
kernel:     file format elf32-i386


Disassembly of section .text:

00100000 <multiboot_header>:
  100000:	02 b0 ad 1b 00 00    	add    0x1bad(%eax),%dh
  100006:	00 00                	add    %al,(%eax)
  100008:	fe 4f 52             	decb   0x52(%edi)
  10000b:	e4                   	.byte 0xe4

0010000c <_start>:

# Entering xv6 on boot processor, with paging off.
.globl entry
entry:
  # Set up the stack pointer.
  movl $(stack + KSTACKSIZE), %esp
  10000c:	bc b0 c6 10 00       	mov    $0x10c6b0,%esp

  # Jump to main(), and switch to executing at
  # high addresses. The indirect call is needed because
  # the assembler produces a PC-relative instruction
  # for a direct jump.
  mov $main, %eax
  100011:	b8 4d 08 10 00       	mov    $0x10084d,%eax
  jmp *%eax
  100016:	ff e0                	jmp    *%eax

00100018 <outw>:
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
}

static inline void
outw(ushort port, ushort data)
{
  100018:	55                   	push   %ebp
  100019:	89 e5                	mov    %esp,%ebp
  10001b:	83 ec 08             	sub    $0x8,%esp
  10001e:	8b 55 08             	mov    0x8(%ebp),%edx
  100021:	8b 45 0c             	mov    0xc(%ebp),%eax
  100024:	66 89 55 fc          	mov    %dx,-0x4(%ebp)
  100028:	66 89 45 f8          	mov    %ax,-0x8(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
  10002c:	0f b7 45 f8          	movzwl -0x8(%ebp),%eax
  100030:	0f b7 55 fc          	movzwl -0x4(%ebp),%edx
  100034:	66 ef                	out    %ax,(%dx)
}
  100036:	90                   	nop
  100037:	c9                   	leave
  100038:	c3                   	ret

00100039 <cli>:
  return eflags;
}

static inline void
cli(void)
{
  100039:	55                   	push   %ebp
  10003a:	89 e5                	mov    %esp,%ebp
  asm volatile("cli");
  10003c:	fa                   	cli
}
  10003d:	90                   	nop
  10003e:	5d                   	pop    %ebp
  10003f:	c3                   	ret

00100040 <printint>:

static int panicked = 0;

static void
printint(int xx, int base, int sign)
{
  100040:	55                   	push   %ebp
  100041:	89 e5                	mov    %esp,%ebp
  100043:	83 ec 28             	sub    $0x28,%esp
  static char digits[] = "0123456789abcdef";
  char buf[16];
  int i;
  uint x;

  if(sign && (sign = xx < 0))
  100046:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
  10004a:	74 1c                	je     100068 <printint+0x28>
  10004c:	8b 45 08             	mov    0x8(%ebp),%eax
  10004f:	c1 e8 1f             	shr    $0x1f,%eax
  100052:	0f b6 c0             	movzbl %al,%eax
  100055:	89 45 10             	mov    %eax,0x10(%ebp)
  100058:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
  10005c:	74 0a                	je     100068 <printint+0x28>
    x = -xx;
  10005e:	8b 45 08             	mov    0x8(%ebp),%eax
  100061:	f7 d8                	neg    %eax
  100063:	89 45 f0             	mov    %eax,-0x10(%ebp)
  100066:	eb 06                	jmp    10006e <printint+0x2e>
  else
    x = xx;
  100068:	8b 45 08             	mov    0x8(%ebp),%eax
  10006b:	89 45 f0             	mov    %eax,-0x10(%ebp)

  i = 0;
  10006e:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  do{
    buf[i++] = digits[x % base];
  100075:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  100078:	8b 45 f0             	mov    -0x10(%ebp),%eax
  10007b:	ba 00 00 00 00       	mov    $0x0,%edx
  100080:	f7 f1                	div    %ecx
  100082:	89 d1                	mov    %edx,%ecx
  100084:	8b 45 f4             	mov    -0xc(%ebp),%eax
  100087:	8d 50 01             	lea    0x1(%eax),%edx
  10008a:	89 55 f4             	mov    %edx,-0xc(%ebp)
  10008d:	0f b6 91 00 50 10 00 	movzbl 0x105000(%ecx),%edx
  100094:	88 54 05 e0          	mov    %dl,-0x20(%ebp,%eax,1)
  }while((x /= base) != 0);
  100098:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  10009b:	8b 45 f0             	mov    -0x10(%ebp),%eax
  10009e:	ba 00 00 00 00       	mov    $0x0,%edx
  1000a3:	f7 f1                	div    %ecx
  1000a5:	89 45 f0             	mov    %eax,-0x10(%ebp)
  1000a8:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
  1000ac:	75 c7                	jne    100075 <printint+0x35>

  if(sign)
  1000ae:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
  1000b2:	74 2a                	je     1000de <printint+0x9e>
    buf[i++] = '-';
  1000b4:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1000b7:	8d 50 01             	lea    0x1(%eax),%edx
  1000ba:	89 55 f4             	mov    %edx,-0xc(%ebp)
  1000bd:	c6 44 05 e0 2d       	movb   $0x2d,-0x20(%ebp,%eax,1)

  while(--i >= 0)
  1000c2:	eb 1a                	jmp    1000de <printint+0x9e>
    consputc(buf[i]);
  1000c4:	8d 55 e0             	lea    -0x20(%ebp),%edx
  1000c7:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1000ca:	01 d0                	add    %edx,%eax
  1000cc:	0f b6 00             	movzbl (%eax),%eax
  1000cf:	0f be c0             	movsbl %al,%eax
  1000d2:	83 ec 0c             	sub    $0xc,%esp
  1000d5:	50                   	push   %eax
  1000d6:	e8 60 02 00 00       	call   10033b <consputc>
  1000db:	83 c4 10             	add    $0x10,%esp
  while(--i >= 0)
  1000de:	83 6d f4 01          	subl   $0x1,-0xc(%ebp)
  1000e2:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
  1000e6:	79 dc                	jns    1000c4 <printint+0x84>
}
  1000e8:	90                   	nop
  1000e9:	90                   	nop
  1000ea:	c9                   	leave
  1000eb:	c3                   	ret

001000ec <cprintf>:

// Print to the console. only understands %d, %x, %p, %s.
void
cprintf(char *fmt, ...)
{
  1000ec:	55                   	push   %ebp
  1000ed:	89 e5                	mov    %esp,%ebp
  1000ef:	83 ec 18             	sub    $0x18,%esp
  int i, c;
  uint *argp;
  char *s;

  if (fmt == 0)
  1000f2:	8b 45 08             	mov    0x8(%ebp),%eax
  1000f5:	85 c0                	test   %eax,%eax
  1000f7:	0f 84 63 01 00 00    	je     100260 <cprintf+0x174>
    // panic("null fmt");
    return;

  argp = (uint*)(void*)(&fmt + 1);
  1000fd:	8d 45 0c             	lea    0xc(%ebp),%eax
  100100:	89 45 f0             	mov    %eax,-0x10(%ebp)
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
  100103:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  10010a:	e9 2f 01 00 00       	jmp    10023e <cprintf+0x152>
    if(c != '%'){
  10010f:	83 7d e8 25          	cmpl   $0x25,-0x18(%ebp)
  100113:	74 13                	je     100128 <cprintf+0x3c>
      consputc(c);
  100115:	83 ec 0c             	sub    $0xc,%esp
  100118:	ff 75 e8             	push   -0x18(%ebp)
  10011b:	e8 1b 02 00 00       	call   10033b <consputc>
  100120:	83 c4 10             	add    $0x10,%esp
      continue;
  100123:	e9 12 01 00 00       	jmp    10023a <cprintf+0x14e>
    }
    c = fmt[++i] & 0xff;
  100128:	8b 55 08             	mov    0x8(%ebp),%edx
  10012b:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  10012f:	8b 45 f4             	mov    -0xc(%ebp),%eax
  100132:	01 d0                	add    %edx,%eax
  100134:	0f b6 00             	movzbl (%eax),%eax
  100137:	0f be c0             	movsbl %al,%eax
  10013a:	25 ff 00 00 00       	and    $0xff,%eax
  10013f:	89 45 e8             	mov    %eax,-0x18(%ebp)
    if(c == 0)
  100142:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
  100146:	0f 84 17 01 00 00    	je     100263 <cprintf+0x177>
      break;
    switch(c){
  10014c:	83 7d e8 78          	cmpl   $0x78,-0x18(%ebp)
  100150:	74 5e                	je     1001b0 <cprintf+0xc4>
  100152:	83 7d e8 78          	cmpl   $0x78,-0x18(%ebp)
  100156:	0f 8f c2 00 00 00    	jg     10021e <cprintf+0x132>
  10015c:	83 7d e8 73          	cmpl   $0x73,-0x18(%ebp)
  100160:	74 6b                	je     1001cd <cprintf+0xe1>
  100162:	83 7d e8 73          	cmpl   $0x73,-0x18(%ebp)
  100166:	0f 8f b2 00 00 00    	jg     10021e <cprintf+0x132>
  10016c:	83 7d e8 70          	cmpl   $0x70,-0x18(%ebp)
  100170:	74 3e                	je     1001b0 <cprintf+0xc4>
  100172:	83 7d e8 70          	cmpl   $0x70,-0x18(%ebp)
  100176:	0f 8f a2 00 00 00    	jg     10021e <cprintf+0x132>
  10017c:	83 7d e8 25          	cmpl   $0x25,-0x18(%ebp)
  100180:	0f 84 89 00 00 00    	je     10020f <cprintf+0x123>
  100186:	83 7d e8 64          	cmpl   $0x64,-0x18(%ebp)
  10018a:	0f 85 8e 00 00 00    	jne    10021e <cprintf+0x132>
    case 'd':
      printint(*argp++, 10, 1);
  100190:	8b 45 f0             	mov    -0x10(%ebp),%eax
  100193:	8d 50 04             	lea    0x4(%eax),%edx
  100196:	89 55 f0             	mov    %edx,-0x10(%ebp)
  100199:	8b 00                	mov    (%eax),%eax
  10019b:	83 ec 04             	sub    $0x4,%esp
  10019e:	6a 01                	push   $0x1
  1001a0:	6a 0a                	push   $0xa
  1001a2:	50                   	push   %eax
  1001a3:	e8 98 fe ff ff       	call   100040 <printint>
  1001a8:	83 c4 10             	add    $0x10,%esp
      break;
  1001ab:	e9 8a 00 00 00       	jmp    10023a <cprintf+0x14e>
    case 'x':
    case 'p':
      printint(*argp++, 16, 0);
  1001b0:	8b 45 f0             	mov    -0x10(%ebp),%eax
  1001b3:	8d 50 04             	lea    0x4(%eax),%edx
  1001b6:	89 55 f0             	mov    %edx,-0x10(%ebp)
  1001b9:	8b 00                	mov    (%eax),%eax
  1001bb:	83 ec 04             	sub    $0x4,%esp
  1001be:	6a 00                	push   $0x0
  1001c0:	6a 10                	push   $0x10
  1001c2:	50                   	push   %eax
  1001c3:	e8 78 fe ff ff       	call   100040 <printint>
  1001c8:	83 c4 10             	add    $0x10,%esp
      break;
  1001cb:	eb 6d                	jmp    10023a <cprintf+0x14e>
    case 's':
      if((s = (char*)*argp++) == 0)
  1001cd:	8b 45 f0             	mov    -0x10(%ebp),%eax
  1001d0:	8d 50 04             	lea    0x4(%eax),%edx
  1001d3:	89 55 f0             	mov    %edx,-0x10(%ebp)
  1001d6:	8b 00                	mov    (%eax),%eax
  1001d8:	89 45 ec             	mov    %eax,-0x14(%ebp)
  1001db:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
  1001df:	75 22                	jne    100203 <cprintf+0x117>
        s = "(null)";
  1001e1:	c7 45 ec 44 40 10 00 	movl   $0x104044,-0x14(%ebp)
      for(; *s; s++)
  1001e8:	eb 19                	jmp    100203 <cprintf+0x117>
        consputc(*s);
  1001ea:	8b 45 ec             	mov    -0x14(%ebp),%eax
  1001ed:	0f b6 00             	movzbl (%eax),%eax
  1001f0:	0f be c0             	movsbl %al,%eax
  1001f3:	83 ec 0c             	sub    $0xc,%esp
  1001f6:	50                   	push   %eax
  1001f7:	e8 3f 01 00 00       	call   10033b <consputc>
  1001fc:	83 c4 10             	add    $0x10,%esp
      for(; *s; s++)
  1001ff:	83 45 ec 01          	addl   $0x1,-0x14(%ebp)
  100203:	8b 45 ec             	mov    -0x14(%ebp),%eax
  100206:	0f b6 00             	movzbl (%eax),%eax
  100209:	84 c0                	test   %al,%al
  10020b:	75 dd                	jne    1001ea <cprintf+0xfe>
      break;
  10020d:	eb 2b                	jmp    10023a <cprintf+0x14e>
    case '%':
      consputc('%');
  10020f:	83 ec 0c             	sub    $0xc,%esp
  100212:	6a 25                	push   $0x25
  100214:	e8 22 01 00 00       	call   10033b <consputc>
  100219:	83 c4 10             	add    $0x10,%esp
      break;
  10021c:	eb 1c                	jmp    10023a <cprintf+0x14e>
    default:
      // Print unknown % sequence to draw attention.
      consputc('%');
  10021e:	83 ec 0c             	sub    $0xc,%esp
  100221:	6a 25                	push   $0x25
  100223:	e8 13 01 00 00       	call   10033b <consputc>
  100228:	83 c4 10             	add    $0x10,%esp
      consputc(c);
  10022b:	83 ec 0c             	sub    $0xc,%esp
  10022e:	ff 75 e8             	push   -0x18(%ebp)
  100231:	e8 05 01 00 00       	call   10033b <consputc>
  100236:	83 c4 10             	add    $0x10,%esp
      break;
  100239:	90                   	nop
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
  10023a:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  10023e:	8b 55 08             	mov    0x8(%ebp),%edx
  100241:	8b 45 f4             	mov    -0xc(%ebp),%eax
  100244:	01 d0                	add    %edx,%eax
  100246:	0f b6 00             	movzbl (%eax),%eax
  100249:	0f be c0             	movsbl %al,%eax
  10024c:	25 ff 00 00 00       	and    $0xff,%eax
  100251:	89 45 e8             	mov    %eax,-0x18(%ebp)
  100254:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
  100258:	0f 85 b1 fe ff ff    	jne    10010f <cprintf+0x23>
  10025e:	eb 04                	jmp    100264 <cprintf+0x178>
    return;
  100260:	90                   	nop
  100261:	eb 01                	jmp    100264 <cprintf+0x178>
      break;
  100263:	90                   	nop
    }
  }
}
  100264:	c9                   	leave
  100265:	c3                   	ret

00100266 <halt>:

void
halt(void)
{
  100266:	55                   	push   %ebp
  100267:	89 e5                	mov    %esp,%ebp
  100269:	83 ec 08             	sub    $0x8,%esp
  cprintf("Bye COL%d!\n\0", 331);
  10026c:	83 ec 08             	sub    $0x8,%esp
  10026f:	68 4b 01 00 00       	push   $0x14b
  100274:	68 4b 40 10 00       	push   $0x10404b
  100279:	e8 6e fe ff ff       	call   1000ec <cprintf>
  10027e:	83 c4 10             	add    $0x10,%esp
  outw(0x602, 0x2000);
  100281:	83 ec 08             	sub    $0x8,%esp
  100284:	68 00 20 00 00       	push   $0x2000
  100289:	68 02 06 00 00       	push   $0x602
  10028e:	e8 85 fd ff ff       	call   100018 <outw>
  100293:	83 c4 10             	add    $0x10,%esp
  // For older versions of QEMU, 
  outw(0xB002, 0x2000);
  100296:	83 ec 08             	sub    $0x8,%esp
  100299:	68 00 20 00 00       	push   $0x2000
  10029e:	68 02 b0 00 00       	push   $0xb002
  1002a3:	e8 70 fd ff ff       	call   100018 <outw>
  1002a8:	83 c4 10             	add    $0x10,%esp
  for(;;);
  1002ab:	90                   	nop
  1002ac:	eb fd                	jmp    1002ab <halt+0x45>

001002ae <panic>:
}

void
panic(char *s)
{
  1002ae:	55                   	push   %ebp
  1002af:	89 e5                	mov    %esp,%ebp
  1002b1:	83 ec 38             	sub    $0x38,%esp
  int i;
  uint pcs[10];

  cli();
  1002b4:	e8 80 fd ff ff       	call   100039 <cli>
  cprintf("lapicid %d: panic: ", lapicid());
  1002b9:	e8 55 04 00 00       	call   100713 <lapicid>
  1002be:	83 ec 08             	sub    $0x8,%esp
  1002c1:	50                   	push   %eax
  1002c2:	68 58 40 10 00       	push   $0x104058
  1002c7:	e8 20 fe ff ff       	call   1000ec <cprintf>
  1002cc:	83 c4 10             	add    $0x10,%esp
  cprintf(s);
  1002cf:	8b 45 08             	mov    0x8(%ebp),%eax
  1002d2:	83 ec 0c             	sub    $0xc,%esp
  1002d5:	50                   	push   %eax
  1002d6:	e8 11 fe ff ff       	call   1000ec <cprintf>
  1002db:	83 c4 10             	add    $0x10,%esp
  cprintf("\n");
  1002de:	83 ec 0c             	sub    $0xc,%esp
  1002e1:	68 6c 40 10 00       	push   $0x10406c
  1002e6:	e8 01 fe ff ff       	call   1000ec <cprintf>
  1002eb:	83 c4 10             	add    $0x10,%esp
  getcallerpcs(&s, pcs);
  1002ee:	83 ec 08             	sub    $0x8,%esp
  1002f1:	8d 45 cc             	lea    -0x34(%ebp),%eax
  1002f4:	50                   	push   %eax
  1002f5:	8d 45 08             	lea    0x8(%ebp),%eax
  1002f8:	50                   	push   %eax
  1002f9:	e8 8b 0e 00 00       	call   101189 <getcallerpcs>
  1002fe:	83 c4 10             	add    $0x10,%esp
  for(i=0; i<10; i++)
  100301:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  100308:	eb 1c                	jmp    100326 <panic+0x78>
    cprintf(" %p", pcs[i]);
  10030a:	8b 45 f4             	mov    -0xc(%ebp),%eax
  10030d:	8b 44 85 cc          	mov    -0x34(%ebp,%eax,4),%eax
  100311:	83 ec 08             	sub    $0x8,%esp
  100314:	50                   	push   %eax
  100315:	68 6e 40 10 00       	push   $0x10406e
  10031a:	e8 cd fd ff ff       	call   1000ec <cprintf>
  10031f:	83 c4 10             	add    $0x10,%esp
  for(i=0; i<10; i++)
  100322:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  100326:	83 7d f4 09          	cmpl   $0x9,-0xc(%ebp)
  10032a:	7e de                	jle    10030a <panic+0x5c>
  panicked = 1; // freeze other CPU
  10032c:	c7 05 ac 54 10 00 01 	movl   $0x1,0x1054ac
  100333:	00 00 00 
  halt();
  100336:	e8 2b ff ff ff       	call   100266 <halt>

0010033b <consputc>:

#define BACKSPACE 0x100

void
consputc(int c)
{
  10033b:	55                   	push   %ebp
  10033c:	89 e5                	mov    %esp,%ebp
  10033e:	83 ec 08             	sub    $0x8,%esp
  if(c == BACKSPACE){
  100341:	81 7d 08 00 01 00 00 	cmpl   $0x100,0x8(%ebp)
  100348:	75 29                	jne    100373 <consputc+0x38>
    uartputc('\b'); uartputc(' '); uartputc('\b');
  10034a:	83 ec 0c             	sub    $0xc,%esp
  10034d:	6a 08                	push   $0x8
  10034f:	e8 38 0a 00 00       	call   100d8c <uartputc>
  100354:	83 c4 10             	add    $0x10,%esp
  100357:	83 ec 0c             	sub    $0xc,%esp
  10035a:	6a 20                	push   $0x20
  10035c:	e8 2b 0a 00 00       	call   100d8c <uartputc>
  100361:	83 c4 10             	add    $0x10,%esp
  100364:	83 ec 0c             	sub    $0xc,%esp
  100367:	6a 08                	push   $0x8
  100369:	e8 1e 0a 00 00       	call   100d8c <uartputc>
  10036e:	83 c4 10             	add    $0x10,%esp
  } else
    uartputc(c);
}
  100371:	eb 0e                	jmp    100381 <consputc+0x46>
    uartputc(c);
  100373:	83 ec 0c             	sub    $0xc,%esp
  100376:	ff 75 08             	push   0x8(%ebp)
  100379:	e8 0e 0a 00 00       	call   100d8c <uartputc>
  10037e:	83 c4 10             	add    $0x10,%esp
}
  100381:	90                   	nop
  100382:	c9                   	leave
  100383:	c3                   	ret

00100384 <consoleintr>:

#define C(x)  ((x)-'@')  // Control-x

void
consoleintr(int (*getc)(void))
{
  100384:	55                   	push   %ebp
  100385:	89 e5                	mov    %esp,%ebp
  100387:	83 ec 18             	sub    $0x18,%esp
  int c;

  while((c = getc()) >= 0){
  10038a:	e9 19 01 00 00       	jmp    1004a8 <consoleintr+0x124>
    switch(c){
  10038f:	83 7d f4 7f          	cmpl   $0x7f,-0xc(%ebp)
  100393:	74 63                	je     1003f8 <consoleintr+0x74>
  100395:	83 7d f4 7f          	cmpl   $0x7f,-0xc(%ebp)
  100399:	0f 8f 8b 00 00 00    	jg     10042a <consoleintr+0xa6>
  10039f:	83 7d f4 08          	cmpl   $0x8,-0xc(%ebp)
  1003a3:	74 53                	je     1003f8 <consoleintr+0x74>
  1003a5:	83 7d f4 15          	cmpl   $0x15,-0xc(%ebp)
  1003a9:	75 7f                	jne    10042a <consoleintr+0xa6>
    case C('U'):  // Kill line.
      while(input.e != input.w &&
  1003ab:	eb 1d                	jmp    1003ca <consoleintr+0x46>
            input.buf[(input.e-1) % INPUT_BUF] != '\n'){
        input.e--;
  1003ad:	a1 a8 54 10 00       	mov    0x1054a8,%eax
  1003b2:	83 e8 01             	sub    $0x1,%eax
  1003b5:	a3 a8 54 10 00       	mov    %eax,0x1054a8
        consputc(BACKSPACE);
  1003ba:	83 ec 0c             	sub    $0xc,%esp
  1003bd:	68 00 01 00 00       	push   $0x100
  1003c2:	e8 74 ff ff ff       	call   10033b <consputc>
  1003c7:	83 c4 10             	add    $0x10,%esp
      while(input.e != input.w &&
  1003ca:	8b 15 a8 54 10 00    	mov    0x1054a8,%edx
  1003d0:	a1 a4 54 10 00       	mov    0x1054a4,%eax
  1003d5:	39 c2                	cmp    %eax,%edx
  1003d7:	0f 84 c4 00 00 00    	je     1004a1 <consoleintr+0x11d>
            input.buf[(input.e-1) % INPUT_BUF] != '\n'){
  1003dd:	a1 a8 54 10 00       	mov    0x1054a8,%eax
  1003e2:	83 e8 01             	sub    $0x1,%eax
  1003e5:	83 e0 7f             	and    $0x7f,%eax
  1003e8:	0f b6 80 20 54 10 00 	movzbl 0x105420(%eax),%eax
      while(input.e != input.w &&
  1003ef:	3c 0a                	cmp    $0xa,%al
  1003f1:	75 ba                	jne    1003ad <consoleintr+0x29>
      }
      break;
  1003f3:	e9 a9 00 00 00       	jmp    1004a1 <consoleintr+0x11d>
    case C('H'): case '\x7f':  // Backspace
      if(input.e != input.w){
  1003f8:	8b 15 a8 54 10 00    	mov    0x1054a8,%edx
  1003fe:	a1 a4 54 10 00       	mov    0x1054a4,%eax
  100403:	39 c2                	cmp    %eax,%edx
  100405:	0f 84 99 00 00 00    	je     1004a4 <consoleintr+0x120>
        input.e--;
  10040b:	a1 a8 54 10 00       	mov    0x1054a8,%eax
  100410:	83 e8 01             	sub    $0x1,%eax
  100413:	a3 a8 54 10 00       	mov    %eax,0x1054a8
        consputc(BACKSPACE);
  100418:	83 ec 0c             	sub    $0xc,%esp
  10041b:	68 00 01 00 00       	push   $0x100
  100420:	e8 16 ff ff ff       	call   10033b <consputc>
  100425:	83 c4 10             	add    $0x10,%esp
      }
      break;
  100428:	eb 7a                	jmp    1004a4 <consoleintr+0x120>
    default:
      if(c != 0 && input.e-input.r < INPUT_BUF){
  10042a:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
  10042e:	74 77                	je     1004a7 <consoleintr+0x123>
  100430:	8b 15 a8 54 10 00    	mov    0x1054a8,%edx
  100436:	a1 a0 54 10 00       	mov    0x1054a0,%eax
  10043b:	29 c2                	sub    %eax,%edx
  10043d:	83 fa 7f             	cmp    $0x7f,%edx
  100440:	77 65                	ja     1004a7 <consoleintr+0x123>
        c = (c == '\r') ? '\n' : c;
  100442:	83 7d f4 0d          	cmpl   $0xd,-0xc(%ebp)
  100446:	75 07                	jne    10044f <consoleintr+0xcb>
  100448:	c7 45 f4 0a 00 00 00 	movl   $0xa,-0xc(%ebp)
        input.buf[input.e++ % INPUT_BUF] = c;
  10044f:	a1 a8 54 10 00       	mov    0x1054a8,%eax
  100454:	8d 50 01             	lea    0x1(%eax),%edx
  100457:	89 15 a8 54 10 00    	mov    %edx,0x1054a8
  10045d:	83 e0 7f             	and    $0x7f,%eax
  100460:	8b 55 f4             	mov    -0xc(%ebp),%edx
  100463:	88 90 20 54 10 00    	mov    %dl,0x105420(%eax)
        consputc(c);
  100469:	83 ec 0c             	sub    $0xc,%esp
  10046c:	ff 75 f4             	push   -0xc(%ebp)
  10046f:	e8 c7 fe ff ff       	call   10033b <consputc>
  100474:	83 c4 10             	add    $0x10,%esp
        if(c == '\n' || c == C('D') || input.e == input.r+INPUT_BUF){
  100477:	83 7d f4 0a          	cmpl   $0xa,-0xc(%ebp)
  10047b:	74 18                	je     100495 <consoleintr+0x111>
  10047d:	83 7d f4 04          	cmpl   $0x4,-0xc(%ebp)
  100481:	74 12                	je     100495 <consoleintr+0x111>
  100483:	8b 15 a8 54 10 00    	mov    0x1054a8,%edx
  100489:	a1 a0 54 10 00       	mov    0x1054a0,%eax
  10048e:	83 e8 80             	sub    $0xffffff80,%eax
  100491:	39 c2                	cmp    %eax,%edx
  100493:	75 12                	jne    1004a7 <consoleintr+0x123>
          input.w = input.e;
  100495:	a1 a8 54 10 00       	mov    0x1054a8,%eax
  10049a:	a3 a4 54 10 00       	mov    %eax,0x1054a4
        }
      }
      break;
  10049f:	eb 06                	jmp    1004a7 <consoleintr+0x123>
      break;
  1004a1:	90                   	nop
  1004a2:	eb 04                	jmp    1004a8 <consoleintr+0x124>
      break;
  1004a4:	90                   	nop
  1004a5:	eb 01                	jmp    1004a8 <consoleintr+0x124>
      break;
  1004a7:	90                   	nop
  while((c = getc()) >= 0){
  1004a8:	8b 45 08             	mov    0x8(%ebp),%eax
  1004ab:	ff d0                	call   *%eax
  1004ad:	89 45 f4             	mov    %eax,-0xc(%ebp)
  1004b0:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
  1004b4:	0f 89 d5 fe ff ff    	jns    10038f <consoleintr+0xb>
    }
  }
  1004ba:	90                   	nop
  1004bb:	90                   	nop
  1004bc:	c9                   	leave
  1004bd:	c3                   	ret

001004be <ioapicread>:
  uint data;
};

static uint
ioapicread(int reg)
{
  1004be:	55                   	push   %ebp
  1004bf:	89 e5                	mov    %esp,%ebp
  ioapic->reg = reg;
  1004c1:	a1 b0 54 10 00       	mov    0x1054b0,%eax
  1004c6:	8b 55 08             	mov    0x8(%ebp),%edx
  1004c9:	89 10                	mov    %edx,(%eax)
  return ioapic->data;
  1004cb:	a1 b0 54 10 00       	mov    0x1054b0,%eax
  1004d0:	8b 40 10             	mov    0x10(%eax),%eax
}
  1004d3:	5d                   	pop    %ebp
  1004d4:	c3                   	ret

001004d5 <ioapicwrite>:

static void
ioapicwrite(int reg, uint data)
{
  1004d5:	55                   	push   %ebp
  1004d6:	89 e5                	mov    %esp,%ebp
  ioapic->reg = reg;
  1004d8:	a1 b0 54 10 00       	mov    0x1054b0,%eax
  1004dd:	8b 55 08             	mov    0x8(%ebp),%edx
  1004e0:	89 10                	mov    %edx,(%eax)
  ioapic->data = data;
  1004e2:	a1 b0 54 10 00       	mov    0x1054b0,%eax
  1004e7:	8b 55 0c             	mov    0xc(%ebp),%edx
  1004ea:	89 50 10             	mov    %edx,0x10(%eax)
}
  1004ed:	90                   	nop
  1004ee:	5d                   	pop    %ebp
  1004ef:	c3                   	ret

001004f0 <ioapicinit>:

void
ioapicinit(void)
{
  1004f0:	55                   	push   %ebp
  1004f1:	89 e5                	mov    %esp,%ebp
  1004f3:	83 ec 18             	sub    $0x18,%esp
  int i, id, maxintr;

  ioapic = (volatile struct ioapic*)IOAPIC;
  1004f6:	c7 05 b0 54 10 00 00 	movl   $0xfec00000,0x1054b0
  1004fd:	00 c0 fe 
  maxintr = (ioapicread(REG_VER) >> 16) & 0xFF;
  100500:	6a 01                	push   $0x1
  100502:	e8 b7 ff ff ff       	call   1004be <ioapicread>
  100507:	83 c4 04             	add    $0x4,%esp
  10050a:	c1 e8 10             	shr    $0x10,%eax
  10050d:	25 ff 00 00 00       	and    $0xff,%eax
  100512:	89 45 f0             	mov    %eax,-0x10(%ebp)
  id = ioapicread(REG_ID) >> 24;
  100515:	6a 00                	push   $0x0
  100517:	e8 a2 ff ff ff       	call   1004be <ioapicread>
  10051c:	83 c4 04             	add    $0x4,%esp
  10051f:	c1 e8 18             	shr    $0x18,%eax
  100522:	89 45 ec             	mov    %eax,-0x14(%ebp)
  if(id != ioapicid)
  100525:	0f b6 05 c4 54 10 00 	movzbl 0x1054c4,%eax
  10052c:	0f b6 c0             	movzbl %al,%eax
  10052f:	39 45 ec             	cmp    %eax,-0x14(%ebp)
  100532:	74 10                	je     100544 <ioapicinit+0x54>
    cprintf("ioapicinit: id isn't equal to ioapicid; not a MP\n");
  100534:	83 ec 0c             	sub    $0xc,%esp
  100537:	68 74 40 10 00       	push   $0x104074
  10053c:	e8 ab fb ff ff       	call   1000ec <cprintf>
  100541:	83 c4 10             	add    $0x10,%esp

  // Mark all interrupts edge-triggered, active high, disabled,
  // and not routed to any CPUs.
  for(i = 0; i <= maxintr; i++){
  100544:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  10054b:	eb 3f                	jmp    10058c <ioapicinit+0x9c>
    ioapicwrite(REG_TABLE+2*i, INT_DISABLED | (T_IRQ0 + i));
  10054d:	8b 45 f4             	mov    -0xc(%ebp),%eax
  100550:	83 c0 20             	add    $0x20,%eax
  100553:	0d 00 00 01 00       	or     $0x10000,%eax
  100558:	89 c2                	mov    %eax,%edx
  10055a:	8b 45 f4             	mov    -0xc(%ebp),%eax
  10055d:	83 c0 08             	add    $0x8,%eax
  100560:	01 c0                	add    %eax,%eax
  100562:	83 ec 08             	sub    $0x8,%esp
  100565:	52                   	push   %edx
  100566:	50                   	push   %eax
  100567:	e8 69 ff ff ff       	call   1004d5 <ioapicwrite>
  10056c:	83 c4 10             	add    $0x10,%esp
    ioapicwrite(REG_TABLE+2*i+1, 0);
  10056f:	8b 45 f4             	mov    -0xc(%ebp),%eax
  100572:	83 c0 08             	add    $0x8,%eax
  100575:	01 c0                	add    %eax,%eax
  100577:	83 c0 01             	add    $0x1,%eax
  10057a:	83 ec 08             	sub    $0x8,%esp
  10057d:	6a 00                	push   $0x0
  10057f:	50                   	push   %eax
  100580:	e8 50 ff ff ff       	call   1004d5 <ioapicwrite>
  100585:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i <= maxintr; i++){
  100588:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  10058c:	8b 45 f4             	mov    -0xc(%ebp),%eax
  10058f:	3b 45 f0             	cmp    -0x10(%ebp),%eax
  100592:	7e b9                	jle    10054d <ioapicinit+0x5d>
  }
}
  100594:	90                   	nop
  100595:	90                   	nop
  100596:	c9                   	leave
  100597:	c3                   	ret

00100598 <ioapicenable>:

void
ioapicenable(int irq, int cpunum)
{
  100598:	55                   	push   %ebp
  100599:	89 e5                	mov    %esp,%ebp
  // Mark interrupt edge-triggered, active high,
  // enabled, and routed to the given cpunum,
  // which happens to be that cpu's APIC ID.
  ioapicwrite(REG_TABLE+2*irq, T_IRQ0 + irq);
  10059b:	8b 45 08             	mov    0x8(%ebp),%eax
  10059e:	83 c0 20             	add    $0x20,%eax
  1005a1:	89 c2                	mov    %eax,%edx
  1005a3:	8b 45 08             	mov    0x8(%ebp),%eax
  1005a6:	83 c0 08             	add    $0x8,%eax
  1005a9:	01 c0                	add    %eax,%eax
  1005ab:	52                   	push   %edx
  1005ac:	50                   	push   %eax
  1005ad:	e8 23 ff ff ff       	call   1004d5 <ioapicwrite>
  1005b2:	83 c4 08             	add    $0x8,%esp
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
  1005b5:	8b 45 0c             	mov    0xc(%ebp),%eax
  1005b8:	c1 e0 18             	shl    $0x18,%eax
  1005bb:	89 c2                	mov    %eax,%edx
  1005bd:	8b 45 08             	mov    0x8(%ebp),%eax
  1005c0:	83 c0 08             	add    $0x8,%eax
  1005c3:	01 c0                	add    %eax,%eax
  1005c5:	83 c0 01             	add    $0x1,%eax
  1005c8:	52                   	push   %edx
  1005c9:	50                   	push   %eax
  1005ca:	e8 06 ff ff ff       	call   1004d5 <ioapicwrite>
  1005cf:	83 c4 08             	add    $0x8,%esp
}
  1005d2:	90                   	nop
  1005d3:	c9                   	leave
  1005d4:	c3                   	ret

001005d5 <lapicw>:

volatile uint *lapic;  // Initialized in mp.c

static void
lapicw(int index, int value)
{
  1005d5:	55                   	push   %ebp
  1005d6:	89 e5                	mov    %esp,%ebp
  lapic[index] = value;
  1005d8:	a1 b4 54 10 00       	mov    0x1054b4,%eax
  1005dd:	8b 55 08             	mov    0x8(%ebp),%edx
  1005e0:	c1 e2 02             	shl    $0x2,%edx
  1005e3:	01 c2                	add    %eax,%edx
  1005e5:	8b 45 0c             	mov    0xc(%ebp),%eax
  1005e8:	89 02                	mov    %eax,(%edx)
  lapic[ID];  // wait for write to finish, by reading
  1005ea:	a1 b4 54 10 00       	mov    0x1054b4,%eax
  1005ef:	83 c0 20             	add    $0x20,%eax
  1005f2:	8b 00                	mov    (%eax),%eax
}
  1005f4:	90                   	nop
  1005f5:	5d                   	pop    %ebp
  1005f6:	c3                   	ret

001005f7 <lapicinit>:

void
lapicinit(void)
{
  1005f7:	55                   	push   %ebp
  1005f8:	89 e5                	mov    %esp,%ebp
  if(!lapic)
  1005fa:	a1 b4 54 10 00       	mov    0x1054b4,%eax
  1005ff:	85 c0                	test   %eax,%eax
  100601:	0f 84 09 01 00 00    	je     100710 <lapicinit+0x119>
    return;

  // Enable local APIC; set spurious interrupt vector.
  lapicw(SVR, ENABLE | (T_IRQ0 + IRQ_SPURIOUS));
  100607:	68 3f 01 00 00       	push   $0x13f
  10060c:	6a 3c                	push   $0x3c
  10060e:	e8 c2 ff ff ff       	call   1005d5 <lapicw>
  100613:	83 c4 08             	add    $0x8,%esp

  // The timer repeatedly counts down at bus frequency
  // from lapic[TICR] and then issues an interrupt.
  // If xv6 cared more about precise timekeeping,
  // TICR would be calibrated using an external time source.
  lapicw(TDCR, X1);
  100616:	6a 0b                	push   $0xb
  100618:	68 f8 00 00 00       	push   $0xf8
  10061d:	e8 b3 ff ff ff       	call   1005d5 <lapicw>
  100622:	83 c4 08             	add    $0x8,%esp
  lapicw(TIMER, PERIODIC | (T_IRQ0 + IRQ_TIMER));
  100625:	68 20 00 02 00       	push   $0x20020
  10062a:	68 c8 00 00 00       	push   $0xc8
  10062f:	e8 a1 ff ff ff       	call   1005d5 <lapicw>
  100634:	83 c4 08             	add    $0x8,%esp
  lapicw(TICR, 10000000);
  100637:	68 80 96 98 00       	push   $0x989680
  10063c:	68 e0 00 00 00       	push   $0xe0
  100641:	e8 8f ff ff ff       	call   1005d5 <lapicw>
  100646:	83 c4 08             	add    $0x8,%esp

  // Disable logical interrupt lines.
  lapicw(LINT0, MASKED);
  100649:	68 00 00 01 00       	push   $0x10000
  10064e:	68 d4 00 00 00       	push   $0xd4
  100653:	e8 7d ff ff ff       	call   1005d5 <lapicw>
  100658:	83 c4 08             	add    $0x8,%esp
  lapicw(LINT1, MASKED);
  10065b:	68 00 00 01 00       	push   $0x10000
  100660:	68 d8 00 00 00       	push   $0xd8
  100665:	e8 6b ff ff ff       	call   1005d5 <lapicw>
  10066a:	83 c4 08             	add    $0x8,%esp

  // Disable performance counter overflow interrupts
  // on machines that provide that interrupt entry.
  if(((lapic[VER]>>16) & 0xFF) >= 4)
  10066d:	a1 b4 54 10 00       	mov    0x1054b4,%eax
  100672:	83 c0 30             	add    $0x30,%eax
  100675:	8b 00                	mov    (%eax),%eax
  100677:	25 00 00 fc 00       	and    $0xfc0000,%eax
  10067c:	85 c0                	test   %eax,%eax
  10067e:	74 12                	je     100692 <lapicinit+0x9b>
    lapicw(PCINT, MASKED);
  100680:	68 00 00 01 00       	push   $0x10000
  100685:	68 d0 00 00 00       	push   $0xd0
  10068a:	e8 46 ff ff ff       	call   1005d5 <lapicw>
  10068f:	83 c4 08             	add    $0x8,%esp

  // Map error interrupt to IRQ_ERROR.
  lapicw(ERROR, T_IRQ0 + IRQ_ERROR);
  100692:	6a 33                	push   $0x33
  100694:	68 dc 00 00 00       	push   $0xdc
  100699:	e8 37 ff ff ff       	call   1005d5 <lapicw>
  10069e:	83 c4 08             	add    $0x8,%esp

  // Clear error status register (requires back-to-back writes).
  lapicw(ESR, 0);
  1006a1:	6a 00                	push   $0x0
  1006a3:	68 a0 00 00 00       	push   $0xa0
  1006a8:	e8 28 ff ff ff       	call   1005d5 <lapicw>
  1006ad:	83 c4 08             	add    $0x8,%esp
  lapicw(ESR, 0);
  1006b0:	6a 00                	push   $0x0
  1006b2:	68 a0 00 00 00       	push   $0xa0
  1006b7:	e8 19 ff ff ff       	call   1005d5 <lapicw>
  1006bc:	83 c4 08             	add    $0x8,%esp

  // Ack any outstanding interrupts.
  lapicw(EOI, 0);
  1006bf:	6a 00                	push   $0x0
  1006c1:	6a 2c                	push   $0x2c
  1006c3:	e8 0d ff ff ff       	call   1005d5 <lapicw>
  1006c8:	83 c4 08             	add    $0x8,%esp

  // Send an Init Level De-Assert to synchronise arbitration ID's.
  lapicw(ICRHI, 0);
  1006cb:	6a 00                	push   $0x0
  1006cd:	68 c4 00 00 00       	push   $0xc4
  1006d2:	e8 fe fe ff ff       	call   1005d5 <lapicw>
  1006d7:	83 c4 08             	add    $0x8,%esp
  lapicw(ICRLO, BCAST | INIT | LEVEL);
  1006da:	68 00 85 08 00       	push   $0x88500
  1006df:	68 c0 00 00 00       	push   $0xc0
  1006e4:	e8 ec fe ff ff       	call   1005d5 <lapicw>
  1006e9:	83 c4 08             	add    $0x8,%esp
  while(lapic[ICRLO] & DELIVS)
  1006ec:	90                   	nop
  1006ed:	a1 b4 54 10 00       	mov    0x1054b4,%eax
  1006f2:	05 00 03 00 00       	add    $0x300,%eax
  1006f7:	8b 00                	mov    (%eax),%eax
  1006f9:	25 00 10 00 00       	and    $0x1000,%eax
  1006fe:	85 c0                	test   %eax,%eax
  100700:	75 eb                	jne    1006ed <lapicinit+0xf6>
    ;

  // Enable interrupts on the APIC (but not on the processor).
  lapicw(TPR, 0);
  100702:	6a 00                	push   $0x0
  100704:	6a 20                	push   $0x20
  100706:	e8 ca fe ff ff       	call   1005d5 <lapicw>
  10070b:	83 c4 08             	add    $0x8,%esp
  10070e:	eb 01                	jmp    100711 <lapicinit+0x11a>
    return;
  100710:	90                   	nop
}
  100711:	c9                   	leave
  100712:	c3                   	ret

00100713 <lapicid>:

int
lapicid(void)
{
  100713:	55                   	push   %ebp
  100714:	89 e5                	mov    %esp,%ebp
  if (!lapic)
  100716:	a1 b4 54 10 00       	mov    0x1054b4,%eax
  10071b:	85 c0                	test   %eax,%eax
  10071d:	75 07                	jne    100726 <lapicid+0x13>
    return 0;
  10071f:	b8 00 00 00 00       	mov    $0x0,%eax
  100724:	eb 0d                	jmp    100733 <lapicid+0x20>
  return lapic[ID] >> 24;
  100726:	a1 b4 54 10 00       	mov    0x1054b4,%eax
  10072b:	83 c0 20             	add    $0x20,%eax
  10072e:	8b 00                	mov    (%eax),%eax
  100730:	c1 e8 18             	shr    $0x18,%eax
}
  100733:	5d                   	pop    %ebp
  100734:	c3                   	ret

00100735 <lapiceoi>:

// Acknowledge interrupt.
void
lapiceoi(void)
{
  100735:	55                   	push   %ebp
  100736:	89 e5                	mov    %esp,%ebp
  if(lapic)
  100738:	a1 b4 54 10 00       	mov    0x1054b4,%eax
  10073d:	85 c0                	test   %eax,%eax
  10073f:	74 0c                	je     10074d <lapiceoi+0x18>
    lapicw(EOI, 0);
  100741:	6a 00                	push   $0x0
  100743:	6a 2c                	push   $0x2c
  100745:	e8 8b fe ff ff       	call   1005d5 <lapicw>
  10074a:	83 c4 08             	add    $0x8,%esp
}
  10074d:	90                   	nop
  10074e:	c9                   	leave
  10074f:	c3                   	ret

00100750 <microdelay>:

// Spin for a given number of microseconds.
// On real hardware would want to tune this dynamically.
void
microdelay(int us)
{
  100750:	55                   	push   %ebp
  100751:	89 e5                	mov    %esp,%ebp
  100753:	90                   	nop
  100754:	5d                   	pop    %ebp
  100755:	c3                   	ret

00100756 <sti>:


static inline void
sti(void)
{
  100756:	55                   	push   %ebp
  100757:	89 e5                	mov    %esp,%ebp
  asm volatile("sti");
  100759:	fb                   	sti
}
  10075a:	90                   	nop
  10075b:	5d                   	pop    %ebp
  10075c:	c3                   	ret

0010075d <wfi>:

static inline void
wfi(void)
{
  10075d:	55                   	push   %ebp
  10075e:	89 e5                	mov    %esp,%ebp
  asm volatile("hlt");
  100760:	f4                   	hlt
}
  100761:	90                   	nop
  100762:	5d                   	pop    %ebp
  100763:	c3                   	ret

00100764 <log_test>:
#include "logflag.h"

extern char end[]; // first address after kernel loaded from ELF file

static inline void 
log_test(void) {
  100764:	55                   	push   %ebp
  100765:	89 e5                	mov    %esp,%ebp
  100767:	81 ec 18 02 00 00    	sub    $0x218,%esp
  struct file* gtxt;
  int n;
  char buffer[512];

  if((gtxt=open("/hello.txt", O_RDONLY)) == 0) {
  10076d:	83 ec 08             	sub    $0x8,%esp
  100770:	6a 00                	push   $0x0
  100772:	68 a6 40 10 00       	push   $0x1040a6
  100777:	e8 31 33 00 00       	call   103aad <open>
  10077c:	83 c4 10             	add    $0x10,%esp
  10077f:	89 45 f4             	mov    %eax,-0xc(%ebp)
  100782:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
  100786:	75 0d                	jne    100795 <log_test+0x31>
    panic("Unable to open /hello.txt");
  100788:	83 ec 0c             	sub    $0xc,%esp
  10078b:	68 b1 40 10 00       	push   $0x1040b1
  100790:	e8 19 fb ff ff       	call   1002ae <panic>
  } 

  n = fileread(gtxt, buffer, 5);
  100795:	83 ec 04             	sub    $0x4,%esp
  100798:	6a 05                	push   $0x5
  10079a:	8d 85 f0 fd ff ff    	lea    -0x210(%ebp),%eax
  1007a0:	50                   	push   %eax
  1007a1:	ff 75 f4             	push   -0xc(%ebp)
  1007a4:	e8 8d 2d 00 00       	call   103536 <fileread>
  1007a9:	83 c4 10             	add    $0x10,%esp
  1007ac:	89 45 f0             	mov    %eax,-0x10(%ebp)
  cprintf("[UNDOLOG] READ: %d %s\n", n, buffer);
  1007af:	83 ec 04             	sub    $0x4,%esp
  1007b2:	8d 85 f0 fd ff ff    	lea    -0x210(%ebp),%eax
  1007b8:	50                   	push   %eax
  1007b9:	ff 75 f0             	push   -0x10(%ebp)
  1007bc:	68 cb 40 10 00       	push   $0x1040cb
  1007c1:	e8 26 f9 ff ff       	call   1000ec <cprintf>
  1007c6:	83 c4 10             	add    $0x10,%esp
  fileclose(gtxt);
  1007c9:	83 ec 0c             	sub    $0xc,%esp
  1007cc:	ff 75 f4             	push   -0xc(%ebp)
  1007cf:	e8 8e 2c 00 00       	call   103462 <fileclose>
  1007d4:	83 c4 10             	add    $0x10,%esp

  buffer[0] = '0' + PANIC_1;
  1007d7:	c6 85 f0 fd ff ff 30 	movb   $0x30,-0x210(%ebp)
  buffer[1] = '0' + PANIC_2;
  1007de:	c6 85 f1 fd ff ff 30 	movb   $0x30,-0x20f(%ebp)
  buffer[2] = '0' + PANIC_3;
  1007e5:	c6 85 f2 fd ff ff 30 	movb   $0x30,-0x20e(%ebp)
  buffer[3] = '0' + PANIC_4;
  1007ec:	c6 85 f3 fd ff ff 30 	movb   $0x30,-0x20d(%ebp)
  buffer[4] = '0' + PANIC_5;
  1007f3:	c6 85 f4 fd ff ff 30 	movb   $0x30,-0x20c(%ebp)

  // Open for writing 
  if((gtxt = open("/hello.txt", O_WRONLY)) == 0){
  1007fa:	83 ec 08             	sub    $0x8,%esp
  1007fd:	6a 01                	push   $0x1
  1007ff:	68 a6 40 10 00       	push   $0x1040a6
  100804:	e8 a4 32 00 00       	call   103aad <open>
  100809:	83 c4 10             	add    $0x10,%esp
  10080c:	89 45 f4             	mov    %eax,-0xc(%ebp)
  10080f:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
  100813:	75 0d                	jne    100822 <log_test+0xbe>
    panic("Failed to create /hello.txt");
  100815:	83 ec 0c             	sub    $0xc,%esp
  100818:	68 e2 40 10 00       	push   $0x1040e2
  10081d:	e8 8c fa ff ff       	call   1002ae <panic>
  }  
  n = filewrite(gtxt, buffer, 5);
  100822:	83 ec 04             	sub    $0x4,%esp
  100825:	6a 05                	push   $0x5
  100827:	8d 85 f0 fd ff ff    	lea    -0x210(%ebp),%eax
  10082d:	50                   	push   %eax
  10082e:	ff 75 f4             	push   -0xc(%ebp)
  100831:	e8 7f 2d 00 00       	call   1035b5 <filewrite>
  100836:	83 c4 10             	add    $0x10,%esp
  100839:	89 45 f0             	mov    %eax,-0x10(%ebp)
  fileclose(gtxt);
  10083c:	83 ec 0c             	sub    $0xc,%esp
  10083f:	ff 75 f4             	push   -0xc(%ebp)
  100842:	e8 1b 2c 00 00       	call   103462 <fileclose>
  100847:	83 c4 10             	add    $0x10,%esp
}
  10084a:	90                   	nop
  10084b:	c9                   	leave
  10084c:	c3                   	ret

0010084d <main>:

// Bootstrap processor starts running C code here.
int
main(int argc, char* argv[])
{
  10084d:	8d 4c 24 04          	lea    0x4(%esp),%ecx
  100851:	83 e4 f0             	and    $0xfffffff0,%esp
  100854:	ff 71 fc             	push   -0x4(%ecx)
  100857:	55                   	push   %ebp
  100858:	89 e5                	mov    %esp,%ebp
  10085a:	51                   	push   %ecx
  10085b:	83 ec 04             	sub    $0x4,%esp
  mpinit();        // detect other processors
  10085e:	e8 83 02 00 00       	call   100ae6 <mpinit>
  lapicinit();     // interrupt controller
  100863:	e8 8f fd ff ff       	call   1005f7 <lapicinit>
  picinit();       // disable pic
  100868:	e8 d5 03 00 00       	call   100c42 <picinit>
  ioapicinit();    // another interrupt controller
  10086d:	e8 7e fc ff ff       	call   1004f0 <ioapicinit>
  uartinit();      // serial port
  100872:	e8 2e 04 00 00       	call   100ca5 <uartinit>
  ideinit();       // disk 
  100877:	e8 d1 18 00 00       	call   10214d <ideinit>
  tvinit();        // trap vectors
  10087c:	e8 c4 09 00 00       	call   101245 <tvinit>
  binit();         // buffer cache
  100881:	e8 fd 15 00 00       	call   101e83 <binit>
  idtinit();       // load idt register
  100886:	e8 a0 0a 00 00       	call   10132b <idtinit>
  sti();           // enable interrupts
  10088b:	e8 c6 fe ff ff       	call   100756 <sti>
  iinit(ROOTDEV);  // Read superblock to start reading inodes
  100890:	83 ec 0c             	sub    $0xc,%esp
  100893:	6a 01                	push   $0x1
  100895:	e8 c1 1e 00 00       	call   10275b <iinit>
  10089a:	83 c4 10             	add    $0x10,%esp
  initlog(ROOTDEV);  // Initialize log
  10089d:	83 ec 0c             	sub    $0xc,%esp
  1008a0:	6a 01                	push   $0x1
  1008a2:	e8 c3 33 00 00       	call   103c6a <initlog>
  1008a7:	83 c4 10             	add    $0x10,%esp
  log_test();
  1008aa:	e8 b5 fe ff ff       	call   100764 <log_test>
  for(;;)
    wfi();
  1008af:	e8 a9 fe ff ff       	call   10075d <wfi>
  1008b4:	eb f9                	jmp    1008af <main+0x62>

001008b6 <inb>:
{
  1008b6:	55                   	push   %ebp
  1008b7:	89 e5                	mov    %esp,%ebp
  1008b9:	83 ec 14             	sub    $0x14,%esp
  1008bc:	8b 45 08             	mov    0x8(%ebp),%eax
  1008bf:	66 89 45 ec          	mov    %ax,-0x14(%ebp)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
  1008c3:	0f b7 45 ec          	movzwl -0x14(%ebp),%eax
  1008c7:	89 c2                	mov    %eax,%edx
  1008c9:	ec                   	in     (%dx),%al
  1008ca:	88 45 ff             	mov    %al,-0x1(%ebp)
  return data;
  1008cd:	0f b6 45 ff          	movzbl -0x1(%ebp),%eax
}
  1008d1:	c9                   	leave
  1008d2:	c3                   	ret

001008d3 <outb>:
{
  1008d3:	55                   	push   %ebp
  1008d4:	89 e5                	mov    %esp,%ebp
  1008d6:	83 ec 08             	sub    $0x8,%esp
  1008d9:	8b 55 08             	mov    0x8(%ebp),%edx
  1008dc:	8b 45 0c             	mov    0xc(%ebp),%eax
  1008df:	66 89 55 fc          	mov    %dx,-0x4(%ebp)
  1008e3:	88 45 f8             	mov    %al,-0x8(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
  1008e6:	0f b6 45 f8          	movzbl -0x8(%ebp),%eax
  1008ea:	0f b7 55 fc          	movzwl -0x4(%ebp),%edx
  1008ee:	ee                   	out    %al,(%dx)
}
  1008ef:	90                   	nop
  1008f0:	c9                   	leave
  1008f1:	c3                   	ret

001008f2 <sum>:
int ncpu;
uchar ioapicid;

static uchar
sum(uchar *addr, int len)
{
  1008f2:	55                   	push   %ebp
  1008f3:	89 e5                	mov    %esp,%ebp
  1008f5:	83 ec 10             	sub    $0x10,%esp
  int i, sum;

  sum = 0;
  1008f8:	c7 45 f8 00 00 00 00 	movl   $0x0,-0x8(%ebp)
  for(i=0; i<len; i++)
  1008ff:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
  100906:	eb 15                	jmp    10091d <sum+0x2b>
    sum += addr[i];
  100908:	8b 55 fc             	mov    -0x4(%ebp),%edx
  10090b:	8b 45 08             	mov    0x8(%ebp),%eax
  10090e:	01 d0                	add    %edx,%eax
  100910:	0f b6 00             	movzbl (%eax),%eax
  100913:	0f b6 c0             	movzbl %al,%eax
  100916:	01 45 f8             	add    %eax,-0x8(%ebp)
  for(i=0; i<len; i++)
  100919:	83 45 fc 01          	addl   $0x1,-0x4(%ebp)
  10091d:	8b 45 fc             	mov    -0x4(%ebp),%eax
  100920:	3b 45 0c             	cmp    0xc(%ebp),%eax
  100923:	7c e3                	jl     100908 <sum+0x16>
  return sum;
  100925:	8b 45 f8             	mov    -0x8(%ebp),%eax
}
  100928:	c9                   	leave
  100929:	c3                   	ret

0010092a <mpsearch1>:

// Look for an MP structure in the len bytes at addr.
static struct mp*
mpsearch1(uint a, int len)
{
  10092a:	55                   	push   %ebp
  10092b:	89 e5                	mov    %esp,%ebp
  10092d:	83 ec 18             	sub    $0x18,%esp
  uchar *e, *p, *addr;

  // addr = P2V(a);
  addr = (uchar*) a;
  100930:	8b 45 08             	mov    0x8(%ebp),%eax
  100933:	89 45 f0             	mov    %eax,-0x10(%ebp)
  e = addr+len;
  100936:	8b 55 0c             	mov    0xc(%ebp),%edx
  100939:	8b 45 f0             	mov    -0x10(%ebp),%eax
  10093c:	01 d0                	add    %edx,%eax
  10093e:	89 45 ec             	mov    %eax,-0x14(%ebp)
  for(p = addr; p < e; p += sizeof(struct mp))
  100941:	8b 45 f0             	mov    -0x10(%ebp),%eax
  100944:	89 45 f4             	mov    %eax,-0xc(%ebp)
  100947:	eb 36                	jmp    10097f <mpsearch1+0x55>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
  100949:	83 ec 04             	sub    $0x4,%esp
  10094c:	6a 04                	push   $0x4
  10094e:	68 00 41 10 00       	push   $0x104100
  100953:	ff 75 f4             	push   -0xc(%ebp)
  100956:	e8 92 05 00 00       	call   100eed <memcmp>
  10095b:	83 c4 10             	add    $0x10,%esp
  10095e:	85 c0                	test   %eax,%eax
  100960:	75 19                	jne    10097b <mpsearch1+0x51>
  100962:	83 ec 08             	sub    $0x8,%esp
  100965:	6a 10                	push   $0x10
  100967:	ff 75 f4             	push   -0xc(%ebp)
  10096a:	e8 83 ff ff ff       	call   1008f2 <sum>
  10096f:	83 c4 10             	add    $0x10,%esp
  100972:	84 c0                	test   %al,%al
  100974:	75 05                	jne    10097b <mpsearch1+0x51>
      return (struct mp*)p;
  100976:	8b 45 f4             	mov    -0xc(%ebp),%eax
  100979:	eb 11                	jmp    10098c <mpsearch1+0x62>
  for(p = addr; p < e; p += sizeof(struct mp))
  10097b:	83 45 f4 10          	addl   $0x10,-0xc(%ebp)
  10097f:	8b 45 f4             	mov    -0xc(%ebp),%eax
  100982:	3b 45 ec             	cmp    -0x14(%ebp),%eax
  100985:	72 c2                	jb     100949 <mpsearch1+0x1f>
  return 0;
  100987:	b8 00 00 00 00       	mov    $0x0,%eax
}
  10098c:	c9                   	leave
  10098d:	c3                   	ret

0010098e <mpsearch>:
// 1) in the first KB of the EBDA;
// 2) in the last KB of system base memory;
// 3) in the BIOS ROM between 0xE0000 and 0xFFFFF.
static struct mp*
mpsearch(void)
{
  10098e:	55                   	push   %ebp
  10098f:	89 e5                	mov    %esp,%ebp
  100991:	83 ec 18             	sub    $0x18,%esp
  uchar *bda;
  uint p;
  struct mp *mp;

  // bda = (uchar *) P2V(0x400);
  bda = (uchar *) 0x400;
  100994:	c7 45 f4 00 04 00 00 	movl   $0x400,-0xc(%ebp)
  if((p = ((bda[0x0F]<<8)| bda[0x0E]) << 4)){
  10099b:	8b 45 f4             	mov    -0xc(%ebp),%eax
  10099e:	83 c0 0f             	add    $0xf,%eax
  1009a1:	0f b6 00             	movzbl (%eax),%eax
  1009a4:	0f b6 c0             	movzbl %al,%eax
  1009a7:	c1 e0 08             	shl    $0x8,%eax
  1009aa:	89 c2                	mov    %eax,%edx
  1009ac:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1009af:	83 c0 0e             	add    $0xe,%eax
  1009b2:	0f b6 00             	movzbl (%eax),%eax
  1009b5:	0f b6 c0             	movzbl %al,%eax
  1009b8:	09 d0                	or     %edx,%eax
  1009ba:	c1 e0 04             	shl    $0x4,%eax
  1009bd:	89 45 f0             	mov    %eax,-0x10(%ebp)
  1009c0:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
  1009c4:	74 21                	je     1009e7 <mpsearch+0x59>
    if((mp = mpsearch1(p, 1024)))
  1009c6:	83 ec 08             	sub    $0x8,%esp
  1009c9:	68 00 04 00 00       	push   $0x400
  1009ce:	ff 75 f0             	push   -0x10(%ebp)
  1009d1:	e8 54 ff ff ff       	call   10092a <mpsearch1>
  1009d6:	83 c4 10             	add    $0x10,%esp
  1009d9:	89 45 ec             	mov    %eax,-0x14(%ebp)
  1009dc:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
  1009e0:	74 51                	je     100a33 <mpsearch+0xa5>
      return mp;
  1009e2:	8b 45 ec             	mov    -0x14(%ebp),%eax
  1009e5:	eb 61                	jmp    100a48 <mpsearch+0xba>
  } else {
    p = ((bda[0x14]<<8)|bda[0x13])*1024;
  1009e7:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1009ea:	83 c0 14             	add    $0x14,%eax
  1009ed:	0f b6 00             	movzbl (%eax),%eax
  1009f0:	0f b6 c0             	movzbl %al,%eax
  1009f3:	c1 e0 08             	shl    $0x8,%eax
  1009f6:	89 c2                	mov    %eax,%edx
  1009f8:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1009fb:	83 c0 13             	add    $0x13,%eax
  1009fe:	0f b6 00             	movzbl (%eax),%eax
  100a01:	0f b6 c0             	movzbl %al,%eax
  100a04:	09 d0                	or     %edx,%eax
  100a06:	c1 e0 0a             	shl    $0xa,%eax
  100a09:	89 45 f0             	mov    %eax,-0x10(%ebp)
    if((mp = mpsearch1(p-1024, 1024)))
  100a0c:	8b 45 f0             	mov    -0x10(%ebp),%eax
  100a0f:	2d 00 04 00 00       	sub    $0x400,%eax
  100a14:	83 ec 08             	sub    $0x8,%esp
  100a17:	68 00 04 00 00       	push   $0x400
  100a1c:	50                   	push   %eax
  100a1d:	e8 08 ff ff ff       	call   10092a <mpsearch1>
  100a22:	83 c4 10             	add    $0x10,%esp
  100a25:	89 45 ec             	mov    %eax,-0x14(%ebp)
  100a28:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
  100a2c:	74 05                	je     100a33 <mpsearch+0xa5>
      return mp;
  100a2e:	8b 45 ec             	mov    -0x14(%ebp),%eax
  100a31:	eb 15                	jmp    100a48 <mpsearch+0xba>
  }
  return mpsearch1(0xF0000, 0x10000);
  100a33:	83 ec 08             	sub    $0x8,%esp
  100a36:	68 00 00 01 00       	push   $0x10000
  100a3b:	68 00 00 0f 00       	push   $0xf0000
  100a40:	e8 e5 fe ff ff       	call   10092a <mpsearch1>
  100a45:	83 c4 10             	add    $0x10,%esp
}
  100a48:	c9                   	leave
  100a49:	c3                   	ret

00100a4a <mpconfig>:
// Check for correct signature, calculate the checksum and,
// if correct, check the version.
// To do: check extended table checksum.
static struct mpconf*
mpconfig(struct mp **pmp)
{
  100a4a:	55                   	push   %ebp
  100a4b:	89 e5                	mov    %esp,%ebp
  100a4d:	83 ec 18             	sub    $0x18,%esp
  struct mpconf *conf;
  struct mp *mp;

  if((mp = mpsearch()) == 0 || mp->physaddr == 0)
  100a50:	e8 39 ff ff ff       	call   10098e <mpsearch>
  100a55:	89 45 f4             	mov    %eax,-0xc(%ebp)
  100a58:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
  100a5c:	74 0a                	je     100a68 <mpconfig+0x1e>
  100a5e:	8b 45 f4             	mov    -0xc(%ebp),%eax
  100a61:	8b 40 04             	mov    0x4(%eax),%eax
  100a64:	85 c0                	test   %eax,%eax
  100a66:	75 07                	jne    100a6f <mpconfig+0x25>
    return 0;
  100a68:	b8 00 00 00 00       	mov    $0x0,%eax
  100a6d:	eb 75                	jmp    100ae4 <mpconfig+0x9a>
  // conf = (struct mpconf*) P2V((uint) mp->physaddr);
  conf = (struct mpconf*) (uint) mp->physaddr;
  100a6f:	8b 45 f4             	mov    -0xc(%ebp),%eax
  100a72:	8b 40 04             	mov    0x4(%eax),%eax
  100a75:	89 45 f0             	mov    %eax,-0x10(%ebp)
  if(memcmp(conf, "PCMP", 4) != 0)
  100a78:	83 ec 04             	sub    $0x4,%esp
  100a7b:	6a 04                	push   $0x4
  100a7d:	68 05 41 10 00       	push   $0x104105
  100a82:	ff 75 f0             	push   -0x10(%ebp)
  100a85:	e8 63 04 00 00       	call   100eed <memcmp>
  100a8a:	83 c4 10             	add    $0x10,%esp
  100a8d:	85 c0                	test   %eax,%eax
  100a8f:	74 07                	je     100a98 <mpconfig+0x4e>
    return 0;
  100a91:	b8 00 00 00 00       	mov    $0x0,%eax
  100a96:	eb 4c                	jmp    100ae4 <mpconfig+0x9a>
  if(conf->version != 1 && conf->version != 4)
  100a98:	8b 45 f0             	mov    -0x10(%ebp),%eax
  100a9b:	0f b6 40 06          	movzbl 0x6(%eax),%eax
  100a9f:	3c 01                	cmp    $0x1,%al
  100aa1:	74 12                	je     100ab5 <mpconfig+0x6b>
  100aa3:	8b 45 f0             	mov    -0x10(%ebp),%eax
  100aa6:	0f b6 40 06          	movzbl 0x6(%eax),%eax
  100aaa:	3c 04                	cmp    $0x4,%al
  100aac:	74 07                	je     100ab5 <mpconfig+0x6b>
    return 0;
  100aae:	b8 00 00 00 00       	mov    $0x0,%eax
  100ab3:	eb 2f                	jmp    100ae4 <mpconfig+0x9a>
  if(sum((uchar*)conf, conf->length) != 0)
  100ab5:	8b 45 f0             	mov    -0x10(%ebp),%eax
  100ab8:	0f b7 40 04          	movzwl 0x4(%eax),%eax
  100abc:	0f b7 c0             	movzwl %ax,%eax
  100abf:	83 ec 08             	sub    $0x8,%esp
  100ac2:	50                   	push   %eax
  100ac3:	ff 75 f0             	push   -0x10(%ebp)
  100ac6:	e8 27 fe ff ff       	call   1008f2 <sum>
  100acb:	83 c4 10             	add    $0x10,%esp
  100ace:	84 c0                	test   %al,%al
  100ad0:	74 07                	je     100ad9 <mpconfig+0x8f>
    return 0;
  100ad2:	b8 00 00 00 00       	mov    $0x0,%eax
  100ad7:	eb 0b                	jmp    100ae4 <mpconfig+0x9a>
  *pmp = mp;
  100ad9:	8b 45 08             	mov    0x8(%ebp),%eax
  100adc:	8b 55 f4             	mov    -0xc(%ebp),%edx
  100adf:	89 10                	mov    %edx,(%eax)
  return conf;
  100ae1:	8b 45 f0             	mov    -0x10(%ebp),%eax
}
  100ae4:	c9                   	leave
  100ae5:	c3                   	ret

00100ae6 <mpinit>:

void
mpinit(void)
{
  100ae6:	55                   	push   %ebp
  100ae7:	89 e5                	mov    %esp,%ebp
  100ae9:	83 ec 28             	sub    $0x28,%esp
  struct mp *mp;
  struct mpconf *conf;
  struct mpproc *proc;
  struct mpioapic *ioapic;

  if((conf = mpconfig(&mp)) == 0)
  100aec:	83 ec 0c             	sub    $0xc,%esp
  100aef:	8d 45 dc             	lea    -0x24(%ebp),%eax
  100af2:	50                   	push   %eax
  100af3:	e8 52 ff ff ff       	call   100a4a <mpconfig>
  100af8:	83 c4 10             	add    $0x10,%esp
  100afb:	89 45 ec             	mov    %eax,-0x14(%ebp)
  100afe:	83 7d ec 00          	cmpl   $0x0,-0x14(%ebp)
  100b02:	75 0d                	jne    100b11 <mpinit+0x2b>
    panic("Expect to run on an SMP");
  100b04:	83 ec 0c             	sub    $0xc,%esp
  100b07:	68 0a 41 10 00       	push   $0x10410a
  100b0c:	e8 9d f7 ff ff       	call   1002ae <panic>
  ismp = 1;
  100b11:	c7 45 f0 01 00 00 00 	movl   $0x1,-0x10(%ebp)
  lapic = (uint*)conf->lapicaddr;
  100b18:	8b 45 ec             	mov    -0x14(%ebp),%eax
  100b1b:	8b 40 24             	mov    0x24(%eax),%eax
  100b1e:	a3 b4 54 10 00       	mov    %eax,0x1054b4
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
  100b23:	8b 45 ec             	mov    -0x14(%ebp),%eax
  100b26:	83 c0 2c             	add    $0x2c,%eax
  100b29:	89 45 f4             	mov    %eax,-0xc(%ebp)
  100b2c:	8b 45 ec             	mov    -0x14(%ebp),%eax
  100b2f:	0f b7 40 04          	movzwl 0x4(%eax),%eax
  100b33:	0f b7 d0             	movzwl %ax,%edx
  100b36:	8b 45 ec             	mov    -0x14(%ebp),%eax
  100b39:	01 d0                	add    %edx,%eax
  100b3b:	89 45 e8             	mov    %eax,-0x18(%ebp)
  100b3e:	e9 83 00 00 00       	jmp    100bc6 <mpinit+0xe0>
    switch(*p){
  100b43:	8b 45 f4             	mov    -0xc(%ebp),%eax
  100b46:	0f b6 00             	movzbl (%eax),%eax
  100b49:	0f b6 c0             	movzbl %al,%eax
  100b4c:	83 f8 04             	cmp    $0x4,%eax
  100b4f:	7f 6d                	jg     100bbe <mpinit+0xd8>
  100b51:	83 f8 03             	cmp    $0x3,%eax
  100b54:	7d 62                	jge    100bb8 <mpinit+0xd2>
  100b56:	83 f8 02             	cmp    $0x2,%eax
  100b59:	74 45                	je     100ba0 <mpinit+0xba>
  100b5b:	83 f8 02             	cmp    $0x2,%eax
  100b5e:	7f 5e                	jg     100bbe <mpinit+0xd8>
  100b60:	85 c0                	test   %eax,%eax
  100b62:	74 07                	je     100b6b <mpinit+0x85>
  100b64:	83 f8 01             	cmp    $0x1,%eax
  100b67:	74 4f                	je     100bb8 <mpinit+0xd2>
  100b69:	eb 53                	jmp    100bbe <mpinit+0xd8>
    case MPPROC:
      proc = (struct mpproc*)p;
  100b6b:	8b 45 f4             	mov    -0xc(%ebp),%eax
  100b6e:	89 45 e0             	mov    %eax,-0x20(%ebp)
      if(ncpu < NCPU) {
  100b71:	a1 c0 54 10 00       	mov    0x1054c0,%eax
  100b76:	83 f8 07             	cmp    $0x7,%eax
  100b79:	7f 1f                	jg     100b9a <mpinit+0xb4>
        cpus[ncpu].apicid = proc->apicid;  // apicid may differ from ncpu
  100b7b:	a1 c0 54 10 00       	mov    0x1054c0,%eax
  100b80:	8b 55 e0             	mov    -0x20(%ebp),%edx
  100b83:	0f b6 52 01          	movzbl 0x1(%edx),%edx
  100b87:	88 90 b8 54 10 00    	mov    %dl,0x1054b8(%eax)
        ncpu++;
  100b8d:	a1 c0 54 10 00       	mov    0x1054c0,%eax
  100b92:	83 c0 01             	add    $0x1,%eax
  100b95:	a3 c0 54 10 00       	mov    %eax,0x1054c0
      }
      p += sizeof(struct mpproc);
  100b9a:	83 45 f4 14          	addl   $0x14,-0xc(%ebp)
      continue;
  100b9e:	eb 26                	jmp    100bc6 <mpinit+0xe0>
    case MPIOAPIC:
      ioapic = (struct mpioapic*)p;
  100ba0:	8b 45 f4             	mov    -0xc(%ebp),%eax
  100ba3:	89 45 e4             	mov    %eax,-0x1c(%ebp)
      ioapicid = ioapic->apicno;
  100ba6:	8b 45 e4             	mov    -0x1c(%ebp),%eax
  100ba9:	0f b6 40 01          	movzbl 0x1(%eax),%eax
  100bad:	a2 c4 54 10 00       	mov    %al,0x1054c4
      p += sizeof(struct mpioapic);
  100bb2:	83 45 f4 08          	addl   $0x8,-0xc(%ebp)
      continue;
  100bb6:	eb 0e                	jmp    100bc6 <mpinit+0xe0>
    case MPBUS:
    case MPIOINTR:
    case MPLINTR:
      p += 8;
  100bb8:	83 45 f4 08          	addl   $0x8,-0xc(%ebp)
      continue;
  100bbc:	eb 08                	jmp    100bc6 <mpinit+0xe0>
    default:
      ismp = 0;
  100bbe:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
      break;
  100bc5:	90                   	nop
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
  100bc6:	8b 45 f4             	mov    -0xc(%ebp),%eax
  100bc9:	3b 45 e8             	cmp    -0x18(%ebp),%eax
  100bcc:	0f 82 71 ff ff ff    	jb     100b43 <mpinit+0x5d>
    }
  }
  if(!ismp)
  100bd2:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
  100bd6:	75 0d                	jne    100be5 <mpinit+0xff>
    panic("Didn't find a suitable machine");
  100bd8:	83 ec 0c             	sub    $0xc,%esp
  100bdb:	68 24 41 10 00       	push   $0x104124
  100be0:	e8 c9 f6 ff ff       	call   1002ae <panic>

  if(mp->imcrp){
  100be5:	8b 45 dc             	mov    -0x24(%ebp),%eax
  100be8:	0f b6 40 0c          	movzbl 0xc(%eax),%eax
  100bec:	84 c0                	test   %al,%al
  100bee:	74 30                	je     100c20 <mpinit+0x13a>
    // Bochs doesn't support IMCR, so this doesn't run on Bochs.
    // But it would on real hardware.
    outb(0x22, 0x70);   // Select IMCR
  100bf0:	83 ec 08             	sub    $0x8,%esp
  100bf3:	6a 70                	push   $0x70
  100bf5:	6a 22                	push   $0x22
  100bf7:	e8 d7 fc ff ff       	call   1008d3 <outb>
  100bfc:	83 c4 10             	add    $0x10,%esp
    outb(0x23, inb(0x23) | 1);  // Mask external interrupts.
  100bff:	83 ec 0c             	sub    $0xc,%esp
  100c02:	6a 23                	push   $0x23
  100c04:	e8 ad fc ff ff       	call   1008b6 <inb>
  100c09:	83 c4 10             	add    $0x10,%esp
  100c0c:	83 c8 01             	or     $0x1,%eax
  100c0f:	0f b6 c0             	movzbl %al,%eax
  100c12:	83 ec 08             	sub    $0x8,%esp
  100c15:	50                   	push   %eax
  100c16:	6a 23                	push   $0x23
  100c18:	e8 b6 fc ff ff       	call   1008d3 <outb>
  100c1d:	83 c4 10             	add    $0x10,%esp
  }
}
  100c20:	90                   	nop
  100c21:	c9                   	leave
  100c22:	c3                   	ret

00100c23 <outb>:
{
  100c23:	55                   	push   %ebp
  100c24:	89 e5                	mov    %esp,%ebp
  100c26:	83 ec 08             	sub    $0x8,%esp
  100c29:	8b 55 08             	mov    0x8(%ebp),%edx
  100c2c:	8b 45 0c             	mov    0xc(%ebp),%eax
  100c2f:	66 89 55 fc          	mov    %dx,-0x4(%ebp)
  100c33:	88 45 f8             	mov    %al,-0x8(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
  100c36:	0f b6 45 f8          	movzbl -0x8(%ebp),%eax
  100c3a:	0f b7 55 fc          	movzwl -0x4(%ebp),%edx
  100c3e:	ee                   	out    %al,(%dx)
}
  100c3f:	90                   	nop
  100c40:	c9                   	leave
  100c41:	c3                   	ret

00100c42 <picinit>:
#define IO_PIC2         0xA0    // Slave (IRQs 8-15)

// Don't use the 8259A interrupt controllers.  Xv6 assumes SMP hardware.
void
picinit(void)
{
  100c42:	55                   	push   %ebp
  100c43:	89 e5                	mov    %esp,%ebp
  // mask all interrupts
  outb(IO_PIC1+1, 0xFF);
  100c45:	68 ff 00 00 00       	push   $0xff
  100c4a:	6a 21                	push   $0x21
  100c4c:	e8 d2 ff ff ff       	call   100c23 <outb>
  100c51:	83 c4 08             	add    $0x8,%esp
  outb(IO_PIC2+1, 0xFF);
  100c54:	68 ff 00 00 00       	push   $0xff
  100c59:	68 a1 00 00 00       	push   $0xa1
  100c5e:	e8 c0 ff ff ff       	call   100c23 <outb>
  100c63:	83 c4 08             	add    $0x8,%esp
  100c66:	90                   	nop
  100c67:	c9                   	leave
  100c68:	c3                   	ret

00100c69 <inb>:
{
  100c69:	55                   	push   %ebp
  100c6a:	89 e5                	mov    %esp,%ebp
  100c6c:	83 ec 14             	sub    $0x14,%esp
  100c6f:	8b 45 08             	mov    0x8(%ebp),%eax
  100c72:	66 89 45 ec          	mov    %ax,-0x14(%ebp)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
  100c76:	0f b7 45 ec          	movzwl -0x14(%ebp),%eax
  100c7a:	89 c2                	mov    %eax,%edx
  100c7c:	ec                   	in     (%dx),%al
  100c7d:	88 45 ff             	mov    %al,-0x1(%ebp)
  return data;
  100c80:	0f b6 45 ff          	movzbl -0x1(%ebp),%eax
}
  100c84:	c9                   	leave
  100c85:	c3                   	ret

00100c86 <outb>:
{
  100c86:	55                   	push   %ebp
  100c87:	89 e5                	mov    %esp,%ebp
  100c89:	83 ec 08             	sub    $0x8,%esp
  100c8c:	8b 55 08             	mov    0x8(%ebp),%edx
  100c8f:	8b 45 0c             	mov    0xc(%ebp),%eax
  100c92:	66 89 55 fc          	mov    %dx,-0x4(%ebp)
  100c96:	88 45 f8             	mov    %al,-0x8(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
  100c99:	0f b6 45 f8          	movzbl -0x8(%ebp),%eax
  100c9d:	0f b7 55 fc          	movzwl -0x4(%ebp),%edx
  100ca1:	ee                   	out    %al,(%dx)
}
  100ca2:	90                   	nop
  100ca3:	c9                   	leave
  100ca4:	c3                   	ret

00100ca5 <uartinit>:

static int uart;    // is there a uart?

void
uartinit(void)
{
  100ca5:	55                   	push   %ebp
  100ca6:	89 e5                	mov    %esp,%ebp
  100ca8:	83 ec 18             	sub    $0x18,%esp
  char *p;

  // Turn off the FIFO
  outb(COM1+2, 0);
  100cab:	6a 00                	push   $0x0
  100cad:	68 fa 03 00 00       	push   $0x3fa
  100cb2:	e8 cf ff ff ff       	call   100c86 <outb>
  100cb7:	83 c4 08             	add    $0x8,%esp

  // 9600 baud, 8 data bits, 1 stop bit, parity off.
  outb(COM1+3, 0x80);    // Unlock divisor
  100cba:	68 80 00 00 00       	push   $0x80
  100cbf:	68 fb 03 00 00       	push   $0x3fb
  100cc4:	e8 bd ff ff ff       	call   100c86 <outb>
  100cc9:	83 c4 08             	add    $0x8,%esp
  outb(COM1+0, 115200/9600);
  100ccc:	6a 0c                	push   $0xc
  100cce:	68 f8 03 00 00       	push   $0x3f8
  100cd3:	e8 ae ff ff ff       	call   100c86 <outb>
  100cd8:	83 c4 08             	add    $0x8,%esp
  outb(COM1+1, 0);
  100cdb:	6a 00                	push   $0x0
  100cdd:	68 f9 03 00 00       	push   $0x3f9
  100ce2:	e8 9f ff ff ff       	call   100c86 <outb>
  100ce7:	83 c4 08             	add    $0x8,%esp
  outb(COM1+3, 0x03);    // Lock divisor, 8 data bits.
  100cea:	6a 03                	push   $0x3
  100cec:	68 fb 03 00 00       	push   $0x3fb
  100cf1:	e8 90 ff ff ff       	call   100c86 <outb>
  100cf6:	83 c4 08             	add    $0x8,%esp
  outb(COM1+4, 0);
  100cf9:	6a 00                	push   $0x0
  100cfb:	68 fc 03 00 00       	push   $0x3fc
  100d00:	e8 81 ff ff ff       	call   100c86 <outb>
  100d05:	83 c4 08             	add    $0x8,%esp
  outb(COM1+1, 0x01);    // Enable receive interrupts.
  100d08:	6a 01                	push   $0x1
  100d0a:	68 f9 03 00 00       	push   $0x3f9
  100d0f:	e8 72 ff ff ff       	call   100c86 <outb>
  100d14:	83 c4 08             	add    $0x8,%esp

  // If status is 0xFF, no serial port.
  if(inb(COM1+5) == 0xFF)
  100d17:	68 fd 03 00 00       	push   $0x3fd
  100d1c:	e8 48 ff ff ff       	call   100c69 <inb>
  100d21:	83 c4 04             	add    $0x4,%esp
  100d24:	3c ff                	cmp    $0xff,%al
  100d26:	74 61                	je     100d89 <uartinit+0xe4>
    return;
  uart = 1;
  100d28:	c7 05 c8 54 10 00 01 	movl   $0x1,0x1054c8
  100d2f:	00 00 00 

  // Acknowledge pre-existing interrupt conditions;
  // enable interrupts.
  inb(COM1+2);
  100d32:	68 fa 03 00 00       	push   $0x3fa
  100d37:	e8 2d ff ff ff       	call   100c69 <inb>
  100d3c:	83 c4 04             	add    $0x4,%esp
  inb(COM1+0);
  100d3f:	68 f8 03 00 00       	push   $0x3f8
  100d44:	e8 20 ff ff ff       	call   100c69 <inb>
  100d49:	83 c4 04             	add    $0x4,%esp
  ioapicenable(IRQ_COM1, 0);
  100d4c:	83 ec 08             	sub    $0x8,%esp
  100d4f:	6a 00                	push   $0x0
  100d51:	6a 04                	push   $0x4
  100d53:	e8 40 f8 ff ff       	call   100598 <ioapicenable>
  100d58:	83 c4 10             	add    $0x10,%esp

  // Announce that we're here.
  for(p="xv6...\n"; *p; p++)
  100d5b:	c7 45 f4 43 41 10 00 	movl   $0x104143,-0xc(%ebp)
  100d62:	eb 19                	jmp    100d7d <uartinit+0xd8>
    uartputc(*p);
  100d64:	8b 45 f4             	mov    -0xc(%ebp),%eax
  100d67:	0f b6 00             	movzbl (%eax),%eax
  100d6a:	0f be c0             	movsbl %al,%eax
  100d6d:	83 ec 0c             	sub    $0xc,%esp
  100d70:	50                   	push   %eax
  100d71:	e8 16 00 00 00       	call   100d8c <uartputc>
  100d76:	83 c4 10             	add    $0x10,%esp
  for(p="xv6...\n"; *p; p++)
  100d79:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  100d7d:	8b 45 f4             	mov    -0xc(%ebp),%eax
  100d80:	0f b6 00             	movzbl (%eax),%eax
  100d83:	84 c0                	test   %al,%al
  100d85:	75 dd                	jne    100d64 <uartinit+0xbf>
  100d87:	eb 01                	jmp    100d8a <uartinit+0xe5>
    return;
  100d89:	90                   	nop
}
  100d8a:	c9                   	leave
  100d8b:	c3                   	ret

00100d8c <uartputc>:

void
uartputc(int c)
{
  100d8c:	55                   	push   %ebp
  100d8d:	89 e5                	mov    %esp,%ebp
  100d8f:	83 ec 10             	sub    $0x10,%esp
  int i;

  if(!uart)
  100d92:	a1 c8 54 10 00       	mov    0x1054c8,%eax
  100d97:	85 c0                	test   %eax,%eax
  100d99:	74 40                	je     100ddb <uartputc+0x4f>
    return;
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++);
  100d9b:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
  100da2:	eb 04                	jmp    100da8 <uartputc+0x1c>
  100da4:	83 45 fc 01          	addl   $0x1,-0x4(%ebp)
  100da8:	83 7d fc 7f          	cmpl   $0x7f,-0x4(%ebp)
  100dac:	7f 17                	jg     100dc5 <uartputc+0x39>
  100dae:	68 fd 03 00 00       	push   $0x3fd
  100db3:	e8 b1 fe ff ff       	call   100c69 <inb>
  100db8:	83 c4 04             	add    $0x4,%esp
  100dbb:	0f b6 c0             	movzbl %al,%eax
  100dbe:	83 e0 20             	and    $0x20,%eax
  100dc1:	85 c0                	test   %eax,%eax
  100dc3:	74 df                	je     100da4 <uartputc+0x18>
  outb(COM1+0, c);
  100dc5:	8b 45 08             	mov    0x8(%ebp),%eax
  100dc8:	0f b6 c0             	movzbl %al,%eax
  100dcb:	50                   	push   %eax
  100dcc:	68 f8 03 00 00       	push   $0x3f8
  100dd1:	e8 b0 fe ff ff       	call   100c86 <outb>
  100dd6:	83 c4 08             	add    $0x8,%esp
  100dd9:	eb 01                	jmp    100ddc <uartputc+0x50>
    return;
  100ddb:	90                   	nop
}
  100ddc:	c9                   	leave
  100ddd:	c3                   	ret

00100dde <uartgetc>:


static int
uartgetc(void)
{
  100dde:	55                   	push   %ebp
  100ddf:	89 e5                	mov    %esp,%ebp
  if(!uart)
  100de1:	a1 c8 54 10 00       	mov    0x1054c8,%eax
  100de6:	85 c0                	test   %eax,%eax
  100de8:	75 07                	jne    100df1 <uartgetc+0x13>
    return -1;
  100dea:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  100def:	eb 2e                	jmp    100e1f <uartgetc+0x41>
  if(!(inb(COM1+5) & 0x01))
  100df1:	68 fd 03 00 00       	push   $0x3fd
  100df6:	e8 6e fe ff ff       	call   100c69 <inb>
  100dfb:	83 c4 04             	add    $0x4,%esp
  100dfe:	0f b6 c0             	movzbl %al,%eax
  100e01:	83 e0 01             	and    $0x1,%eax
  100e04:	85 c0                	test   %eax,%eax
  100e06:	75 07                	jne    100e0f <uartgetc+0x31>
    return -1;
  100e08:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  100e0d:	eb 10                	jmp    100e1f <uartgetc+0x41>
  return inb(COM1+0);
  100e0f:	68 f8 03 00 00       	push   $0x3f8
  100e14:	e8 50 fe ff ff       	call   100c69 <inb>
  100e19:	83 c4 04             	add    $0x4,%esp
  100e1c:	0f b6 c0             	movzbl %al,%eax
}
  100e1f:	c9                   	leave
  100e20:	c3                   	ret

00100e21 <uartintr>:

void
uartintr(void)
{
  100e21:	55                   	push   %ebp
  100e22:	89 e5                	mov    %esp,%ebp
  100e24:	83 ec 08             	sub    $0x8,%esp
  consoleintr(uartgetc);
  100e27:	83 ec 0c             	sub    $0xc,%esp
  100e2a:	68 de 0d 10 00       	push   $0x100dde
  100e2f:	e8 50 f5 ff ff       	call   100384 <consoleintr>
  100e34:	83 c4 10             	add    $0x10,%esp
  100e37:	90                   	nop
  100e38:	c9                   	leave
  100e39:	c3                   	ret

00100e3a <stosb>:
{
  100e3a:	55                   	push   %ebp
  100e3b:	89 e5                	mov    %esp,%ebp
  100e3d:	57                   	push   %edi
  100e3e:	53                   	push   %ebx
  asm volatile("cld; rep stosb" :
  100e3f:	8b 4d 08             	mov    0x8(%ebp),%ecx
  100e42:	8b 55 10             	mov    0x10(%ebp),%edx
  100e45:	8b 45 0c             	mov    0xc(%ebp),%eax
  100e48:	89 cb                	mov    %ecx,%ebx
  100e4a:	89 df                	mov    %ebx,%edi
  100e4c:	89 d1                	mov    %edx,%ecx
  100e4e:	fc                   	cld
  100e4f:	f3 aa                	rep stos %al,%es:(%edi)
  100e51:	89 ca                	mov    %ecx,%edx
  100e53:	89 fb                	mov    %edi,%ebx
  100e55:	89 5d 08             	mov    %ebx,0x8(%ebp)
  100e58:	89 55 10             	mov    %edx,0x10(%ebp)
}
  100e5b:	90                   	nop
  100e5c:	5b                   	pop    %ebx
  100e5d:	5f                   	pop    %edi
  100e5e:	5d                   	pop    %ebp
  100e5f:	c3                   	ret

00100e60 <stosl>:
{
  100e60:	55                   	push   %ebp
  100e61:	89 e5                	mov    %esp,%ebp
  100e63:	57                   	push   %edi
  100e64:	53                   	push   %ebx
  asm volatile("cld; rep stosl" :
  100e65:	8b 4d 08             	mov    0x8(%ebp),%ecx
  100e68:	8b 55 10             	mov    0x10(%ebp),%edx
  100e6b:	8b 45 0c             	mov    0xc(%ebp),%eax
  100e6e:	89 cb                	mov    %ecx,%ebx
  100e70:	89 df                	mov    %ebx,%edi
  100e72:	89 d1                	mov    %edx,%ecx
  100e74:	fc                   	cld
  100e75:	f3 ab                	rep stos %eax,%es:(%edi)
  100e77:	89 ca                	mov    %ecx,%edx
  100e79:	89 fb                	mov    %edi,%ebx
  100e7b:	89 5d 08             	mov    %ebx,0x8(%ebp)
  100e7e:	89 55 10             	mov    %edx,0x10(%ebp)
}
  100e81:	90                   	nop
  100e82:	5b                   	pop    %ebx
  100e83:	5f                   	pop    %edi
  100e84:	5d                   	pop    %ebp
  100e85:	c3                   	ret

00100e86 <memset>:
#include "types.h"
#include "x86.h"

void*
memset(void *dst, int c, uint n)
{
  100e86:	55                   	push   %ebp
  100e87:	89 e5                	mov    %esp,%ebp
  if ((int)dst%4 == 0 && n%4 == 0){
  100e89:	8b 45 08             	mov    0x8(%ebp),%eax
  100e8c:	83 e0 03             	and    $0x3,%eax
  100e8f:	85 c0                	test   %eax,%eax
  100e91:	75 43                	jne    100ed6 <memset+0x50>
  100e93:	8b 45 10             	mov    0x10(%ebp),%eax
  100e96:	83 e0 03             	and    $0x3,%eax
  100e99:	85 c0                	test   %eax,%eax
  100e9b:	75 39                	jne    100ed6 <memset+0x50>
    c &= 0xFF;
  100e9d:	81 65 0c ff 00 00 00 	andl   $0xff,0xc(%ebp)
    stosl(dst, (c<<24)|(c<<16)|(c<<8)|c, n/4);
  100ea4:	8b 45 10             	mov    0x10(%ebp),%eax
  100ea7:	c1 e8 02             	shr    $0x2,%eax
  100eaa:	89 c1                	mov    %eax,%ecx
  100eac:	8b 45 0c             	mov    0xc(%ebp),%eax
  100eaf:	c1 e0 18             	shl    $0x18,%eax
  100eb2:	89 c2                	mov    %eax,%edx
  100eb4:	8b 45 0c             	mov    0xc(%ebp),%eax
  100eb7:	c1 e0 10             	shl    $0x10,%eax
  100eba:	09 c2                	or     %eax,%edx
  100ebc:	8b 45 0c             	mov    0xc(%ebp),%eax
  100ebf:	c1 e0 08             	shl    $0x8,%eax
  100ec2:	09 d0                	or     %edx,%eax
  100ec4:	0b 45 0c             	or     0xc(%ebp),%eax
  100ec7:	51                   	push   %ecx
  100ec8:	50                   	push   %eax
  100ec9:	ff 75 08             	push   0x8(%ebp)
  100ecc:	e8 8f ff ff ff       	call   100e60 <stosl>
  100ed1:	83 c4 0c             	add    $0xc,%esp
  100ed4:	eb 12                	jmp    100ee8 <memset+0x62>
  } else
    stosb(dst, c, n);
  100ed6:	8b 45 10             	mov    0x10(%ebp),%eax
  100ed9:	50                   	push   %eax
  100eda:	ff 75 0c             	push   0xc(%ebp)
  100edd:	ff 75 08             	push   0x8(%ebp)
  100ee0:	e8 55 ff ff ff       	call   100e3a <stosb>
  100ee5:	83 c4 0c             	add    $0xc,%esp
  return dst;
  100ee8:	8b 45 08             	mov    0x8(%ebp),%eax
}
  100eeb:	c9                   	leave
  100eec:	c3                   	ret

00100eed <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
  100eed:	55                   	push   %ebp
  100eee:	89 e5                	mov    %esp,%ebp
  100ef0:	83 ec 10             	sub    $0x10,%esp
  const uchar *s1, *s2;

  s1 = v1;
  100ef3:	8b 45 08             	mov    0x8(%ebp),%eax
  100ef6:	89 45 fc             	mov    %eax,-0x4(%ebp)
  s2 = v2;
  100ef9:	8b 45 0c             	mov    0xc(%ebp),%eax
  100efc:	89 45 f8             	mov    %eax,-0x8(%ebp)
  while(n-- > 0){
  100eff:	eb 2e                	jmp    100f2f <memcmp+0x42>
    if(*s1 != *s2)
  100f01:	8b 45 fc             	mov    -0x4(%ebp),%eax
  100f04:	0f b6 10             	movzbl (%eax),%edx
  100f07:	8b 45 f8             	mov    -0x8(%ebp),%eax
  100f0a:	0f b6 00             	movzbl (%eax),%eax
  100f0d:	38 c2                	cmp    %al,%dl
  100f0f:	74 16                	je     100f27 <memcmp+0x3a>
      return *s1 - *s2;
  100f11:	8b 45 fc             	mov    -0x4(%ebp),%eax
  100f14:	0f b6 00             	movzbl (%eax),%eax
  100f17:	0f b6 d0             	movzbl %al,%edx
  100f1a:	8b 45 f8             	mov    -0x8(%ebp),%eax
  100f1d:	0f b6 00             	movzbl (%eax),%eax
  100f20:	0f b6 c0             	movzbl %al,%eax
  100f23:	29 c2                	sub    %eax,%edx
  100f25:	eb 1a                	jmp    100f41 <memcmp+0x54>
    s1++, s2++;
  100f27:	83 45 fc 01          	addl   $0x1,-0x4(%ebp)
  100f2b:	83 45 f8 01          	addl   $0x1,-0x8(%ebp)
  while(n-- > 0){
  100f2f:	8b 45 10             	mov    0x10(%ebp),%eax
  100f32:	8d 50 ff             	lea    -0x1(%eax),%edx
  100f35:	89 55 10             	mov    %edx,0x10(%ebp)
  100f38:	85 c0                	test   %eax,%eax
  100f3a:	75 c5                	jne    100f01 <memcmp+0x14>
  }

  return 0;
  100f3c:	ba 00 00 00 00       	mov    $0x0,%edx
}
  100f41:	89 d0                	mov    %edx,%eax
  100f43:	c9                   	leave
  100f44:	c3                   	ret

00100f45 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
  100f45:	55                   	push   %ebp
  100f46:	89 e5                	mov    %esp,%ebp
  100f48:	83 ec 10             	sub    $0x10,%esp
  const char *s;
  char *d;

  s = src;
  100f4b:	8b 45 0c             	mov    0xc(%ebp),%eax
  100f4e:	89 45 fc             	mov    %eax,-0x4(%ebp)
  d = dst;
  100f51:	8b 45 08             	mov    0x8(%ebp),%eax
  100f54:	89 45 f8             	mov    %eax,-0x8(%ebp)
  if(s < d && s + n > d){
  100f57:	8b 45 fc             	mov    -0x4(%ebp),%eax
  100f5a:	3b 45 f8             	cmp    -0x8(%ebp),%eax
  100f5d:	73 54                	jae    100fb3 <memmove+0x6e>
  100f5f:	8b 55 fc             	mov    -0x4(%ebp),%edx
  100f62:	8b 45 10             	mov    0x10(%ebp),%eax
  100f65:	01 d0                	add    %edx,%eax
  100f67:	39 45 f8             	cmp    %eax,-0x8(%ebp)
  100f6a:	73 47                	jae    100fb3 <memmove+0x6e>
    s += n;
  100f6c:	8b 45 10             	mov    0x10(%ebp),%eax
  100f6f:	01 45 fc             	add    %eax,-0x4(%ebp)
    d += n;
  100f72:	8b 45 10             	mov    0x10(%ebp),%eax
  100f75:	01 45 f8             	add    %eax,-0x8(%ebp)
    while(n-- > 0)
  100f78:	eb 13                	jmp    100f8d <memmove+0x48>
      *--d = *--s;
  100f7a:	83 6d fc 01          	subl   $0x1,-0x4(%ebp)
  100f7e:	83 6d f8 01          	subl   $0x1,-0x8(%ebp)
  100f82:	8b 45 fc             	mov    -0x4(%ebp),%eax
  100f85:	0f b6 10             	movzbl (%eax),%edx
  100f88:	8b 45 f8             	mov    -0x8(%ebp),%eax
  100f8b:	88 10                	mov    %dl,(%eax)
    while(n-- > 0)
  100f8d:	8b 45 10             	mov    0x10(%ebp),%eax
  100f90:	8d 50 ff             	lea    -0x1(%eax),%edx
  100f93:	89 55 10             	mov    %edx,0x10(%ebp)
  100f96:	85 c0                	test   %eax,%eax
  100f98:	75 e0                	jne    100f7a <memmove+0x35>
  if(s < d && s + n > d){
  100f9a:	eb 24                	jmp    100fc0 <memmove+0x7b>
  } else
    while(n-- > 0)
      *d++ = *s++;
  100f9c:	8b 55 fc             	mov    -0x4(%ebp),%edx
  100f9f:	8d 42 01             	lea    0x1(%edx),%eax
  100fa2:	89 45 fc             	mov    %eax,-0x4(%ebp)
  100fa5:	8b 45 f8             	mov    -0x8(%ebp),%eax
  100fa8:	8d 48 01             	lea    0x1(%eax),%ecx
  100fab:	89 4d f8             	mov    %ecx,-0x8(%ebp)
  100fae:	0f b6 12             	movzbl (%edx),%edx
  100fb1:	88 10                	mov    %dl,(%eax)
    while(n-- > 0)
  100fb3:	8b 45 10             	mov    0x10(%ebp),%eax
  100fb6:	8d 50 ff             	lea    -0x1(%eax),%edx
  100fb9:	89 55 10             	mov    %edx,0x10(%ebp)
  100fbc:	85 c0                	test   %eax,%eax
  100fbe:	75 dc                	jne    100f9c <memmove+0x57>

  return dst;
  100fc0:	8b 45 08             	mov    0x8(%ebp),%eax
}
  100fc3:	c9                   	leave
  100fc4:	c3                   	ret

00100fc5 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
  100fc5:	55                   	push   %ebp
  100fc6:	89 e5                	mov    %esp,%ebp
  return memmove(dst, src, n);
  100fc8:	ff 75 10             	push   0x10(%ebp)
  100fcb:	ff 75 0c             	push   0xc(%ebp)
  100fce:	ff 75 08             	push   0x8(%ebp)
  100fd1:	e8 6f ff ff ff       	call   100f45 <memmove>
  100fd6:	83 c4 0c             	add    $0xc,%esp
}
  100fd9:	c9                   	leave
  100fda:	c3                   	ret

00100fdb <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  100fdb:	55                   	push   %ebp
  100fdc:	89 e5                	mov    %esp,%ebp
  while(n > 0 && *p && *p == *q)
  100fde:	eb 0c                	jmp    100fec <strncmp+0x11>
    n--, p++, q++;
  100fe0:	83 6d 10 01          	subl   $0x1,0x10(%ebp)
  100fe4:	83 45 08 01          	addl   $0x1,0x8(%ebp)
  100fe8:	83 45 0c 01          	addl   $0x1,0xc(%ebp)
  while(n > 0 && *p && *p == *q)
  100fec:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
  100ff0:	74 1a                	je     10100c <strncmp+0x31>
  100ff2:	8b 45 08             	mov    0x8(%ebp),%eax
  100ff5:	0f b6 00             	movzbl (%eax),%eax
  100ff8:	84 c0                	test   %al,%al
  100ffa:	74 10                	je     10100c <strncmp+0x31>
  100ffc:	8b 45 08             	mov    0x8(%ebp),%eax
  100fff:	0f b6 10             	movzbl (%eax),%edx
  101002:	8b 45 0c             	mov    0xc(%ebp),%eax
  101005:	0f b6 00             	movzbl (%eax),%eax
  101008:	38 c2                	cmp    %al,%dl
  10100a:	74 d4                	je     100fe0 <strncmp+0x5>
  if(n == 0)
  10100c:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
  101010:	75 07                	jne    101019 <strncmp+0x3e>
    return 0;
  101012:	ba 00 00 00 00       	mov    $0x0,%edx
  101017:	eb 14                	jmp    10102d <strncmp+0x52>
  return (uchar)*p - (uchar)*q;
  101019:	8b 45 08             	mov    0x8(%ebp),%eax
  10101c:	0f b6 00             	movzbl (%eax),%eax
  10101f:	0f b6 d0             	movzbl %al,%edx
  101022:	8b 45 0c             	mov    0xc(%ebp),%eax
  101025:	0f b6 00             	movzbl (%eax),%eax
  101028:	0f b6 c0             	movzbl %al,%eax
  10102b:	29 c2                	sub    %eax,%edx
}
  10102d:	89 d0                	mov    %edx,%eax
  10102f:	5d                   	pop    %ebp
  101030:	c3                   	ret

00101031 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  101031:	55                   	push   %ebp
  101032:	89 e5                	mov    %esp,%ebp
  101034:	83 ec 10             	sub    $0x10,%esp
  char *os;

  os = s;
  101037:	8b 45 08             	mov    0x8(%ebp),%eax
  10103a:	89 45 fc             	mov    %eax,-0x4(%ebp)
  while(n-- > 0 && (*s++ = *t++) != 0)
  10103d:	90                   	nop
  10103e:	8b 45 10             	mov    0x10(%ebp),%eax
  101041:	8d 50 ff             	lea    -0x1(%eax),%edx
  101044:	89 55 10             	mov    %edx,0x10(%ebp)
  101047:	85 c0                	test   %eax,%eax
  101049:	7e 2c                	jle    101077 <strncpy+0x46>
  10104b:	8b 55 0c             	mov    0xc(%ebp),%edx
  10104e:	8d 42 01             	lea    0x1(%edx),%eax
  101051:	89 45 0c             	mov    %eax,0xc(%ebp)
  101054:	8b 45 08             	mov    0x8(%ebp),%eax
  101057:	8d 48 01             	lea    0x1(%eax),%ecx
  10105a:	89 4d 08             	mov    %ecx,0x8(%ebp)
  10105d:	0f b6 12             	movzbl (%edx),%edx
  101060:	88 10                	mov    %dl,(%eax)
  101062:	0f b6 00             	movzbl (%eax),%eax
  101065:	84 c0                	test   %al,%al
  101067:	75 d5                	jne    10103e <strncpy+0xd>
    ;
  while(n-- > 0)
  101069:	eb 0c                	jmp    101077 <strncpy+0x46>
    *s++ = 0;
  10106b:	8b 45 08             	mov    0x8(%ebp),%eax
  10106e:	8d 50 01             	lea    0x1(%eax),%edx
  101071:	89 55 08             	mov    %edx,0x8(%ebp)
  101074:	c6 00 00             	movb   $0x0,(%eax)
  while(n-- > 0)
  101077:	8b 45 10             	mov    0x10(%ebp),%eax
  10107a:	8d 50 ff             	lea    -0x1(%eax),%edx
  10107d:	89 55 10             	mov    %edx,0x10(%ebp)
  101080:	85 c0                	test   %eax,%eax
  101082:	7f e7                	jg     10106b <strncpy+0x3a>
  return os;
  101084:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
  101087:	c9                   	leave
  101088:	c3                   	ret

00101089 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
  101089:	55                   	push   %ebp
  10108a:	89 e5                	mov    %esp,%ebp
  10108c:	83 ec 10             	sub    $0x10,%esp
  char *os;

  os = s;
  10108f:	8b 45 08             	mov    0x8(%ebp),%eax
  101092:	89 45 fc             	mov    %eax,-0x4(%ebp)
  if(n <= 0)
  101095:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
  101099:	7f 05                	jg     1010a0 <safestrcpy+0x17>
    return os;
  10109b:	8b 45 fc             	mov    -0x4(%ebp),%eax
  10109e:	eb 32                	jmp    1010d2 <safestrcpy+0x49>
  while(--n > 0 && (*s++ = *t++) != 0)
  1010a0:	90                   	nop
  1010a1:	83 6d 10 01          	subl   $0x1,0x10(%ebp)
  1010a5:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
  1010a9:	7e 1e                	jle    1010c9 <safestrcpy+0x40>
  1010ab:	8b 55 0c             	mov    0xc(%ebp),%edx
  1010ae:	8d 42 01             	lea    0x1(%edx),%eax
  1010b1:	89 45 0c             	mov    %eax,0xc(%ebp)
  1010b4:	8b 45 08             	mov    0x8(%ebp),%eax
  1010b7:	8d 48 01             	lea    0x1(%eax),%ecx
  1010ba:	89 4d 08             	mov    %ecx,0x8(%ebp)
  1010bd:	0f b6 12             	movzbl (%edx),%edx
  1010c0:	88 10                	mov    %dl,(%eax)
  1010c2:	0f b6 00             	movzbl (%eax),%eax
  1010c5:	84 c0                	test   %al,%al
  1010c7:	75 d8                	jne    1010a1 <safestrcpy+0x18>
    ;
  *s = 0;
  1010c9:	8b 45 08             	mov    0x8(%ebp),%eax
  1010cc:	c6 00 00             	movb   $0x0,(%eax)
  return os;
  1010cf:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
  1010d2:	c9                   	leave
  1010d3:	c3                   	ret

001010d4 <strlen>:

int
strlen(const char *s)
{
  1010d4:	55                   	push   %ebp
  1010d5:	89 e5                	mov    %esp,%ebp
  1010d7:	83 ec 10             	sub    $0x10,%esp
  int n;

  for(n = 0; s[n]; n++)
  1010da:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
  1010e1:	eb 04                	jmp    1010e7 <strlen+0x13>
  1010e3:	83 45 fc 01          	addl   $0x1,-0x4(%ebp)
  1010e7:	8b 55 fc             	mov    -0x4(%ebp),%edx
  1010ea:	8b 45 08             	mov    0x8(%ebp),%eax
  1010ed:	01 d0                	add    %edx,%eax
  1010ef:	0f b6 00             	movzbl (%eax),%eax
  1010f2:	84 c0                	test   %al,%al
  1010f4:	75 ed                	jne    1010e3 <strlen+0xf>
    ;
  return n;
  1010f6:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
  1010f9:	c9                   	leave
  1010fa:	c3                   	ret

001010fb <readeflags>:
{
  1010fb:	55                   	push   %ebp
  1010fc:	89 e5                	mov    %esp,%ebp
  1010fe:	83 ec 10             	sub    $0x10,%esp
  asm volatile("pushfl; popl %0" : "=r" (eflags));
  101101:	9c                   	pushf
  101102:	58                   	pop    %eax
  101103:	89 45 fc             	mov    %eax,-0x4(%ebp)
  return eflags;
  101106:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
  101109:	c9                   	leave
  10110a:	c3                   	ret

0010110b <cpuid>:
#include "x86.h"
#include "proc.h"

// Must be called with interrupts disabled
int
cpuid() {
  10110b:	55                   	push   %ebp
  10110c:	89 e5                	mov    %esp,%ebp
  10110e:	83 ec 08             	sub    $0x8,%esp
  return mycpu()-cpus;
  101111:	e8 07 00 00 00       	call   10111d <mycpu>
  101116:	2d b8 54 10 00       	sub    $0x1054b8,%eax
}
  10111b:	c9                   	leave
  10111c:	c3                   	ret

0010111d <mycpu>:

// Must be called with interrupts disabled to avoid the caller being
// rescheduled between reading lapicid and running through the loop.
struct cpu*
mycpu(void)
{
  10111d:	55                   	push   %ebp
  10111e:	89 e5                	mov    %esp,%ebp
  101120:	83 ec 18             	sub    $0x18,%esp
  int apicid, i;
  
  if(readeflags()&FL_IF)
  101123:	e8 d3 ff ff ff       	call   1010fb <readeflags>
  101128:	25 00 02 00 00       	and    $0x200,%eax
  10112d:	85 c0                	test   %eax,%eax
  10112f:	74 0d                	je     10113e <mycpu+0x21>
    panic("mycpu called with interrupts enabled\n");
  101131:	83 ec 0c             	sub    $0xc,%esp
  101134:	68 4c 41 10 00       	push   $0x10414c
  101139:	e8 70 f1 ff ff       	call   1002ae <panic>
  
  apicid = lapicid();
  10113e:	e8 d0 f5 ff ff       	call   100713 <lapicid>
  101143:	89 45 f0             	mov    %eax,-0x10(%ebp)
  // APIC IDs are not guaranteed to be contiguous. Maybe we should have
  // a reverse map, or reserve a register to store &cpus[i].
  for (i = 0; i < ncpu; ++i) {
  101146:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  10114d:	eb 21                	jmp    101170 <mycpu+0x53>
    if (cpus[i].apicid == apicid)
  10114f:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101152:	05 b8 54 10 00       	add    $0x1054b8,%eax
  101157:	0f b6 00             	movzbl (%eax),%eax
  10115a:	0f b6 c0             	movzbl %al,%eax
  10115d:	39 45 f0             	cmp    %eax,-0x10(%ebp)
  101160:	75 0a                	jne    10116c <mycpu+0x4f>
      return &cpus[i];
  101162:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101165:	05 b8 54 10 00       	add    $0x1054b8,%eax
  10116a:	eb 1b                	jmp    101187 <mycpu+0x6a>
  for (i = 0; i < ncpu; ++i) {
  10116c:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  101170:	a1 c0 54 10 00       	mov    0x1054c0,%eax
  101175:	39 45 f4             	cmp    %eax,-0xc(%ebp)
  101178:	7c d5                	jl     10114f <mycpu+0x32>
  }
  panic("unknown apicid\n");
  10117a:	83 ec 0c             	sub    $0xc,%esp
  10117d:	68 72 41 10 00       	push   $0x104172
  101182:	e8 27 f1 ff ff       	call   1002ae <panic>
  101187:	c9                   	leave
  101188:	c3                   	ret

00101189 <getcallerpcs>:
// #include "memlayout.h"

// Record the current call stack in pcs[] by following the %ebp chain.
void
getcallerpcs(void *v, uint pcs[])
{
  101189:	55                   	push   %ebp
  10118a:	89 e5                	mov    %esp,%ebp
  10118c:	83 ec 10             	sub    $0x10,%esp
  uint *ebp;
  int i;

  ebp = (uint*)v - 2;
  10118f:	8b 45 08             	mov    0x8(%ebp),%eax
  101192:	83 e8 08             	sub    $0x8,%eax
  101195:	89 45 fc             	mov    %eax,-0x4(%ebp)
  for(i = 0; i < 10; i++){
  101198:	c7 45 f8 00 00 00 00 	movl   $0x0,-0x8(%ebp)
  10119f:	eb 2f                	jmp    1011d0 <getcallerpcs+0x47>
    // if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
    if(ebp == 0 || ebp == (uint*)0xffffffff)
  1011a1:	83 7d fc 00          	cmpl   $0x0,-0x4(%ebp)
  1011a5:	74 4a                	je     1011f1 <getcallerpcs+0x68>
  1011a7:	83 7d fc ff          	cmpl   $0xffffffff,-0x4(%ebp)
  1011ab:	74 44                	je     1011f1 <getcallerpcs+0x68>
      break;
    pcs[i] = ebp[1];     // saved %eip
  1011ad:	8b 45 f8             	mov    -0x8(%ebp),%eax
  1011b0:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
  1011b7:	8b 45 0c             	mov    0xc(%ebp),%eax
  1011ba:	01 c2                	add    %eax,%edx
  1011bc:	8b 45 fc             	mov    -0x4(%ebp),%eax
  1011bf:	8b 40 04             	mov    0x4(%eax),%eax
  1011c2:	89 02                	mov    %eax,(%edx)
    ebp = (uint*)ebp[0]; // saved %ebp
  1011c4:	8b 45 fc             	mov    -0x4(%ebp),%eax
  1011c7:	8b 00                	mov    (%eax),%eax
  1011c9:	89 45 fc             	mov    %eax,-0x4(%ebp)
  for(i = 0; i < 10; i++){
  1011cc:	83 45 f8 01          	addl   $0x1,-0x8(%ebp)
  1011d0:	83 7d f8 09          	cmpl   $0x9,-0x8(%ebp)
  1011d4:	7e cb                	jle    1011a1 <getcallerpcs+0x18>
  }
  for(; i < 10; i++)
  1011d6:	eb 19                	jmp    1011f1 <getcallerpcs+0x68>
    pcs[i] = 0;
  1011d8:	8b 45 f8             	mov    -0x8(%ebp),%eax
  1011db:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
  1011e2:	8b 45 0c             	mov    0xc(%ebp),%eax
  1011e5:	01 d0                	add    %edx,%eax
  1011e7:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
  1011ed:	83 45 f8 01          	addl   $0x1,-0x8(%ebp)
  1011f1:	83 7d f8 09          	cmpl   $0x9,-0x8(%ebp)
  1011f5:	7e e1                	jle    1011d8 <getcallerpcs+0x4f>
  1011f7:	90                   	nop
  1011f8:	90                   	nop
  1011f9:	c9                   	leave
  1011fa:	c3                   	ret

001011fb <alltraps>:

  # vectors.S sends all traps here.
.globl alltraps
alltraps:
  # Build trap frame.
  pushal
  1011fb:	60                   	pusha
  
  # Call trap(tf), where tf=%esp
  pushl %esp
  1011fc:	54                   	push   %esp
  call trap
  1011fd:	e8 41 01 00 00       	call   101343 <trap>
  addl $4, %esp
  101202:	83 c4 04             	add    $0x4,%esp

00101205 <trapret>:

  # Return falls through to trapret...
.globl trapret
trapret:
  popal
  101205:	61                   	popa
  addl $0x8, %esp  # trapno and errcode
  101206:	83 c4 08             	add    $0x8,%esp
  iret
  101209:	cf                   	iret

0010120a <lidt>:
{
  10120a:	55                   	push   %ebp
  10120b:	89 e5                	mov    %esp,%ebp
  10120d:	83 ec 10             	sub    $0x10,%esp
  pd[0] = size-1;
  101210:	8b 45 0c             	mov    0xc(%ebp),%eax
  101213:	83 e8 01             	sub    $0x1,%eax
  101216:	66 89 45 fa          	mov    %ax,-0x6(%ebp)
  pd[1] = (uint)p;
  10121a:	8b 45 08             	mov    0x8(%ebp),%eax
  10121d:	66 89 45 fc          	mov    %ax,-0x4(%ebp)
  pd[2] = (uint)p >> 16;
  101221:	8b 45 08             	mov    0x8(%ebp),%eax
  101224:	c1 e8 10             	shr    $0x10,%eax
  101227:	66 89 45 fe          	mov    %ax,-0x2(%ebp)
  asm volatile("lidt (%0)" : : "r" (pd));
  10122b:	8d 45 fa             	lea    -0x6(%ebp),%eax
  10122e:	0f 01 18             	lidtl  (%eax)
}
  101231:	90                   	nop
  101232:	c9                   	leave
  101233:	c3                   	ret

00101234 <rcr2>:

static inline uint
rcr2(void)
{
  101234:	55                   	push   %ebp
  101235:	89 e5                	mov    %esp,%ebp
  101237:	83 ec 10             	sub    $0x10,%esp
  uint val;
  asm volatile("movl %%cr2,%0" : "=r" (val));
  10123a:	0f 20 d0             	mov    %cr2,%eax
  10123d:	89 45 fc             	mov    %eax,-0x4(%ebp)
  return val;
  101240:	8b 45 fc             	mov    -0x4(%ebp),%eax
}
  101243:	c9                   	leave
  101244:	c3                   	ret

00101245 <tvinit>:
extern uint vectors[];  // in vectors.S: array of 256 entry pointers
uint ticks;

void
tvinit(void)
{
  101245:	55                   	push   %ebp
  101246:	89 e5                	mov    %esp,%ebp
  101248:	83 ec 10             	sub    $0x10,%esp
  int i;

  for(i = 0; i < 256; i++)
  10124b:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%ebp)
  101252:	e9 c3 00 00 00       	jmp    10131a <tvinit+0xd5>
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
  101257:	8b 45 fc             	mov    -0x4(%ebp),%eax
  10125a:	8b 04 85 11 50 10 00 	mov    0x105011(,%eax,4),%eax
  101261:	89 c2                	mov    %eax,%edx
  101263:	8b 45 fc             	mov    -0x4(%ebp),%eax
  101266:	66 89 14 c5 e0 54 10 	mov    %dx,0x1054e0(,%eax,8)
  10126d:	00 
  10126e:	8b 45 fc             	mov    -0x4(%ebp),%eax
  101271:	66 c7 04 c5 e2 54 10 	movw   $0x8,0x1054e2(,%eax,8)
  101278:	00 08 00 
  10127b:	8b 45 fc             	mov    -0x4(%ebp),%eax
  10127e:	0f b6 14 c5 e4 54 10 	movzbl 0x1054e4(,%eax,8),%edx
  101285:	00 
  101286:	83 e2 e0             	and    $0xffffffe0,%edx
  101289:	88 14 c5 e4 54 10 00 	mov    %dl,0x1054e4(,%eax,8)
  101290:	8b 45 fc             	mov    -0x4(%ebp),%eax
  101293:	0f b6 14 c5 e4 54 10 	movzbl 0x1054e4(,%eax,8),%edx
  10129a:	00 
  10129b:	83 e2 1f             	and    $0x1f,%edx
  10129e:	88 14 c5 e4 54 10 00 	mov    %dl,0x1054e4(,%eax,8)
  1012a5:	8b 45 fc             	mov    -0x4(%ebp),%eax
  1012a8:	0f b6 14 c5 e5 54 10 	movzbl 0x1054e5(,%eax,8),%edx
  1012af:	00 
  1012b0:	83 e2 f0             	and    $0xfffffff0,%edx
  1012b3:	83 ca 0e             	or     $0xe,%edx
  1012b6:	88 14 c5 e5 54 10 00 	mov    %dl,0x1054e5(,%eax,8)
  1012bd:	8b 45 fc             	mov    -0x4(%ebp),%eax
  1012c0:	0f b6 14 c5 e5 54 10 	movzbl 0x1054e5(,%eax,8),%edx
  1012c7:	00 
  1012c8:	83 e2 ef             	and    $0xffffffef,%edx
  1012cb:	88 14 c5 e5 54 10 00 	mov    %dl,0x1054e5(,%eax,8)
  1012d2:	8b 45 fc             	mov    -0x4(%ebp),%eax
  1012d5:	0f b6 14 c5 e5 54 10 	movzbl 0x1054e5(,%eax,8),%edx
  1012dc:	00 
  1012dd:	83 e2 9f             	and    $0xffffff9f,%edx
  1012e0:	88 14 c5 e5 54 10 00 	mov    %dl,0x1054e5(,%eax,8)
  1012e7:	8b 45 fc             	mov    -0x4(%ebp),%eax
  1012ea:	0f b6 14 c5 e5 54 10 	movzbl 0x1054e5(,%eax,8),%edx
  1012f1:	00 
  1012f2:	83 ca 80             	or     $0xffffff80,%edx
  1012f5:	88 14 c5 e5 54 10 00 	mov    %dl,0x1054e5(,%eax,8)
  1012fc:	8b 45 fc             	mov    -0x4(%ebp),%eax
  1012ff:	8b 04 85 11 50 10 00 	mov    0x105011(,%eax,4),%eax
  101306:	c1 e8 10             	shr    $0x10,%eax
  101309:	89 c2                	mov    %eax,%edx
  10130b:	8b 45 fc             	mov    -0x4(%ebp),%eax
  10130e:	66 89 14 c5 e6 54 10 	mov    %dx,0x1054e6(,%eax,8)
  101315:	00 
  for(i = 0; i < 256; i++)
  101316:	83 45 fc 01          	addl   $0x1,-0x4(%ebp)
  10131a:	81 7d fc ff 00 00 00 	cmpl   $0xff,-0x4(%ebp)
  101321:	0f 8e 30 ff ff ff    	jle    101257 <tvinit+0x12>
}
  101327:	90                   	nop
  101328:	90                   	nop
  101329:	c9                   	leave
  10132a:	c3                   	ret

0010132b <idtinit>:

void
idtinit(void)
{
  10132b:	55                   	push   %ebp
  10132c:	89 e5                	mov    %esp,%ebp
  lidt(idt, sizeof(idt));
  10132e:	68 00 08 00 00       	push   $0x800
  101333:	68 e0 54 10 00       	push   $0x1054e0
  101338:	e8 cd fe ff ff       	call   10120a <lidt>
  10133d:	83 c4 08             	add    $0x8,%esp
}
  101340:	90                   	nop
  101341:	c9                   	leave
  101342:	c3                   	ret

00101343 <trap>:

void
trap(struct trapframe *tf)
{
  101343:	55                   	push   %ebp
  101344:	89 e5                	mov    %esp,%ebp
  101346:	56                   	push   %esi
  101347:	53                   	push   %ebx
  switch(tf->trapno){
  101348:	8b 45 08             	mov    0x8(%ebp),%eax
  10134b:	8b 40 20             	mov    0x20(%eax),%eax
  10134e:	83 f8 3f             	cmp    $0x3f,%eax
  101351:	74 51                	je     1013a4 <trap+0x61>
  101353:	83 f8 3f             	cmp    $0x3f,%eax
  101356:	77 78                	ja     1013d0 <trap+0x8d>
  101358:	83 f8 2e             	cmp    $0x2e,%eax
  10135b:	74 2f                	je     10138c <trap+0x49>
  10135d:	83 f8 2e             	cmp    $0x2e,%eax
  101360:	77 6e                	ja     1013d0 <trap+0x8d>
  101362:	83 f8 27             	cmp    $0x27,%eax
  101365:	74 3d                	je     1013a4 <trap+0x61>
  101367:	83 f8 27             	cmp    $0x27,%eax
  10136a:	77 64                	ja     1013d0 <trap+0x8d>
  10136c:	83 f8 20             	cmp    $0x20,%eax
  10136f:	74 07                	je     101378 <trap+0x35>
  101371:	83 f8 24             	cmp    $0x24,%eax
  101374:	74 22                	je     101398 <trap+0x55>
  101376:	eb 58                	jmp    1013d0 <trap+0x8d>
  case T_IRQ0 + IRQ_TIMER:
    ticks++;
  101378:	a1 e0 5c 10 00       	mov    0x105ce0,%eax
  10137d:	83 c0 01             	add    $0x1,%eax
  101380:	a3 e0 5c 10 00       	mov    %eax,0x105ce0
    lapiceoi();
  101385:	e8 ab f3 ff ff       	call   100735 <lapiceoi>
    break;
  10138a:	eb 7d                	jmp    101409 <trap+0xc6>
  case T_IRQ0 + IRQ_IDE:
    ideintr();
  10138c:	e8 dc 0f 00 00       	call   10236d <ideintr>
    lapiceoi();
  101391:	e8 9f f3 ff ff       	call   100735 <lapiceoi>
    break;
  101396:	eb 71                	jmp    101409 <trap+0xc6>
  case T_IRQ0 + IRQ_COM1:
    uartintr();
  101398:	e8 84 fa ff ff       	call   100e21 <uartintr>
    lapiceoi();
  10139d:	e8 93 f3 ff ff       	call   100735 <lapiceoi>
    break;
  1013a2:	eb 65                	jmp    101409 <trap+0xc6>
  case T_IRQ0 + 7:
  case T_IRQ0 + IRQ_SPURIOUS:
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
  1013a4:	8b 45 08             	mov    0x8(%ebp),%eax
  1013a7:	8b 70 28             	mov    0x28(%eax),%esi
            cpuid(), tf->cs, tf->eip);
  1013aa:	8b 45 08             	mov    0x8(%ebp),%eax
  1013ad:	0f b7 40 2c          	movzwl 0x2c(%eax),%eax
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
  1013b1:	0f b7 d8             	movzwl %ax,%ebx
  1013b4:	e8 52 fd ff ff       	call   10110b <cpuid>
  1013b9:	56                   	push   %esi
  1013ba:	53                   	push   %ebx
  1013bb:	50                   	push   %eax
  1013bc:	68 84 41 10 00       	push   $0x104184
  1013c1:	e8 26 ed ff ff       	call   1000ec <cprintf>
  1013c6:	83 c4 10             	add    $0x10,%esp
    lapiceoi();
  1013c9:	e8 67 f3 ff ff       	call   100735 <lapiceoi>
    break;
  1013ce:	eb 39                	jmp    101409 <trap+0xc6>

  default:
    cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
  1013d0:	e8 5f fe ff ff       	call   101234 <rcr2>
  1013d5:	89 c3                	mov    %eax,%ebx
  1013d7:	8b 45 08             	mov    0x8(%ebp),%eax
  1013da:	8b 70 28             	mov    0x28(%eax),%esi
  1013dd:	e8 29 fd ff ff       	call   10110b <cpuid>
  1013e2:	8b 55 08             	mov    0x8(%ebp),%edx
  1013e5:	8b 52 20             	mov    0x20(%edx),%edx
  1013e8:	83 ec 0c             	sub    $0xc,%esp
  1013eb:	53                   	push   %ebx
  1013ec:	56                   	push   %esi
  1013ed:	50                   	push   %eax
  1013ee:	52                   	push   %edx
  1013ef:	68 a8 41 10 00       	push   $0x1041a8
  1013f4:	e8 f3 ec ff ff       	call   1000ec <cprintf>
  1013f9:	83 c4 20             	add    $0x20,%esp
            tf->trapno, cpuid(), tf->eip, rcr2());
    panic("trap");
  1013fc:	83 ec 0c             	sub    $0xc,%esp
  1013ff:	68 da 41 10 00       	push   $0x1041da
  101404:	e8 a5 ee ff ff       	call   1002ae <panic>
  }
}
  101409:	90                   	nop
  10140a:	8d 65 f8             	lea    -0x8(%ebp),%esp
  10140d:	5b                   	pop    %ebx
  10140e:	5e                   	pop    %esi
  10140f:	5d                   	pop    %ebp
  101410:	c3                   	ret

00101411 <vector0>:
# generated by vectors.pl - do not edit
# handlers
.globl alltraps
.globl vector0
vector0:
  pushl $0
  101411:	6a 00                	push   $0x0
  pushl $0
  101413:	6a 00                	push   $0x0
  jmp alltraps
  101415:	e9 e1 fd ff ff       	jmp    1011fb <alltraps>

0010141a <vector1>:
.globl vector1
vector1:
  pushl $0
  10141a:	6a 00                	push   $0x0
  pushl $1
  10141c:	6a 01                	push   $0x1
  jmp alltraps
  10141e:	e9 d8 fd ff ff       	jmp    1011fb <alltraps>

00101423 <vector2>:
.globl vector2
vector2:
  pushl $0
  101423:	6a 00                	push   $0x0
  pushl $2
  101425:	6a 02                	push   $0x2
  jmp alltraps
  101427:	e9 cf fd ff ff       	jmp    1011fb <alltraps>

0010142c <vector3>:
.globl vector3
vector3:
  pushl $0
  10142c:	6a 00                	push   $0x0
  pushl $3
  10142e:	6a 03                	push   $0x3
  jmp alltraps
  101430:	e9 c6 fd ff ff       	jmp    1011fb <alltraps>

00101435 <vector4>:
.globl vector4
vector4:
  pushl $0
  101435:	6a 00                	push   $0x0
  pushl $4
  101437:	6a 04                	push   $0x4
  jmp alltraps
  101439:	e9 bd fd ff ff       	jmp    1011fb <alltraps>

0010143e <vector5>:
.globl vector5
vector5:
  pushl $0
  10143e:	6a 00                	push   $0x0
  pushl $5
  101440:	6a 05                	push   $0x5
  jmp alltraps
  101442:	e9 b4 fd ff ff       	jmp    1011fb <alltraps>

00101447 <vector6>:
.globl vector6
vector6:
  pushl $0
  101447:	6a 00                	push   $0x0
  pushl $6
  101449:	6a 06                	push   $0x6
  jmp alltraps
  10144b:	e9 ab fd ff ff       	jmp    1011fb <alltraps>

00101450 <vector7>:
.globl vector7
vector7:
  pushl $0
  101450:	6a 00                	push   $0x0
  pushl $7
  101452:	6a 07                	push   $0x7
  jmp alltraps
  101454:	e9 a2 fd ff ff       	jmp    1011fb <alltraps>

00101459 <vector8>:
.globl vector8
vector8:
  pushl $8
  101459:	6a 08                	push   $0x8
  jmp alltraps
  10145b:	e9 9b fd ff ff       	jmp    1011fb <alltraps>

00101460 <vector9>:
.globl vector9
vector9:
  pushl $0
  101460:	6a 00                	push   $0x0
  pushl $9
  101462:	6a 09                	push   $0x9
  jmp alltraps
  101464:	e9 92 fd ff ff       	jmp    1011fb <alltraps>

00101469 <vector10>:
.globl vector10
vector10:
  pushl $10
  101469:	6a 0a                	push   $0xa
  jmp alltraps
  10146b:	e9 8b fd ff ff       	jmp    1011fb <alltraps>

00101470 <vector11>:
.globl vector11
vector11:
  pushl $11
  101470:	6a 0b                	push   $0xb
  jmp alltraps
  101472:	e9 84 fd ff ff       	jmp    1011fb <alltraps>

00101477 <vector12>:
.globl vector12
vector12:
  pushl $12
  101477:	6a 0c                	push   $0xc
  jmp alltraps
  101479:	e9 7d fd ff ff       	jmp    1011fb <alltraps>

0010147e <vector13>:
.globl vector13
vector13:
  pushl $13
  10147e:	6a 0d                	push   $0xd
  jmp alltraps
  101480:	e9 76 fd ff ff       	jmp    1011fb <alltraps>

00101485 <vector14>:
.globl vector14
vector14:
  pushl $14
  101485:	6a 0e                	push   $0xe
  jmp alltraps
  101487:	e9 6f fd ff ff       	jmp    1011fb <alltraps>

0010148c <vector15>:
.globl vector15
vector15:
  pushl $0
  10148c:	6a 00                	push   $0x0
  pushl $15
  10148e:	6a 0f                	push   $0xf
  jmp alltraps
  101490:	e9 66 fd ff ff       	jmp    1011fb <alltraps>

00101495 <vector16>:
.globl vector16
vector16:
  pushl $0
  101495:	6a 00                	push   $0x0
  pushl $16
  101497:	6a 10                	push   $0x10
  jmp alltraps
  101499:	e9 5d fd ff ff       	jmp    1011fb <alltraps>

0010149e <vector17>:
.globl vector17
vector17:
  pushl $17
  10149e:	6a 11                	push   $0x11
  jmp alltraps
  1014a0:	e9 56 fd ff ff       	jmp    1011fb <alltraps>

001014a5 <vector18>:
.globl vector18
vector18:
  pushl $0
  1014a5:	6a 00                	push   $0x0
  pushl $18
  1014a7:	6a 12                	push   $0x12
  jmp alltraps
  1014a9:	e9 4d fd ff ff       	jmp    1011fb <alltraps>

001014ae <vector19>:
.globl vector19
vector19:
  pushl $0
  1014ae:	6a 00                	push   $0x0
  pushl $19
  1014b0:	6a 13                	push   $0x13
  jmp alltraps
  1014b2:	e9 44 fd ff ff       	jmp    1011fb <alltraps>

001014b7 <vector20>:
.globl vector20
vector20:
  pushl $0
  1014b7:	6a 00                	push   $0x0
  pushl $20
  1014b9:	6a 14                	push   $0x14
  jmp alltraps
  1014bb:	e9 3b fd ff ff       	jmp    1011fb <alltraps>

001014c0 <vector21>:
.globl vector21
vector21:
  pushl $0
  1014c0:	6a 00                	push   $0x0
  pushl $21
  1014c2:	6a 15                	push   $0x15
  jmp alltraps
  1014c4:	e9 32 fd ff ff       	jmp    1011fb <alltraps>

001014c9 <vector22>:
.globl vector22
vector22:
  pushl $0
  1014c9:	6a 00                	push   $0x0
  pushl $22
  1014cb:	6a 16                	push   $0x16
  jmp alltraps
  1014cd:	e9 29 fd ff ff       	jmp    1011fb <alltraps>

001014d2 <vector23>:
.globl vector23
vector23:
  pushl $0
  1014d2:	6a 00                	push   $0x0
  pushl $23
  1014d4:	6a 17                	push   $0x17
  jmp alltraps
  1014d6:	e9 20 fd ff ff       	jmp    1011fb <alltraps>

001014db <vector24>:
.globl vector24
vector24:
  pushl $0
  1014db:	6a 00                	push   $0x0
  pushl $24
  1014dd:	6a 18                	push   $0x18
  jmp alltraps
  1014df:	e9 17 fd ff ff       	jmp    1011fb <alltraps>

001014e4 <vector25>:
.globl vector25
vector25:
  pushl $0
  1014e4:	6a 00                	push   $0x0
  pushl $25
  1014e6:	6a 19                	push   $0x19
  jmp alltraps
  1014e8:	e9 0e fd ff ff       	jmp    1011fb <alltraps>

001014ed <vector26>:
.globl vector26
vector26:
  pushl $0
  1014ed:	6a 00                	push   $0x0
  pushl $26
  1014ef:	6a 1a                	push   $0x1a
  jmp alltraps
  1014f1:	e9 05 fd ff ff       	jmp    1011fb <alltraps>

001014f6 <vector27>:
.globl vector27
vector27:
  pushl $0
  1014f6:	6a 00                	push   $0x0
  pushl $27
  1014f8:	6a 1b                	push   $0x1b
  jmp alltraps
  1014fa:	e9 fc fc ff ff       	jmp    1011fb <alltraps>

001014ff <vector28>:
.globl vector28
vector28:
  pushl $0
  1014ff:	6a 00                	push   $0x0
  pushl $28
  101501:	6a 1c                	push   $0x1c
  jmp alltraps
  101503:	e9 f3 fc ff ff       	jmp    1011fb <alltraps>

00101508 <vector29>:
.globl vector29
vector29:
  pushl $0
  101508:	6a 00                	push   $0x0
  pushl $29
  10150a:	6a 1d                	push   $0x1d
  jmp alltraps
  10150c:	e9 ea fc ff ff       	jmp    1011fb <alltraps>

00101511 <vector30>:
.globl vector30
vector30:
  pushl $0
  101511:	6a 00                	push   $0x0
  pushl $30
  101513:	6a 1e                	push   $0x1e
  jmp alltraps
  101515:	e9 e1 fc ff ff       	jmp    1011fb <alltraps>

0010151a <vector31>:
.globl vector31
vector31:
  pushl $0
  10151a:	6a 00                	push   $0x0
  pushl $31
  10151c:	6a 1f                	push   $0x1f
  jmp alltraps
  10151e:	e9 d8 fc ff ff       	jmp    1011fb <alltraps>

00101523 <vector32>:
.globl vector32
vector32:
  pushl $0
  101523:	6a 00                	push   $0x0
  pushl $32
  101525:	6a 20                	push   $0x20
  jmp alltraps
  101527:	e9 cf fc ff ff       	jmp    1011fb <alltraps>

0010152c <vector33>:
.globl vector33
vector33:
  pushl $0
  10152c:	6a 00                	push   $0x0
  pushl $33
  10152e:	6a 21                	push   $0x21
  jmp alltraps
  101530:	e9 c6 fc ff ff       	jmp    1011fb <alltraps>

00101535 <vector34>:
.globl vector34
vector34:
  pushl $0
  101535:	6a 00                	push   $0x0
  pushl $34
  101537:	6a 22                	push   $0x22
  jmp alltraps
  101539:	e9 bd fc ff ff       	jmp    1011fb <alltraps>

0010153e <vector35>:
.globl vector35
vector35:
  pushl $0
  10153e:	6a 00                	push   $0x0
  pushl $35
  101540:	6a 23                	push   $0x23
  jmp alltraps
  101542:	e9 b4 fc ff ff       	jmp    1011fb <alltraps>

00101547 <vector36>:
.globl vector36
vector36:
  pushl $0
  101547:	6a 00                	push   $0x0
  pushl $36
  101549:	6a 24                	push   $0x24
  jmp alltraps
  10154b:	e9 ab fc ff ff       	jmp    1011fb <alltraps>

00101550 <vector37>:
.globl vector37
vector37:
  pushl $0
  101550:	6a 00                	push   $0x0
  pushl $37
  101552:	6a 25                	push   $0x25
  jmp alltraps
  101554:	e9 a2 fc ff ff       	jmp    1011fb <alltraps>

00101559 <vector38>:
.globl vector38
vector38:
  pushl $0
  101559:	6a 00                	push   $0x0
  pushl $38
  10155b:	6a 26                	push   $0x26
  jmp alltraps
  10155d:	e9 99 fc ff ff       	jmp    1011fb <alltraps>

00101562 <vector39>:
.globl vector39
vector39:
  pushl $0
  101562:	6a 00                	push   $0x0
  pushl $39
  101564:	6a 27                	push   $0x27
  jmp alltraps
  101566:	e9 90 fc ff ff       	jmp    1011fb <alltraps>

0010156b <vector40>:
.globl vector40
vector40:
  pushl $0
  10156b:	6a 00                	push   $0x0
  pushl $40
  10156d:	6a 28                	push   $0x28
  jmp alltraps
  10156f:	e9 87 fc ff ff       	jmp    1011fb <alltraps>

00101574 <vector41>:
.globl vector41
vector41:
  pushl $0
  101574:	6a 00                	push   $0x0
  pushl $41
  101576:	6a 29                	push   $0x29
  jmp alltraps
  101578:	e9 7e fc ff ff       	jmp    1011fb <alltraps>

0010157d <vector42>:
.globl vector42
vector42:
  pushl $0
  10157d:	6a 00                	push   $0x0
  pushl $42
  10157f:	6a 2a                	push   $0x2a
  jmp alltraps
  101581:	e9 75 fc ff ff       	jmp    1011fb <alltraps>

00101586 <vector43>:
.globl vector43
vector43:
  pushl $0
  101586:	6a 00                	push   $0x0
  pushl $43
  101588:	6a 2b                	push   $0x2b
  jmp alltraps
  10158a:	e9 6c fc ff ff       	jmp    1011fb <alltraps>

0010158f <vector44>:
.globl vector44
vector44:
  pushl $0
  10158f:	6a 00                	push   $0x0
  pushl $44
  101591:	6a 2c                	push   $0x2c
  jmp alltraps
  101593:	e9 63 fc ff ff       	jmp    1011fb <alltraps>

00101598 <vector45>:
.globl vector45
vector45:
  pushl $0
  101598:	6a 00                	push   $0x0
  pushl $45
  10159a:	6a 2d                	push   $0x2d
  jmp alltraps
  10159c:	e9 5a fc ff ff       	jmp    1011fb <alltraps>

001015a1 <vector46>:
.globl vector46
vector46:
  pushl $0
  1015a1:	6a 00                	push   $0x0
  pushl $46
  1015a3:	6a 2e                	push   $0x2e
  jmp alltraps
  1015a5:	e9 51 fc ff ff       	jmp    1011fb <alltraps>

001015aa <vector47>:
.globl vector47
vector47:
  pushl $0
  1015aa:	6a 00                	push   $0x0
  pushl $47
  1015ac:	6a 2f                	push   $0x2f
  jmp alltraps
  1015ae:	e9 48 fc ff ff       	jmp    1011fb <alltraps>

001015b3 <vector48>:
.globl vector48
vector48:
  pushl $0
  1015b3:	6a 00                	push   $0x0
  pushl $48
  1015b5:	6a 30                	push   $0x30
  jmp alltraps
  1015b7:	e9 3f fc ff ff       	jmp    1011fb <alltraps>

001015bc <vector49>:
.globl vector49
vector49:
  pushl $0
  1015bc:	6a 00                	push   $0x0
  pushl $49
  1015be:	6a 31                	push   $0x31
  jmp alltraps
  1015c0:	e9 36 fc ff ff       	jmp    1011fb <alltraps>

001015c5 <vector50>:
.globl vector50
vector50:
  pushl $0
  1015c5:	6a 00                	push   $0x0
  pushl $50
  1015c7:	6a 32                	push   $0x32
  jmp alltraps
  1015c9:	e9 2d fc ff ff       	jmp    1011fb <alltraps>

001015ce <vector51>:
.globl vector51
vector51:
  pushl $0
  1015ce:	6a 00                	push   $0x0
  pushl $51
  1015d0:	6a 33                	push   $0x33
  jmp alltraps
  1015d2:	e9 24 fc ff ff       	jmp    1011fb <alltraps>

001015d7 <vector52>:
.globl vector52
vector52:
  pushl $0
  1015d7:	6a 00                	push   $0x0
  pushl $52
  1015d9:	6a 34                	push   $0x34
  jmp alltraps
  1015db:	e9 1b fc ff ff       	jmp    1011fb <alltraps>

001015e0 <vector53>:
.globl vector53
vector53:
  pushl $0
  1015e0:	6a 00                	push   $0x0
  pushl $53
  1015e2:	6a 35                	push   $0x35
  jmp alltraps
  1015e4:	e9 12 fc ff ff       	jmp    1011fb <alltraps>

001015e9 <vector54>:
.globl vector54
vector54:
  pushl $0
  1015e9:	6a 00                	push   $0x0
  pushl $54
  1015eb:	6a 36                	push   $0x36
  jmp alltraps
  1015ed:	e9 09 fc ff ff       	jmp    1011fb <alltraps>

001015f2 <vector55>:
.globl vector55
vector55:
  pushl $0
  1015f2:	6a 00                	push   $0x0
  pushl $55
  1015f4:	6a 37                	push   $0x37
  jmp alltraps
  1015f6:	e9 00 fc ff ff       	jmp    1011fb <alltraps>

001015fb <vector56>:
.globl vector56
vector56:
  pushl $0
  1015fb:	6a 00                	push   $0x0
  pushl $56
  1015fd:	6a 38                	push   $0x38
  jmp alltraps
  1015ff:	e9 f7 fb ff ff       	jmp    1011fb <alltraps>

00101604 <vector57>:
.globl vector57
vector57:
  pushl $0
  101604:	6a 00                	push   $0x0
  pushl $57
  101606:	6a 39                	push   $0x39
  jmp alltraps
  101608:	e9 ee fb ff ff       	jmp    1011fb <alltraps>

0010160d <vector58>:
.globl vector58
vector58:
  pushl $0
  10160d:	6a 00                	push   $0x0
  pushl $58
  10160f:	6a 3a                	push   $0x3a
  jmp alltraps
  101611:	e9 e5 fb ff ff       	jmp    1011fb <alltraps>

00101616 <vector59>:
.globl vector59
vector59:
  pushl $0
  101616:	6a 00                	push   $0x0
  pushl $59
  101618:	6a 3b                	push   $0x3b
  jmp alltraps
  10161a:	e9 dc fb ff ff       	jmp    1011fb <alltraps>

0010161f <vector60>:
.globl vector60
vector60:
  pushl $0
  10161f:	6a 00                	push   $0x0
  pushl $60
  101621:	6a 3c                	push   $0x3c
  jmp alltraps
  101623:	e9 d3 fb ff ff       	jmp    1011fb <alltraps>

00101628 <vector61>:
.globl vector61
vector61:
  pushl $0
  101628:	6a 00                	push   $0x0
  pushl $61
  10162a:	6a 3d                	push   $0x3d
  jmp alltraps
  10162c:	e9 ca fb ff ff       	jmp    1011fb <alltraps>

00101631 <vector62>:
.globl vector62
vector62:
  pushl $0
  101631:	6a 00                	push   $0x0
  pushl $62
  101633:	6a 3e                	push   $0x3e
  jmp alltraps
  101635:	e9 c1 fb ff ff       	jmp    1011fb <alltraps>

0010163a <vector63>:
.globl vector63
vector63:
  pushl $0
  10163a:	6a 00                	push   $0x0
  pushl $63
  10163c:	6a 3f                	push   $0x3f
  jmp alltraps
  10163e:	e9 b8 fb ff ff       	jmp    1011fb <alltraps>

00101643 <vector64>:
.globl vector64
vector64:
  pushl $0
  101643:	6a 00                	push   $0x0
  pushl $64
  101645:	6a 40                	push   $0x40
  jmp alltraps
  101647:	e9 af fb ff ff       	jmp    1011fb <alltraps>

0010164c <vector65>:
.globl vector65
vector65:
  pushl $0
  10164c:	6a 00                	push   $0x0
  pushl $65
  10164e:	6a 41                	push   $0x41
  jmp alltraps
  101650:	e9 a6 fb ff ff       	jmp    1011fb <alltraps>

00101655 <vector66>:
.globl vector66
vector66:
  pushl $0
  101655:	6a 00                	push   $0x0
  pushl $66
  101657:	6a 42                	push   $0x42
  jmp alltraps
  101659:	e9 9d fb ff ff       	jmp    1011fb <alltraps>

0010165e <vector67>:
.globl vector67
vector67:
  pushl $0
  10165e:	6a 00                	push   $0x0
  pushl $67
  101660:	6a 43                	push   $0x43
  jmp alltraps
  101662:	e9 94 fb ff ff       	jmp    1011fb <alltraps>

00101667 <vector68>:
.globl vector68
vector68:
  pushl $0
  101667:	6a 00                	push   $0x0
  pushl $68
  101669:	6a 44                	push   $0x44
  jmp alltraps
  10166b:	e9 8b fb ff ff       	jmp    1011fb <alltraps>

00101670 <vector69>:
.globl vector69
vector69:
  pushl $0
  101670:	6a 00                	push   $0x0
  pushl $69
  101672:	6a 45                	push   $0x45
  jmp alltraps
  101674:	e9 82 fb ff ff       	jmp    1011fb <alltraps>

00101679 <vector70>:
.globl vector70
vector70:
  pushl $0
  101679:	6a 00                	push   $0x0
  pushl $70
  10167b:	6a 46                	push   $0x46
  jmp alltraps
  10167d:	e9 79 fb ff ff       	jmp    1011fb <alltraps>

00101682 <vector71>:
.globl vector71
vector71:
  pushl $0
  101682:	6a 00                	push   $0x0
  pushl $71
  101684:	6a 47                	push   $0x47
  jmp alltraps
  101686:	e9 70 fb ff ff       	jmp    1011fb <alltraps>

0010168b <vector72>:
.globl vector72
vector72:
  pushl $0
  10168b:	6a 00                	push   $0x0
  pushl $72
  10168d:	6a 48                	push   $0x48
  jmp alltraps
  10168f:	e9 67 fb ff ff       	jmp    1011fb <alltraps>

00101694 <vector73>:
.globl vector73
vector73:
  pushl $0
  101694:	6a 00                	push   $0x0
  pushl $73
  101696:	6a 49                	push   $0x49
  jmp alltraps
  101698:	e9 5e fb ff ff       	jmp    1011fb <alltraps>

0010169d <vector74>:
.globl vector74
vector74:
  pushl $0
  10169d:	6a 00                	push   $0x0
  pushl $74
  10169f:	6a 4a                	push   $0x4a
  jmp alltraps
  1016a1:	e9 55 fb ff ff       	jmp    1011fb <alltraps>

001016a6 <vector75>:
.globl vector75
vector75:
  pushl $0
  1016a6:	6a 00                	push   $0x0
  pushl $75
  1016a8:	6a 4b                	push   $0x4b
  jmp alltraps
  1016aa:	e9 4c fb ff ff       	jmp    1011fb <alltraps>

001016af <vector76>:
.globl vector76
vector76:
  pushl $0
  1016af:	6a 00                	push   $0x0
  pushl $76
  1016b1:	6a 4c                	push   $0x4c
  jmp alltraps
  1016b3:	e9 43 fb ff ff       	jmp    1011fb <alltraps>

001016b8 <vector77>:
.globl vector77
vector77:
  pushl $0
  1016b8:	6a 00                	push   $0x0
  pushl $77
  1016ba:	6a 4d                	push   $0x4d
  jmp alltraps
  1016bc:	e9 3a fb ff ff       	jmp    1011fb <alltraps>

001016c1 <vector78>:
.globl vector78
vector78:
  pushl $0
  1016c1:	6a 00                	push   $0x0
  pushl $78
  1016c3:	6a 4e                	push   $0x4e
  jmp alltraps
  1016c5:	e9 31 fb ff ff       	jmp    1011fb <alltraps>

001016ca <vector79>:
.globl vector79
vector79:
  pushl $0
  1016ca:	6a 00                	push   $0x0
  pushl $79
  1016cc:	6a 4f                	push   $0x4f
  jmp alltraps
  1016ce:	e9 28 fb ff ff       	jmp    1011fb <alltraps>

001016d3 <vector80>:
.globl vector80
vector80:
  pushl $0
  1016d3:	6a 00                	push   $0x0
  pushl $80
  1016d5:	6a 50                	push   $0x50
  jmp alltraps
  1016d7:	e9 1f fb ff ff       	jmp    1011fb <alltraps>

001016dc <vector81>:
.globl vector81
vector81:
  pushl $0
  1016dc:	6a 00                	push   $0x0
  pushl $81
  1016de:	6a 51                	push   $0x51
  jmp alltraps
  1016e0:	e9 16 fb ff ff       	jmp    1011fb <alltraps>

001016e5 <vector82>:
.globl vector82
vector82:
  pushl $0
  1016e5:	6a 00                	push   $0x0
  pushl $82
  1016e7:	6a 52                	push   $0x52
  jmp alltraps
  1016e9:	e9 0d fb ff ff       	jmp    1011fb <alltraps>

001016ee <vector83>:
.globl vector83
vector83:
  pushl $0
  1016ee:	6a 00                	push   $0x0
  pushl $83
  1016f0:	6a 53                	push   $0x53
  jmp alltraps
  1016f2:	e9 04 fb ff ff       	jmp    1011fb <alltraps>

001016f7 <vector84>:
.globl vector84
vector84:
  pushl $0
  1016f7:	6a 00                	push   $0x0
  pushl $84
  1016f9:	6a 54                	push   $0x54
  jmp alltraps
  1016fb:	e9 fb fa ff ff       	jmp    1011fb <alltraps>

00101700 <vector85>:
.globl vector85
vector85:
  pushl $0
  101700:	6a 00                	push   $0x0
  pushl $85
  101702:	6a 55                	push   $0x55
  jmp alltraps
  101704:	e9 f2 fa ff ff       	jmp    1011fb <alltraps>

00101709 <vector86>:
.globl vector86
vector86:
  pushl $0
  101709:	6a 00                	push   $0x0
  pushl $86
  10170b:	6a 56                	push   $0x56
  jmp alltraps
  10170d:	e9 e9 fa ff ff       	jmp    1011fb <alltraps>

00101712 <vector87>:
.globl vector87
vector87:
  pushl $0
  101712:	6a 00                	push   $0x0
  pushl $87
  101714:	6a 57                	push   $0x57
  jmp alltraps
  101716:	e9 e0 fa ff ff       	jmp    1011fb <alltraps>

0010171b <vector88>:
.globl vector88
vector88:
  pushl $0
  10171b:	6a 00                	push   $0x0
  pushl $88
  10171d:	6a 58                	push   $0x58
  jmp alltraps
  10171f:	e9 d7 fa ff ff       	jmp    1011fb <alltraps>

00101724 <vector89>:
.globl vector89
vector89:
  pushl $0
  101724:	6a 00                	push   $0x0
  pushl $89
  101726:	6a 59                	push   $0x59
  jmp alltraps
  101728:	e9 ce fa ff ff       	jmp    1011fb <alltraps>

0010172d <vector90>:
.globl vector90
vector90:
  pushl $0
  10172d:	6a 00                	push   $0x0
  pushl $90
  10172f:	6a 5a                	push   $0x5a
  jmp alltraps
  101731:	e9 c5 fa ff ff       	jmp    1011fb <alltraps>

00101736 <vector91>:
.globl vector91
vector91:
  pushl $0
  101736:	6a 00                	push   $0x0
  pushl $91
  101738:	6a 5b                	push   $0x5b
  jmp alltraps
  10173a:	e9 bc fa ff ff       	jmp    1011fb <alltraps>

0010173f <vector92>:
.globl vector92
vector92:
  pushl $0
  10173f:	6a 00                	push   $0x0
  pushl $92
  101741:	6a 5c                	push   $0x5c
  jmp alltraps
  101743:	e9 b3 fa ff ff       	jmp    1011fb <alltraps>

00101748 <vector93>:
.globl vector93
vector93:
  pushl $0
  101748:	6a 00                	push   $0x0
  pushl $93
  10174a:	6a 5d                	push   $0x5d
  jmp alltraps
  10174c:	e9 aa fa ff ff       	jmp    1011fb <alltraps>

00101751 <vector94>:
.globl vector94
vector94:
  pushl $0
  101751:	6a 00                	push   $0x0
  pushl $94
  101753:	6a 5e                	push   $0x5e
  jmp alltraps
  101755:	e9 a1 fa ff ff       	jmp    1011fb <alltraps>

0010175a <vector95>:
.globl vector95
vector95:
  pushl $0
  10175a:	6a 00                	push   $0x0
  pushl $95
  10175c:	6a 5f                	push   $0x5f
  jmp alltraps
  10175e:	e9 98 fa ff ff       	jmp    1011fb <alltraps>

00101763 <vector96>:
.globl vector96
vector96:
  pushl $0
  101763:	6a 00                	push   $0x0
  pushl $96
  101765:	6a 60                	push   $0x60
  jmp alltraps
  101767:	e9 8f fa ff ff       	jmp    1011fb <alltraps>

0010176c <vector97>:
.globl vector97
vector97:
  pushl $0
  10176c:	6a 00                	push   $0x0
  pushl $97
  10176e:	6a 61                	push   $0x61
  jmp alltraps
  101770:	e9 86 fa ff ff       	jmp    1011fb <alltraps>

00101775 <vector98>:
.globl vector98
vector98:
  pushl $0
  101775:	6a 00                	push   $0x0
  pushl $98
  101777:	6a 62                	push   $0x62
  jmp alltraps
  101779:	e9 7d fa ff ff       	jmp    1011fb <alltraps>

0010177e <vector99>:
.globl vector99
vector99:
  pushl $0
  10177e:	6a 00                	push   $0x0
  pushl $99
  101780:	6a 63                	push   $0x63
  jmp alltraps
  101782:	e9 74 fa ff ff       	jmp    1011fb <alltraps>

00101787 <vector100>:
.globl vector100
vector100:
  pushl $0
  101787:	6a 00                	push   $0x0
  pushl $100
  101789:	6a 64                	push   $0x64
  jmp alltraps
  10178b:	e9 6b fa ff ff       	jmp    1011fb <alltraps>

00101790 <vector101>:
.globl vector101
vector101:
  pushl $0
  101790:	6a 00                	push   $0x0
  pushl $101
  101792:	6a 65                	push   $0x65
  jmp alltraps
  101794:	e9 62 fa ff ff       	jmp    1011fb <alltraps>

00101799 <vector102>:
.globl vector102
vector102:
  pushl $0
  101799:	6a 00                	push   $0x0
  pushl $102
  10179b:	6a 66                	push   $0x66
  jmp alltraps
  10179d:	e9 59 fa ff ff       	jmp    1011fb <alltraps>

001017a2 <vector103>:
.globl vector103
vector103:
  pushl $0
  1017a2:	6a 00                	push   $0x0
  pushl $103
  1017a4:	6a 67                	push   $0x67
  jmp alltraps
  1017a6:	e9 50 fa ff ff       	jmp    1011fb <alltraps>

001017ab <vector104>:
.globl vector104
vector104:
  pushl $0
  1017ab:	6a 00                	push   $0x0
  pushl $104
  1017ad:	6a 68                	push   $0x68
  jmp alltraps
  1017af:	e9 47 fa ff ff       	jmp    1011fb <alltraps>

001017b4 <vector105>:
.globl vector105
vector105:
  pushl $0
  1017b4:	6a 00                	push   $0x0
  pushl $105
  1017b6:	6a 69                	push   $0x69
  jmp alltraps
  1017b8:	e9 3e fa ff ff       	jmp    1011fb <alltraps>

001017bd <vector106>:
.globl vector106
vector106:
  pushl $0
  1017bd:	6a 00                	push   $0x0
  pushl $106
  1017bf:	6a 6a                	push   $0x6a
  jmp alltraps
  1017c1:	e9 35 fa ff ff       	jmp    1011fb <alltraps>

001017c6 <vector107>:
.globl vector107
vector107:
  pushl $0
  1017c6:	6a 00                	push   $0x0
  pushl $107
  1017c8:	6a 6b                	push   $0x6b
  jmp alltraps
  1017ca:	e9 2c fa ff ff       	jmp    1011fb <alltraps>

001017cf <vector108>:
.globl vector108
vector108:
  pushl $0
  1017cf:	6a 00                	push   $0x0
  pushl $108
  1017d1:	6a 6c                	push   $0x6c
  jmp alltraps
  1017d3:	e9 23 fa ff ff       	jmp    1011fb <alltraps>

001017d8 <vector109>:
.globl vector109
vector109:
  pushl $0
  1017d8:	6a 00                	push   $0x0
  pushl $109
  1017da:	6a 6d                	push   $0x6d
  jmp alltraps
  1017dc:	e9 1a fa ff ff       	jmp    1011fb <alltraps>

001017e1 <vector110>:
.globl vector110
vector110:
  pushl $0
  1017e1:	6a 00                	push   $0x0
  pushl $110
  1017e3:	6a 6e                	push   $0x6e
  jmp alltraps
  1017e5:	e9 11 fa ff ff       	jmp    1011fb <alltraps>

001017ea <vector111>:
.globl vector111
vector111:
  pushl $0
  1017ea:	6a 00                	push   $0x0
  pushl $111
  1017ec:	6a 6f                	push   $0x6f
  jmp alltraps
  1017ee:	e9 08 fa ff ff       	jmp    1011fb <alltraps>

001017f3 <vector112>:
.globl vector112
vector112:
  pushl $0
  1017f3:	6a 00                	push   $0x0
  pushl $112
  1017f5:	6a 70                	push   $0x70
  jmp alltraps
  1017f7:	e9 ff f9 ff ff       	jmp    1011fb <alltraps>

001017fc <vector113>:
.globl vector113
vector113:
  pushl $0
  1017fc:	6a 00                	push   $0x0
  pushl $113
  1017fe:	6a 71                	push   $0x71
  jmp alltraps
  101800:	e9 f6 f9 ff ff       	jmp    1011fb <alltraps>

00101805 <vector114>:
.globl vector114
vector114:
  pushl $0
  101805:	6a 00                	push   $0x0
  pushl $114
  101807:	6a 72                	push   $0x72
  jmp alltraps
  101809:	e9 ed f9 ff ff       	jmp    1011fb <alltraps>

0010180e <vector115>:
.globl vector115
vector115:
  pushl $0
  10180e:	6a 00                	push   $0x0
  pushl $115
  101810:	6a 73                	push   $0x73
  jmp alltraps
  101812:	e9 e4 f9 ff ff       	jmp    1011fb <alltraps>

00101817 <vector116>:
.globl vector116
vector116:
  pushl $0
  101817:	6a 00                	push   $0x0
  pushl $116
  101819:	6a 74                	push   $0x74
  jmp alltraps
  10181b:	e9 db f9 ff ff       	jmp    1011fb <alltraps>

00101820 <vector117>:
.globl vector117
vector117:
  pushl $0
  101820:	6a 00                	push   $0x0
  pushl $117
  101822:	6a 75                	push   $0x75
  jmp alltraps
  101824:	e9 d2 f9 ff ff       	jmp    1011fb <alltraps>

00101829 <vector118>:
.globl vector118
vector118:
  pushl $0
  101829:	6a 00                	push   $0x0
  pushl $118
  10182b:	6a 76                	push   $0x76
  jmp alltraps
  10182d:	e9 c9 f9 ff ff       	jmp    1011fb <alltraps>

00101832 <vector119>:
.globl vector119
vector119:
  pushl $0
  101832:	6a 00                	push   $0x0
  pushl $119
  101834:	6a 77                	push   $0x77
  jmp alltraps
  101836:	e9 c0 f9 ff ff       	jmp    1011fb <alltraps>

0010183b <vector120>:
.globl vector120
vector120:
  pushl $0
  10183b:	6a 00                	push   $0x0
  pushl $120
  10183d:	6a 78                	push   $0x78
  jmp alltraps
  10183f:	e9 b7 f9 ff ff       	jmp    1011fb <alltraps>

00101844 <vector121>:
.globl vector121
vector121:
  pushl $0
  101844:	6a 00                	push   $0x0
  pushl $121
  101846:	6a 79                	push   $0x79
  jmp alltraps
  101848:	e9 ae f9 ff ff       	jmp    1011fb <alltraps>

0010184d <vector122>:
.globl vector122
vector122:
  pushl $0
  10184d:	6a 00                	push   $0x0
  pushl $122
  10184f:	6a 7a                	push   $0x7a
  jmp alltraps
  101851:	e9 a5 f9 ff ff       	jmp    1011fb <alltraps>

00101856 <vector123>:
.globl vector123
vector123:
  pushl $0
  101856:	6a 00                	push   $0x0
  pushl $123
  101858:	6a 7b                	push   $0x7b
  jmp alltraps
  10185a:	e9 9c f9 ff ff       	jmp    1011fb <alltraps>

0010185f <vector124>:
.globl vector124
vector124:
  pushl $0
  10185f:	6a 00                	push   $0x0
  pushl $124
  101861:	6a 7c                	push   $0x7c
  jmp alltraps
  101863:	e9 93 f9 ff ff       	jmp    1011fb <alltraps>

00101868 <vector125>:
.globl vector125
vector125:
  pushl $0
  101868:	6a 00                	push   $0x0
  pushl $125
  10186a:	6a 7d                	push   $0x7d
  jmp alltraps
  10186c:	e9 8a f9 ff ff       	jmp    1011fb <alltraps>

00101871 <vector126>:
.globl vector126
vector126:
  pushl $0
  101871:	6a 00                	push   $0x0
  pushl $126
  101873:	6a 7e                	push   $0x7e
  jmp alltraps
  101875:	e9 81 f9 ff ff       	jmp    1011fb <alltraps>

0010187a <vector127>:
.globl vector127
vector127:
  pushl $0
  10187a:	6a 00                	push   $0x0
  pushl $127
  10187c:	6a 7f                	push   $0x7f
  jmp alltraps
  10187e:	e9 78 f9 ff ff       	jmp    1011fb <alltraps>

00101883 <vector128>:
.globl vector128
vector128:
  pushl $0
  101883:	6a 00                	push   $0x0
  pushl $128
  101885:	68 80 00 00 00       	push   $0x80
  jmp alltraps
  10188a:	e9 6c f9 ff ff       	jmp    1011fb <alltraps>

0010188f <vector129>:
.globl vector129
vector129:
  pushl $0
  10188f:	6a 00                	push   $0x0
  pushl $129
  101891:	68 81 00 00 00       	push   $0x81
  jmp alltraps
  101896:	e9 60 f9 ff ff       	jmp    1011fb <alltraps>

0010189b <vector130>:
.globl vector130
vector130:
  pushl $0
  10189b:	6a 00                	push   $0x0
  pushl $130
  10189d:	68 82 00 00 00       	push   $0x82
  jmp alltraps
  1018a2:	e9 54 f9 ff ff       	jmp    1011fb <alltraps>

001018a7 <vector131>:
.globl vector131
vector131:
  pushl $0
  1018a7:	6a 00                	push   $0x0
  pushl $131
  1018a9:	68 83 00 00 00       	push   $0x83
  jmp alltraps
  1018ae:	e9 48 f9 ff ff       	jmp    1011fb <alltraps>

001018b3 <vector132>:
.globl vector132
vector132:
  pushl $0
  1018b3:	6a 00                	push   $0x0
  pushl $132
  1018b5:	68 84 00 00 00       	push   $0x84
  jmp alltraps
  1018ba:	e9 3c f9 ff ff       	jmp    1011fb <alltraps>

001018bf <vector133>:
.globl vector133
vector133:
  pushl $0
  1018bf:	6a 00                	push   $0x0
  pushl $133
  1018c1:	68 85 00 00 00       	push   $0x85
  jmp alltraps
  1018c6:	e9 30 f9 ff ff       	jmp    1011fb <alltraps>

001018cb <vector134>:
.globl vector134
vector134:
  pushl $0
  1018cb:	6a 00                	push   $0x0
  pushl $134
  1018cd:	68 86 00 00 00       	push   $0x86
  jmp alltraps
  1018d2:	e9 24 f9 ff ff       	jmp    1011fb <alltraps>

001018d7 <vector135>:
.globl vector135
vector135:
  pushl $0
  1018d7:	6a 00                	push   $0x0
  pushl $135
  1018d9:	68 87 00 00 00       	push   $0x87
  jmp alltraps
  1018de:	e9 18 f9 ff ff       	jmp    1011fb <alltraps>

001018e3 <vector136>:
.globl vector136
vector136:
  pushl $0
  1018e3:	6a 00                	push   $0x0
  pushl $136
  1018e5:	68 88 00 00 00       	push   $0x88
  jmp alltraps
  1018ea:	e9 0c f9 ff ff       	jmp    1011fb <alltraps>

001018ef <vector137>:
.globl vector137
vector137:
  pushl $0
  1018ef:	6a 00                	push   $0x0
  pushl $137
  1018f1:	68 89 00 00 00       	push   $0x89
  jmp alltraps
  1018f6:	e9 00 f9 ff ff       	jmp    1011fb <alltraps>

001018fb <vector138>:
.globl vector138
vector138:
  pushl $0
  1018fb:	6a 00                	push   $0x0
  pushl $138
  1018fd:	68 8a 00 00 00       	push   $0x8a
  jmp alltraps
  101902:	e9 f4 f8 ff ff       	jmp    1011fb <alltraps>

00101907 <vector139>:
.globl vector139
vector139:
  pushl $0
  101907:	6a 00                	push   $0x0
  pushl $139
  101909:	68 8b 00 00 00       	push   $0x8b
  jmp alltraps
  10190e:	e9 e8 f8 ff ff       	jmp    1011fb <alltraps>

00101913 <vector140>:
.globl vector140
vector140:
  pushl $0
  101913:	6a 00                	push   $0x0
  pushl $140
  101915:	68 8c 00 00 00       	push   $0x8c
  jmp alltraps
  10191a:	e9 dc f8 ff ff       	jmp    1011fb <alltraps>

0010191f <vector141>:
.globl vector141
vector141:
  pushl $0
  10191f:	6a 00                	push   $0x0
  pushl $141
  101921:	68 8d 00 00 00       	push   $0x8d
  jmp alltraps
  101926:	e9 d0 f8 ff ff       	jmp    1011fb <alltraps>

0010192b <vector142>:
.globl vector142
vector142:
  pushl $0
  10192b:	6a 00                	push   $0x0
  pushl $142
  10192d:	68 8e 00 00 00       	push   $0x8e
  jmp alltraps
  101932:	e9 c4 f8 ff ff       	jmp    1011fb <alltraps>

00101937 <vector143>:
.globl vector143
vector143:
  pushl $0
  101937:	6a 00                	push   $0x0
  pushl $143
  101939:	68 8f 00 00 00       	push   $0x8f
  jmp alltraps
  10193e:	e9 b8 f8 ff ff       	jmp    1011fb <alltraps>

00101943 <vector144>:
.globl vector144
vector144:
  pushl $0
  101943:	6a 00                	push   $0x0
  pushl $144
  101945:	68 90 00 00 00       	push   $0x90
  jmp alltraps
  10194a:	e9 ac f8 ff ff       	jmp    1011fb <alltraps>

0010194f <vector145>:
.globl vector145
vector145:
  pushl $0
  10194f:	6a 00                	push   $0x0
  pushl $145
  101951:	68 91 00 00 00       	push   $0x91
  jmp alltraps
  101956:	e9 a0 f8 ff ff       	jmp    1011fb <alltraps>

0010195b <vector146>:
.globl vector146
vector146:
  pushl $0
  10195b:	6a 00                	push   $0x0
  pushl $146
  10195d:	68 92 00 00 00       	push   $0x92
  jmp alltraps
  101962:	e9 94 f8 ff ff       	jmp    1011fb <alltraps>

00101967 <vector147>:
.globl vector147
vector147:
  pushl $0
  101967:	6a 00                	push   $0x0
  pushl $147
  101969:	68 93 00 00 00       	push   $0x93
  jmp alltraps
  10196e:	e9 88 f8 ff ff       	jmp    1011fb <alltraps>

00101973 <vector148>:
.globl vector148
vector148:
  pushl $0
  101973:	6a 00                	push   $0x0
  pushl $148
  101975:	68 94 00 00 00       	push   $0x94
  jmp alltraps
  10197a:	e9 7c f8 ff ff       	jmp    1011fb <alltraps>

0010197f <vector149>:
.globl vector149
vector149:
  pushl $0
  10197f:	6a 00                	push   $0x0
  pushl $149
  101981:	68 95 00 00 00       	push   $0x95
  jmp alltraps
  101986:	e9 70 f8 ff ff       	jmp    1011fb <alltraps>

0010198b <vector150>:
.globl vector150
vector150:
  pushl $0
  10198b:	6a 00                	push   $0x0
  pushl $150
  10198d:	68 96 00 00 00       	push   $0x96
  jmp alltraps
  101992:	e9 64 f8 ff ff       	jmp    1011fb <alltraps>

00101997 <vector151>:
.globl vector151
vector151:
  pushl $0
  101997:	6a 00                	push   $0x0
  pushl $151
  101999:	68 97 00 00 00       	push   $0x97
  jmp alltraps
  10199e:	e9 58 f8 ff ff       	jmp    1011fb <alltraps>

001019a3 <vector152>:
.globl vector152
vector152:
  pushl $0
  1019a3:	6a 00                	push   $0x0
  pushl $152
  1019a5:	68 98 00 00 00       	push   $0x98
  jmp alltraps
  1019aa:	e9 4c f8 ff ff       	jmp    1011fb <alltraps>

001019af <vector153>:
.globl vector153
vector153:
  pushl $0
  1019af:	6a 00                	push   $0x0
  pushl $153
  1019b1:	68 99 00 00 00       	push   $0x99
  jmp alltraps
  1019b6:	e9 40 f8 ff ff       	jmp    1011fb <alltraps>

001019bb <vector154>:
.globl vector154
vector154:
  pushl $0
  1019bb:	6a 00                	push   $0x0
  pushl $154
  1019bd:	68 9a 00 00 00       	push   $0x9a
  jmp alltraps
  1019c2:	e9 34 f8 ff ff       	jmp    1011fb <alltraps>

001019c7 <vector155>:
.globl vector155
vector155:
  pushl $0
  1019c7:	6a 00                	push   $0x0
  pushl $155
  1019c9:	68 9b 00 00 00       	push   $0x9b
  jmp alltraps
  1019ce:	e9 28 f8 ff ff       	jmp    1011fb <alltraps>

001019d3 <vector156>:
.globl vector156
vector156:
  pushl $0
  1019d3:	6a 00                	push   $0x0
  pushl $156
  1019d5:	68 9c 00 00 00       	push   $0x9c
  jmp alltraps
  1019da:	e9 1c f8 ff ff       	jmp    1011fb <alltraps>

001019df <vector157>:
.globl vector157
vector157:
  pushl $0
  1019df:	6a 00                	push   $0x0
  pushl $157
  1019e1:	68 9d 00 00 00       	push   $0x9d
  jmp alltraps
  1019e6:	e9 10 f8 ff ff       	jmp    1011fb <alltraps>

001019eb <vector158>:
.globl vector158
vector158:
  pushl $0
  1019eb:	6a 00                	push   $0x0
  pushl $158
  1019ed:	68 9e 00 00 00       	push   $0x9e
  jmp alltraps
  1019f2:	e9 04 f8 ff ff       	jmp    1011fb <alltraps>

001019f7 <vector159>:
.globl vector159
vector159:
  pushl $0
  1019f7:	6a 00                	push   $0x0
  pushl $159
  1019f9:	68 9f 00 00 00       	push   $0x9f
  jmp alltraps
  1019fe:	e9 f8 f7 ff ff       	jmp    1011fb <alltraps>

00101a03 <vector160>:
.globl vector160
vector160:
  pushl $0
  101a03:	6a 00                	push   $0x0
  pushl $160
  101a05:	68 a0 00 00 00       	push   $0xa0
  jmp alltraps
  101a0a:	e9 ec f7 ff ff       	jmp    1011fb <alltraps>

00101a0f <vector161>:
.globl vector161
vector161:
  pushl $0
  101a0f:	6a 00                	push   $0x0
  pushl $161
  101a11:	68 a1 00 00 00       	push   $0xa1
  jmp alltraps
  101a16:	e9 e0 f7 ff ff       	jmp    1011fb <alltraps>

00101a1b <vector162>:
.globl vector162
vector162:
  pushl $0
  101a1b:	6a 00                	push   $0x0
  pushl $162
  101a1d:	68 a2 00 00 00       	push   $0xa2
  jmp alltraps
  101a22:	e9 d4 f7 ff ff       	jmp    1011fb <alltraps>

00101a27 <vector163>:
.globl vector163
vector163:
  pushl $0
  101a27:	6a 00                	push   $0x0
  pushl $163
  101a29:	68 a3 00 00 00       	push   $0xa3
  jmp alltraps
  101a2e:	e9 c8 f7 ff ff       	jmp    1011fb <alltraps>

00101a33 <vector164>:
.globl vector164
vector164:
  pushl $0
  101a33:	6a 00                	push   $0x0
  pushl $164
  101a35:	68 a4 00 00 00       	push   $0xa4
  jmp alltraps
  101a3a:	e9 bc f7 ff ff       	jmp    1011fb <alltraps>

00101a3f <vector165>:
.globl vector165
vector165:
  pushl $0
  101a3f:	6a 00                	push   $0x0
  pushl $165
  101a41:	68 a5 00 00 00       	push   $0xa5
  jmp alltraps
  101a46:	e9 b0 f7 ff ff       	jmp    1011fb <alltraps>

00101a4b <vector166>:
.globl vector166
vector166:
  pushl $0
  101a4b:	6a 00                	push   $0x0
  pushl $166
  101a4d:	68 a6 00 00 00       	push   $0xa6
  jmp alltraps
  101a52:	e9 a4 f7 ff ff       	jmp    1011fb <alltraps>

00101a57 <vector167>:
.globl vector167
vector167:
  pushl $0
  101a57:	6a 00                	push   $0x0
  pushl $167
  101a59:	68 a7 00 00 00       	push   $0xa7
  jmp alltraps
  101a5e:	e9 98 f7 ff ff       	jmp    1011fb <alltraps>

00101a63 <vector168>:
.globl vector168
vector168:
  pushl $0
  101a63:	6a 00                	push   $0x0
  pushl $168
  101a65:	68 a8 00 00 00       	push   $0xa8
  jmp alltraps
  101a6a:	e9 8c f7 ff ff       	jmp    1011fb <alltraps>

00101a6f <vector169>:
.globl vector169
vector169:
  pushl $0
  101a6f:	6a 00                	push   $0x0
  pushl $169
  101a71:	68 a9 00 00 00       	push   $0xa9
  jmp alltraps
  101a76:	e9 80 f7 ff ff       	jmp    1011fb <alltraps>

00101a7b <vector170>:
.globl vector170
vector170:
  pushl $0
  101a7b:	6a 00                	push   $0x0
  pushl $170
  101a7d:	68 aa 00 00 00       	push   $0xaa
  jmp alltraps
  101a82:	e9 74 f7 ff ff       	jmp    1011fb <alltraps>

00101a87 <vector171>:
.globl vector171
vector171:
  pushl $0
  101a87:	6a 00                	push   $0x0
  pushl $171
  101a89:	68 ab 00 00 00       	push   $0xab
  jmp alltraps
  101a8e:	e9 68 f7 ff ff       	jmp    1011fb <alltraps>

00101a93 <vector172>:
.globl vector172
vector172:
  pushl $0
  101a93:	6a 00                	push   $0x0
  pushl $172
  101a95:	68 ac 00 00 00       	push   $0xac
  jmp alltraps
  101a9a:	e9 5c f7 ff ff       	jmp    1011fb <alltraps>

00101a9f <vector173>:
.globl vector173
vector173:
  pushl $0
  101a9f:	6a 00                	push   $0x0
  pushl $173
  101aa1:	68 ad 00 00 00       	push   $0xad
  jmp alltraps
  101aa6:	e9 50 f7 ff ff       	jmp    1011fb <alltraps>

00101aab <vector174>:
.globl vector174
vector174:
  pushl $0
  101aab:	6a 00                	push   $0x0
  pushl $174
  101aad:	68 ae 00 00 00       	push   $0xae
  jmp alltraps
  101ab2:	e9 44 f7 ff ff       	jmp    1011fb <alltraps>

00101ab7 <vector175>:
.globl vector175
vector175:
  pushl $0
  101ab7:	6a 00                	push   $0x0
  pushl $175
  101ab9:	68 af 00 00 00       	push   $0xaf
  jmp alltraps
  101abe:	e9 38 f7 ff ff       	jmp    1011fb <alltraps>

00101ac3 <vector176>:
.globl vector176
vector176:
  pushl $0
  101ac3:	6a 00                	push   $0x0
  pushl $176
  101ac5:	68 b0 00 00 00       	push   $0xb0
  jmp alltraps
  101aca:	e9 2c f7 ff ff       	jmp    1011fb <alltraps>

00101acf <vector177>:
.globl vector177
vector177:
  pushl $0
  101acf:	6a 00                	push   $0x0
  pushl $177
  101ad1:	68 b1 00 00 00       	push   $0xb1
  jmp alltraps
  101ad6:	e9 20 f7 ff ff       	jmp    1011fb <alltraps>

00101adb <vector178>:
.globl vector178
vector178:
  pushl $0
  101adb:	6a 00                	push   $0x0
  pushl $178
  101add:	68 b2 00 00 00       	push   $0xb2
  jmp alltraps
  101ae2:	e9 14 f7 ff ff       	jmp    1011fb <alltraps>

00101ae7 <vector179>:
.globl vector179
vector179:
  pushl $0
  101ae7:	6a 00                	push   $0x0
  pushl $179
  101ae9:	68 b3 00 00 00       	push   $0xb3
  jmp alltraps
  101aee:	e9 08 f7 ff ff       	jmp    1011fb <alltraps>

00101af3 <vector180>:
.globl vector180
vector180:
  pushl $0
  101af3:	6a 00                	push   $0x0
  pushl $180
  101af5:	68 b4 00 00 00       	push   $0xb4
  jmp alltraps
  101afa:	e9 fc f6 ff ff       	jmp    1011fb <alltraps>

00101aff <vector181>:
.globl vector181
vector181:
  pushl $0
  101aff:	6a 00                	push   $0x0
  pushl $181
  101b01:	68 b5 00 00 00       	push   $0xb5
  jmp alltraps
  101b06:	e9 f0 f6 ff ff       	jmp    1011fb <alltraps>

00101b0b <vector182>:
.globl vector182
vector182:
  pushl $0
  101b0b:	6a 00                	push   $0x0
  pushl $182
  101b0d:	68 b6 00 00 00       	push   $0xb6
  jmp alltraps
  101b12:	e9 e4 f6 ff ff       	jmp    1011fb <alltraps>

00101b17 <vector183>:
.globl vector183
vector183:
  pushl $0
  101b17:	6a 00                	push   $0x0
  pushl $183
  101b19:	68 b7 00 00 00       	push   $0xb7
  jmp alltraps
  101b1e:	e9 d8 f6 ff ff       	jmp    1011fb <alltraps>

00101b23 <vector184>:
.globl vector184
vector184:
  pushl $0
  101b23:	6a 00                	push   $0x0
  pushl $184
  101b25:	68 b8 00 00 00       	push   $0xb8
  jmp alltraps
  101b2a:	e9 cc f6 ff ff       	jmp    1011fb <alltraps>

00101b2f <vector185>:
.globl vector185
vector185:
  pushl $0
  101b2f:	6a 00                	push   $0x0
  pushl $185
  101b31:	68 b9 00 00 00       	push   $0xb9
  jmp alltraps
  101b36:	e9 c0 f6 ff ff       	jmp    1011fb <alltraps>

00101b3b <vector186>:
.globl vector186
vector186:
  pushl $0
  101b3b:	6a 00                	push   $0x0
  pushl $186
  101b3d:	68 ba 00 00 00       	push   $0xba
  jmp alltraps
  101b42:	e9 b4 f6 ff ff       	jmp    1011fb <alltraps>

00101b47 <vector187>:
.globl vector187
vector187:
  pushl $0
  101b47:	6a 00                	push   $0x0
  pushl $187
  101b49:	68 bb 00 00 00       	push   $0xbb
  jmp alltraps
  101b4e:	e9 a8 f6 ff ff       	jmp    1011fb <alltraps>

00101b53 <vector188>:
.globl vector188
vector188:
  pushl $0
  101b53:	6a 00                	push   $0x0
  pushl $188
  101b55:	68 bc 00 00 00       	push   $0xbc
  jmp alltraps
  101b5a:	e9 9c f6 ff ff       	jmp    1011fb <alltraps>

00101b5f <vector189>:
.globl vector189
vector189:
  pushl $0
  101b5f:	6a 00                	push   $0x0
  pushl $189
  101b61:	68 bd 00 00 00       	push   $0xbd
  jmp alltraps
  101b66:	e9 90 f6 ff ff       	jmp    1011fb <alltraps>

00101b6b <vector190>:
.globl vector190
vector190:
  pushl $0
  101b6b:	6a 00                	push   $0x0
  pushl $190
  101b6d:	68 be 00 00 00       	push   $0xbe
  jmp alltraps
  101b72:	e9 84 f6 ff ff       	jmp    1011fb <alltraps>

00101b77 <vector191>:
.globl vector191
vector191:
  pushl $0
  101b77:	6a 00                	push   $0x0
  pushl $191
  101b79:	68 bf 00 00 00       	push   $0xbf
  jmp alltraps
  101b7e:	e9 78 f6 ff ff       	jmp    1011fb <alltraps>

00101b83 <vector192>:
.globl vector192
vector192:
  pushl $0
  101b83:	6a 00                	push   $0x0
  pushl $192
  101b85:	68 c0 00 00 00       	push   $0xc0
  jmp alltraps
  101b8a:	e9 6c f6 ff ff       	jmp    1011fb <alltraps>

00101b8f <vector193>:
.globl vector193
vector193:
  pushl $0
  101b8f:	6a 00                	push   $0x0
  pushl $193
  101b91:	68 c1 00 00 00       	push   $0xc1
  jmp alltraps
  101b96:	e9 60 f6 ff ff       	jmp    1011fb <alltraps>

00101b9b <vector194>:
.globl vector194
vector194:
  pushl $0
  101b9b:	6a 00                	push   $0x0
  pushl $194
  101b9d:	68 c2 00 00 00       	push   $0xc2
  jmp alltraps
  101ba2:	e9 54 f6 ff ff       	jmp    1011fb <alltraps>

00101ba7 <vector195>:
.globl vector195
vector195:
  pushl $0
  101ba7:	6a 00                	push   $0x0
  pushl $195
  101ba9:	68 c3 00 00 00       	push   $0xc3
  jmp alltraps
  101bae:	e9 48 f6 ff ff       	jmp    1011fb <alltraps>

00101bb3 <vector196>:
.globl vector196
vector196:
  pushl $0
  101bb3:	6a 00                	push   $0x0
  pushl $196
  101bb5:	68 c4 00 00 00       	push   $0xc4
  jmp alltraps
  101bba:	e9 3c f6 ff ff       	jmp    1011fb <alltraps>

00101bbf <vector197>:
.globl vector197
vector197:
  pushl $0
  101bbf:	6a 00                	push   $0x0
  pushl $197
  101bc1:	68 c5 00 00 00       	push   $0xc5
  jmp alltraps
  101bc6:	e9 30 f6 ff ff       	jmp    1011fb <alltraps>

00101bcb <vector198>:
.globl vector198
vector198:
  pushl $0
  101bcb:	6a 00                	push   $0x0
  pushl $198
  101bcd:	68 c6 00 00 00       	push   $0xc6
  jmp alltraps
  101bd2:	e9 24 f6 ff ff       	jmp    1011fb <alltraps>

00101bd7 <vector199>:
.globl vector199
vector199:
  pushl $0
  101bd7:	6a 00                	push   $0x0
  pushl $199
  101bd9:	68 c7 00 00 00       	push   $0xc7
  jmp alltraps
  101bde:	e9 18 f6 ff ff       	jmp    1011fb <alltraps>

00101be3 <vector200>:
.globl vector200
vector200:
  pushl $0
  101be3:	6a 00                	push   $0x0
  pushl $200
  101be5:	68 c8 00 00 00       	push   $0xc8
  jmp alltraps
  101bea:	e9 0c f6 ff ff       	jmp    1011fb <alltraps>

00101bef <vector201>:
.globl vector201
vector201:
  pushl $0
  101bef:	6a 00                	push   $0x0
  pushl $201
  101bf1:	68 c9 00 00 00       	push   $0xc9
  jmp alltraps
  101bf6:	e9 00 f6 ff ff       	jmp    1011fb <alltraps>

00101bfb <vector202>:
.globl vector202
vector202:
  pushl $0
  101bfb:	6a 00                	push   $0x0
  pushl $202
  101bfd:	68 ca 00 00 00       	push   $0xca
  jmp alltraps
  101c02:	e9 f4 f5 ff ff       	jmp    1011fb <alltraps>

00101c07 <vector203>:
.globl vector203
vector203:
  pushl $0
  101c07:	6a 00                	push   $0x0
  pushl $203
  101c09:	68 cb 00 00 00       	push   $0xcb
  jmp alltraps
  101c0e:	e9 e8 f5 ff ff       	jmp    1011fb <alltraps>

00101c13 <vector204>:
.globl vector204
vector204:
  pushl $0
  101c13:	6a 00                	push   $0x0
  pushl $204
  101c15:	68 cc 00 00 00       	push   $0xcc
  jmp alltraps
  101c1a:	e9 dc f5 ff ff       	jmp    1011fb <alltraps>

00101c1f <vector205>:
.globl vector205
vector205:
  pushl $0
  101c1f:	6a 00                	push   $0x0
  pushl $205
  101c21:	68 cd 00 00 00       	push   $0xcd
  jmp alltraps
  101c26:	e9 d0 f5 ff ff       	jmp    1011fb <alltraps>

00101c2b <vector206>:
.globl vector206
vector206:
  pushl $0
  101c2b:	6a 00                	push   $0x0
  pushl $206
  101c2d:	68 ce 00 00 00       	push   $0xce
  jmp alltraps
  101c32:	e9 c4 f5 ff ff       	jmp    1011fb <alltraps>

00101c37 <vector207>:
.globl vector207
vector207:
  pushl $0
  101c37:	6a 00                	push   $0x0
  pushl $207
  101c39:	68 cf 00 00 00       	push   $0xcf
  jmp alltraps
  101c3e:	e9 b8 f5 ff ff       	jmp    1011fb <alltraps>

00101c43 <vector208>:
.globl vector208
vector208:
  pushl $0
  101c43:	6a 00                	push   $0x0
  pushl $208
  101c45:	68 d0 00 00 00       	push   $0xd0
  jmp alltraps
  101c4a:	e9 ac f5 ff ff       	jmp    1011fb <alltraps>

00101c4f <vector209>:
.globl vector209
vector209:
  pushl $0
  101c4f:	6a 00                	push   $0x0
  pushl $209
  101c51:	68 d1 00 00 00       	push   $0xd1
  jmp alltraps
  101c56:	e9 a0 f5 ff ff       	jmp    1011fb <alltraps>

00101c5b <vector210>:
.globl vector210
vector210:
  pushl $0
  101c5b:	6a 00                	push   $0x0
  pushl $210
  101c5d:	68 d2 00 00 00       	push   $0xd2
  jmp alltraps
  101c62:	e9 94 f5 ff ff       	jmp    1011fb <alltraps>

00101c67 <vector211>:
.globl vector211
vector211:
  pushl $0
  101c67:	6a 00                	push   $0x0
  pushl $211
  101c69:	68 d3 00 00 00       	push   $0xd3
  jmp alltraps
  101c6e:	e9 88 f5 ff ff       	jmp    1011fb <alltraps>

00101c73 <vector212>:
.globl vector212
vector212:
  pushl $0
  101c73:	6a 00                	push   $0x0
  pushl $212
  101c75:	68 d4 00 00 00       	push   $0xd4
  jmp alltraps
  101c7a:	e9 7c f5 ff ff       	jmp    1011fb <alltraps>

00101c7f <vector213>:
.globl vector213
vector213:
  pushl $0
  101c7f:	6a 00                	push   $0x0
  pushl $213
  101c81:	68 d5 00 00 00       	push   $0xd5
  jmp alltraps
  101c86:	e9 70 f5 ff ff       	jmp    1011fb <alltraps>

00101c8b <vector214>:
.globl vector214
vector214:
  pushl $0
  101c8b:	6a 00                	push   $0x0
  pushl $214
  101c8d:	68 d6 00 00 00       	push   $0xd6
  jmp alltraps
  101c92:	e9 64 f5 ff ff       	jmp    1011fb <alltraps>

00101c97 <vector215>:
.globl vector215
vector215:
  pushl $0
  101c97:	6a 00                	push   $0x0
  pushl $215
  101c99:	68 d7 00 00 00       	push   $0xd7
  jmp alltraps
  101c9e:	e9 58 f5 ff ff       	jmp    1011fb <alltraps>

00101ca3 <vector216>:
.globl vector216
vector216:
  pushl $0
  101ca3:	6a 00                	push   $0x0
  pushl $216
  101ca5:	68 d8 00 00 00       	push   $0xd8
  jmp alltraps
  101caa:	e9 4c f5 ff ff       	jmp    1011fb <alltraps>

00101caf <vector217>:
.globl vector217
vector217:
  pushl $0
  101caf:	6a 00                	push   $0x0
  pushl $217
  101cb1:	68 d9 00 00 00       	push   $0xd9
  jmp alltraps
  101cb6:	e9 40 f5 ff ff       	jmp    1011fb <alltraps>

00101cbb <vector218>:
.globl vector218
vector218:
  pushl $0
  101cbb:	6a 00                	push   $0x0
  pushl $218
  101cbd:	68 da 00 00 00       	push   $0xda
  jmp alltraps
  101cc2:	e9 34 f5 ff ff       	jmp    1011fb <alltraps>

00101cc7 <vector219>:
.globl vector219
vector219:
  pushl $0
  101cc7:	6a 00                	push   $0x0
  pushl $219
  101cc9:	68 db 00 00 00       	push   $0xdb
  jmp alltraps
  101cce:	e9 28 f5 ff ff       	jmp    1011fb <alltraps>

00101cd3 <vector220>:
.globl vector220
vector220:
  pushl $0
  101cd3:	6a 00                	push   $0x0
  pushl $220
  101cd5:	68 dc 00 00 00       	push   $0xdc
  jmp alltraps
  101cda:	e9 1c f5 ff ff       	jmp    1011fb <alltraps>

00101cdf <vector221>:
.globl vector221
vector221:
  pushl $0
  101cdf:	6a 00                	push   $0x0
  pushl $221
  101ce1:	68 dd 00 00 00       	push   $0xdd
  jmp alltraps
  101ce6:	e9 10 f5 ff ff       	jmp    1011fb <alltraps>

00101ceb <vector222>:
.globl vector222
vector222:
  pushl $0
  101ceb:	6a 00                	push   $0x0
  pushl $222
  101ced:	68 de 00 00 00       	push   $0xde
  jmp alltraps
  101cf2:	e9 04 f5 ff ff       	jmp    1011fb <alltraps>

00101cf7 <vector223>:
.globl vector223
vector223:
  pushl $0
  101cf7:	6a 00                	push   $0x0
  pushl $223
  101cf9:	68 df 00 00 00       	push   $0xdf
  jmp alltraps
  101cfe:	e9 f8 f4 ff ff       	jmp    1011fb <alltraps>

00101d03 <vector224>:
.globl vector224
vector224:
  pushl $0
  101d03:	6a 00                	push   $0x0
  pushl $224
  101d05:	68 e0 00 00 00       	push   $0xe0
  jmp alltraps
  101d0a:	e9 ec f4 ff ff       	jmp    1011fb <alltraps>

00101d0f <vector225>:
.globl vector225
vector225:
  pushl $0
  101d0f:	6a 00                	push   $0x0
  pushl $225
  101d11:	68 e1 00 00 00       	push   $0xe1
  jmp alltraps
  101d16:	e9 e0 f4 ff ff       	jmp    1011fb <alltraps>

00101d1b <vector226>:
.globl vector226
vector226:
  pushl $0
  101d1b:	6a 00                	push   $0x0
  pushl $226
  101d1d:	68 e2 00 00 00       	push   $0xe2
  jmp alltraps
  101d22:	e9 d4 f4 ff ff       	jmp    1011fb <alltraps>

00101d27 <vector227>:
.globl vector227
vector227:
  pushl $0
  101d27:	6a 00                	push   $0x0
  pushl $227
  101d29:	68 e3 00 00 00       	push   $0xe3
  jmp alltraps
  101d2e:	e9 c8 f4 ff ff       	jmp    1011fb <alltraps>

00101d33 <vector228>:
.globl vector228
vector228:
  pushl $0
  101d33:	6a 00                	push   $0x0
  pushl $228
  101d35:	68 e4 00 00 00       	push   $0xe4
  jmp alltraps
  101d3a:	e9 bc f4 ff ff       	jmp    1011fb <alltraps>

00101d3f <vector229>:
.globl vector229
vector229:
  pushl $0
  101d3f:	6a 00                	push   $0x0
  pushl $229
  101d41:	68 e5 00 00 00       	push   $0xe5
  jmp alltraps
  101d46:	e9 b0 f4 ff ff       	jmp    1011fb <alltraps>

00101d4b <vector230>:
.globl vector230
vector230:
  pushl $0
  101d4b:	6a 00                	push   $0x0
  pushl $230
  101d4d:	68 e6 00 00 00       	push   $0xe6
  jmp alltraps
  101d52:	e9 a4 f4 ff ff       	jmp    1011fb <alltraps>

00101d57 <vector231>:
.globl vector231
vector231:
  pushl $0
  101d57:	6a 00                	push   $0x0
  pushl $231
  101d59:	68 e7 00 00 00       	push   $0xe7
  jmp alltraps
  101d5e:	e9 98 f4 ff ff       	jmp    1011fb <alltraps>

00101d63 <vector232>:
.globl vector232
vector232:
  pushl $0
  101d63:	6a 00                	push   $0x0
  pushl $232
  101d65:	68 e8 00 00 00       	push   $0xe8
  jmp alltraps
  101d6a:	e9 8c f4 ff ff       	jmp    1011fb <alltraps>

00101d6f <vector233>:
.globl vector233
vector233:
  pushl $0
  101d6f:	6a 00                	push   $0x0
  pushl $233
  101d71:	68 e9 00 00 00       	push   $0xe9
  jmp alltraps
  101d76:	e9 80 f4 ff ff       	jmp    1011fb <alltraps>

00101d7b <vector234>:
.globl vector234
vector234:
  pushl $0
  101d7b:	6a 00                	push   $0x0
  pushl $234
  101d7d:	68 ea 00 00 00       	push   $0xea
  jmp alltraps
  101d82:	e9 74 f4 ff ff       	jmp    1011fb <alltraps>

00101d87 <vector235>:
.globl vector235
vector235:
  pushl $0
  101d87:	6a 00                	push   $0x0
  pushl $235
  101d89:	68 eb 00 00 00       	push   $0xeb
  jmp alltraps
  101d8e:	e9 68 f4 ff ff       	jmp    1011fb <alltraps>

00101d93 <vector236>:
.globl vector236
vector236:
  pushl $0
  101d93:	6a 00                	push   $0x0
  pushl $236
  101d95:	68 ec 00 00 00       	push   $0xec
  jmp alltraps
  101d9a:	e9 5c f4 ff ff       	jmp    1011fb <alltraps>

00101d9f <vector237>:
.globl vector237
vector237:
  pushl $0
  101d9f:	6a 00                	push   $0x0
  pushl $237
  101da1:	68 ed 00 00 00       	push   $0xed
  jmp alltraps
  101da6:	e9 50 f4 ff ff       	jmp    1011fb <alltraps>

00101dab <vector238>:
.globl vector238
vector238:
  pushl $0
  101dab:	6a 00                	push   $0x0
  pushl $238
  101dad:	68 ee 00 00 00       	push   $0xee
  jmp alltraps
  101db2:	e9 44 f4 ff ff       	jmp    1011fb <alltraps>

00101db7 <vector239>:
.globl vector239
vector239:
  pushl $0
  101db7:	6a 00                	push   $0x0
  pushl $239
  101db9:	68 ef 00 00 00       	push   $0xef
  jmp alltraps
  101dbe:	e9 38 f4 ff ff       	jmp    1011fb <alltraps>

00101dc3 <vector240>:
.globl vector240
vector240:
  pushl $0
  101dc3:	6a 00                	push   $0x0
  pushl $240
  101dc5:	68 f0 00 00 00       	push   $0xf0
  jmp alltraps
  101dca:	e9 2c f4 ff ff       	jmp    1011fb <alltraps>

00101dcf <vector241>:
.globl vector241
vector241:
  pushl $0
  101dcf:	6a 00                	push   $0x0
  pushl $241
  101dd1:	68 f1 00 00 00       	push   $0xf1
  jmp alltraps
  101dd6:	e9 20 f4 ff ff       	jmp    1011fb <alltraps>

00101ddb <vector242>:
.globl vector242
vector242:
  pushl $0
  101ddb:	6a 00                	push   $0x0
  pushl $242
  101ddd:	68 f2 00 00 00       	push   $0xf2
  jmp alltraps
  101de2:	e9 14 f4 ff ff       	jmp    1011fb <alltraps>

00101de7 <vector243>:
.globl vector243
vector243:
  pushl $0
  101de7:	6a 00                	push   $0x0
  pushl $243
  101de9:	68 f3 00 00 00       	push   $0xf3
  jmp alltraps
  101dee:	e9 08 f4 ff ff       	jmp    1011fb <alltraps>

00101df3 <vector244>:
.globl vector244
vector244:
  pushl $0
  101df3:	6a 00                	push   $0x0
  pushl $244
  101df5:	68 f4 00 00 00       	push   $0xf4
  jmp alltraps
  101dfa:	e9 fc f3 ff ff       	jmp    1011fb <alltraps>

00101dff <vector245>:
.globl vector245
vector245:
  pushl $0
  101dff:	6a 00                	push   $0x0
  pushl $245
  101e01:	68 f5 00 00 00       	push   $0xf5
  jmp alltraps
  101e06:	e9 f0 f3 ff ff       	jmp    1011fb <alltraps>

00101e0b <vector246>:
.globl vector246
vector246:
  pushl $0
  101e0b:	6a 00                	push   $0x0
  pushl $246
  101e0d:	68 f6 00 00 00       	push   $0xf6
  jmp alltraps
  101e12:	e9 e4 f3 ff ff       	jmp    1011fb <alltraps>

00101e17 <vector247>:
.globl vector247
vector247:
  pushl $0
  101e17:	6a 00                	push   $0x0
  pushl $247
  101e19:	68 f7 00 00 00       	push   $0xf7
  jmp alltraps
  101e1e:	e9 d8 f3 ff ff       	jmp    1011fb <alltraps>

00101e23 <vector248>:
.globl vector248
vector248:
  pushl $0
  101e23:	6a 00                	push   $0x0
  pushl $248
  101e25:	68 f8 00 00 00       	push   $0xf8
  jmp alltraps
  101e2a:	e9 cc f3 ff ff       	jmp    1011fb <alltraps>

00101e2f <vector249>:
.globl vector249
vector249:
  pushl $0
  101e2f:	6a 00                	push   $0x0
  pushl $249
  101e31:	68 f9 00 00 00       	push   $0xf9
  jmp alltraps
  101e36:	e9 c0 f3 ff ff       	jmp    1011fb <alltraps>

00101e3b <vector250>:
.globl vector250
vector250:
  pushl $0
  101e3b:	6a 00                	push   $0x0
  pushl $250
  101e3d:	68 fa 00 00 00       	push   $0xfa
  jmp alltraps
  101e42:	e9 b4 f3 ff ff       	jmp    1011fb <alltraps>

00101e47 <vector251>:
.globl vector251
vector251:
  pushl $0
  101e47:	6a 00                	push   $0x0
  pushl $251
  101e49:	68 fb 00 00 00       	push   $0xfb
  jmp alltraps
  101e4e:	e9 a8 f3 ff ff       	jmp    1011fb <alltraps>

00101e53 <vector252>:
.globl vector252
vector252:
  pushl $0
  101e53:	6a 00                	push   $0x0
  pushl $252
  101e55:	68 fc 00 00 00       	push   $0xfc
  jmp alltraps
  101e5a:	e9 9c f3 ff ff       	jmp    1011fb <alltraps>

00101e5f <vector253>:
.globl vector253
vector253:
  pushl $0
  101e5f:	6a 00                	push   $0x0
  pushl $253
  101e61:	68 fd 00 00 00       	push   $0xfd
  jmp alltraps
  101e66:	e9 90 f3 ff ff       	jmp    1011fb <alltraps>

00101e6b <vector254>:
.globl vector254
vector254:
  pushl $0
  101e6b:	6a 00                	push   $0x0
  pushl $254
  101e6d:	68 fe 00 00 00       	push   $0xfe
  jmp alltraps
  101e72:	e9 84 f3 ff ff       	jmp    1011fb <alltraps>

00101e77 <vector255>:
.globl vector255
vector255:
  pushl $0
  101e77:	6a 00                	push   $0x0
  pushl $255
  101e79:	68 ff 00 00 00       	push   $0xff
  jmp alltraps
  101e7e:	e9 78 f3 ff ff       	jmp    1011fb <alltraps>

00101e83 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
  101e83:	55                   	push   %ebp
  101e84:	89 e5                	mov    %esp,%ebp
  101e86:	83 ec 10             	sub    $0x10,%esp
  struct buf *b;

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
  101e89:	c7 05 58 9c 10 00 48 	movl   $0x109c48,0x109c58
  101e90:	9c 10 00 
  bcache.head.next = &bcache.head;
  101e93:	c7 05 5c 9c 10 00 48 	movl   $0x109c48,0x109c5c
  101e9a:	9c 10 00 
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
  101e9d:	c7 45 fc 00 5d 10 00 	movl   $0x105d00,-0x4(%ebp)
  101ea4:	eb 30                	jmp    101ed6 <binit+0x53>
    b->next = bcache.head.next;
  101ea6:	8b 15 5c 9c 10 00    	mov    0x109c5c,%edx
  101eac:	8b 45 fc             	mov    -0x4(%ebp),%eax
  101eaf:	89 50 14             	mov    %edx,0x14(%eax)
    b->prev = &bcache.head;
  101eb2:	8b 45 fc             	mov    -0x4(%ebp),%eax
  101eb5:	c7 40 10 48 9c 10 00 	movl   $0x109c48,0x10(%eax)
    bcache.head.next->prev = b;
  101ebc:	a1 5c 9c 10 00       	mov    0x109c5c,%eax
  101ec1:	8b 55 fc             	mov    -0x4(%ebp),%edx
  101ec4:	89 50 10             	mov    %edx,0x10(%eax)
    bcache.head.next = b;
  101ec7:	8b 45 fc             	mov    -0x4(%ebp),%eax
  101eca:	a3 5c 9c 10 00       	mov    %eax,0x109c5c
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
  101ecf:	81 45 fc 1c 02 00 00 	addl   $0x21c,-0x4(%ebp)
  101ed6:	b8 48 9c 10 00       	mov    $0x109c48,%eax
  101edb:	39 45 fc             	cmp    %eax,-0x4(%ebp)
  101ede:	72 c6                	jb     101ea6 <binit+0x23>
  }
}
  101ee0:	90                   	nop
  101ee1:	90                   	nop
  101ee2:	c9                   	leave
  101ee3:	c3                   	ret

00101ee4 <bget>:
// Look through buffer cache for block on device dev.
// If not found, allocate a buffer.
// In either case, return locked buffer.
static struct buf*
bget(uint dev, uint blockno)
{
  101ee4:	55                   	push   %ebp
  101ee5:	89 e5                	mov    %esp,%ebp
  101ee7:	83 ec 18             	sub    $0x18,%esp
  struct buf *b;

  // Is the block already cached?
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
  101eea:	a1 5c 9c 10 00       	mov    0x109c5c,%eax
  101eef:	89 45 f4             	mov    %eax,-0xc(%ebp)
  101ef2:	eb 33                	jmp    101f27 <bget+0x43>
    if(b->dev == dev && b->blockno == blockno){
  101ef4:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101ef7:	8b 40 04             	mov    0x4(%eax),%eax
  101efa:	39 45 08             	cmp    %eax,0x8(%ebp)
  101efd:	75 1f                	jne    101f1e <bget+0x3a>
  101eff:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101f02:	8b 40 08             	mov    0x8(%eax),%eax
  101f05:	39 45 0c             	cmp    %eax,0xc(%ebp)
  101f08:	75 14                	jne    101f1e <bget+0x3a>
      b->refcnt++;
  101f0a:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101f0d:	8b 40 0c             	mov    0xc(%eax),%eax
  101f10:	8d 50 01             	lea    0x1(%eax),%edx
  101f13:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101f16:	89 50 0c             	mov    %edx,0xc(%eax)
      return b;
  101f19:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101f1c:	eb 7b                	jmp    101f99 <bget+0xb5>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
  101f1e:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101f21:	8b 40 14             	mov    0x14(%eax),%eax
  101f24:	89 45 f4             	mov    %eax,-0xc(%ebp)
  101f27:	81 7d f4 48 9c 10 00 	cmpl   $0x109c48,-0xc(%ebp)
  101f2e:	75 c4                	jne    101ef4 <bget+0x10>
  }

  // Not cached; recycle an unused buffer.
  // Even if refcnt==0, B_DIRTY indicates a buffer is in use
  // because log.c has modified it but not yet committed it.
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
  101f30:	a1 58 9c 10 00       	mov    0x109c58,%eax
  101f35:	89 45 f4             	mov    %eax,-0xc(%ebp)
  101f38:	eb 49                	jmp    101f83 <bget+0x9f>
    if(b->refcnt == 0 && (b->flags & B_DIRTY) == 0) {
  101f3a:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101f3d:	8b 40 0c             	mov    0xc(%eax),%eax
  101f40:	85 c0                	test   %eax,%eax
  101f42:	75 36                	jne    101f7a <bget+0x96>
  101f44:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101f47:	8b 00                	mov    (%eax),%eax
  101f49:	83 e0 04             	and    $0x4,%eax
  101f4c:	85 c0                	test   %eax,%eax
  101f4e:	75 2a                	jne    101f7a <bget+0x96>
      b->dev = dev;
  101f50:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101f53:	8b 55 08             	mov    0x8(%ebp),%edx
  101f56:	89 50 04             	mov    %edx,0x4(%eax)
      b->blockno = blockno;
  101f59:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101f5c:	8b 55 0c             	mov    0xc(%ebp),%edx
  101f5f:	89 50 08             	mov    %edx,0x8(%eax)
      b->flags = 0;
  101f62:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101f65:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
      b->refcnt = 1;
  101f6b:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101f6e:	c7 40 0c 01 00 00 00 	movl   $0x1,0xc(%eax)
      return b;
  101f75:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101f78:	eb 1f                	jmp    101f99 <bget+0xb5>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
  101f7a:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101f7d:	8b 40 10             	mov    0x10(%eax),%eax
  101f80:	89 45 f4             	mov    %eax,-0xc(%ebp)
  101f83:	81 7d f4 48 9c 10 00 	cmpl   $0x109c48,-0xc(%ebp)
  101f8a:	75 ae                	jne    101f3a <bget+0x56>
    }
  }
  panic("bget: no buffers");
  101f8c:	83 ec 0c             	sub    $0xc,%esp
  101f8f:	68 df 41 10 00       	push   $0x1041df
  101f94:	e8 15 e3 ff ff       	call   1002ae <panic>
}
  101f99:	c9                   	leave
  101f9a:	c3                   	ret

00101f9b <bread>:

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
  101f9b:	55                   	push   %ebp
  101f9c:	89 e5                	mov    %esp,%ebp
  101f9e:	83 ec 18             	sub    $0x18,%esp
  struct buf *b;

  b = bget(dev, blockno);
  101fa1:	83 ec 08             	sub    $0x8,%esp
  101fa4:	ff 75 0c             	push   0xc(%ebp)
  101fa7:	ff 75 08             	push   0x8(%ebp)
  101faa:	e8 35 ff ff ff       	call   101ee4 <bget>
  101faf:	83 c4 10             	add    $0x10,%esp
  101fb2:	89 45 f4             	mov    %eax,-0xc(%ebp)
  if((b->flags & B_VALID) == 0) {
  101fb5:	8b 45 f4             	mov    -0xc(%ebp),%eax
  101fb8:	8b 00                	mov    (%eax),%eax
  101fba:	83 e0 02             	and    $0x2,%eax
  101fbd:	85 c0                	test   %eax,%eax
  101fbf:	75 0e                	jne    101fcf <bread+0x34>
    iderw(b);
  101fc1:	83 ec 0c             	sub    $0xc,%esp
  101fc4:	ff 75 f4             	push   -0xc(%ebp)
  101fc7:	e8 30 04 00 00       	call   1023fc <iderw>
  101fcc:	83 c4 10             	add    $0x10,%esp
  }
  return b;
  101fcf:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
  101fd2:	c9                   	leave
  101fd3:	c3                   	ret

00101fd4 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
  101fd4:	55                   	push   %ebp
  101fd5:	89 e5                	mov    %esp,%ebp
  101fd7:	83 ec 08             	sub    $0x8,%esp
  b->flags |= B_DIRTY;
  101fda:	8b 45 08             	mov    0x8(%ebp),%eax
  101fdd:	8b 00                	mov    (%eax),%eax
  101fdf:	83 c8 04             	or     $0x4,%eax
  101fe2:	89 c2                	mov    %eax,%edx
  101fe4:	8b 45 08             	mov    0x8(%ebp),%eax
  101fe7:	89 10                	mov    %edx,(%eax)
  iderw(b);
  101fe9:	83 ec 0c             	sub    $0xc,%esp
  101fec:	ff 75 08             	push   0x8(%ebp)
  101fef:	e8 08 04 00 00       	call   1023fc <iderw>
  101ff4:	83 c4 10             	add    $0x10,%esp
}
  101ff7:	90                   	nop
  101ff8:	c9                   	leave
  101ff9:	c3                   	ret

00101ffa <bread_wr>:

struct buf* 
bread_wr(uint dev, uint blockno) {
  101ffa:	55                   	push   %ebp
  101ffb:	89 e5                	mov    %esp,%ebp
  101ffd:	83 ec 08             	sub    $0x8,%esp
  // IMPLEMENT YOUR CODE HERE

  return bread(dev,blockno);
  102000:	83 ec 08             	sub    $0x8,%esp
  102003:	ff 75 0c             	push   0xc(%ebp)
  102006:	ff 75 08             	push   0x8(%ebp)
  102009:	e8 8d ff ff ff       	call   101f9b <bread>
  10200e:	83 c4 10             	add    $0x10,%esp
}
  102011:	c9                   	leave
  102012:	c3                   	ret

00102013 <brelse>:

// Release a buffer.
// Move to the head of the MRU list.
void
brelse(struct buf *b)
{
  102013:	55                   	push   %ebp
  102014:	89 e5                	mov    %esp,%ebp
  b->refcnt--;
  102016:	8b 45 08             	mov    0x8(%ebp),%eax
  102019:	8b 40 0c             	mov    0xc(%eax),%eax
  10201c:	8d 50 ff             	lea    -0x1(%eax),%edx
  10201f:	8b 45 08             	mov    0x8(%ebp),%eax
  102022:	89 50 0c             	mov    %edx,0xc(%eax)
  if (b->refcnt == 0) {
  102025:	8b 45 08             	mov    0x8(%ebp),%eax
  102028:	8b 40 0c             	mov    0xc(%eax),%eax
  10202b:	85 c0                	test   %eax,%eax
  10202d:	75 47                	jne    102076 <brelse+0x63>
    // no one is waiting for it.
    b->next->prev = b->prev;
  10202f:	8b 45 08             	mov    0x8(%ebp),%eax
  102032:	8b 40 14             	mov    0x14(%eax),%eax
  102035:	8b 55 08             	mov    0x8(%ebp),%edx
  102038:	8b 52 10             	mov    0x10(%edx),%edx
  10203b:	89 50 10             	mov    %edx,0x10(%eax)
    b->prev->next = b->next;
  10203e:	8b 45 08             	mov    0x8(%ebp),%eax
  102041:	8b 40 10             	mov    0x10(%eax),%eax
  102044:	8b 55 08             	mov    0x8(%ebp),%edx
  102047:	8b 52 14             	mov    0x14(%edx),%edx
  10204a:	89 50 14             	mov    %edx,0x14(%eax)
    b->next = bcache.head.next;
  10204d:	8b 15 5c 9c 10 00    	mov    0x109c5c,%edx
  102053:	8b 45 08             	mov    0x8(%ebp),%eax
  102056:	89 50 14             	mov    %edx,0x14(%eax)
    b->prev = &bcache.head;
  102059:	8b 45 08             	mov    0x8(%ebp),%eax
  10205c:	c7 40 10 48 9c 10 00 	movl   $0x109c48,0x10(%eax)
    bcache.head.next->prev = b;
  102063:	a1 5c 9c 10 00       	mov    0x109c5c,%eax
  102068:	8b 55 08             	mov    0x8(%ebp),%edx
  10206b:	89 50 10             	mov    %edx,0x10(%eax)
    bcache.head.next = b;
  10206e:	8b 45 08             	mov    0x8(%ebp),%eax
  102071:	a3 5c 9c 10 00       	mov    %eax,0x109c5c
  }
  102076:	90                   	nop
  102077:	5d                   	pop    %ebp
  102078:	c3                   	ret

00102079 <inb>:
{
  102079:	55                   	push   %ebp
  10207a:	89 e5                	mov    %esp,%ebp
  10207c:	83 ec 14             	sub    $0x14,%esp
  10207f:	8b 45 08             	mov    0x8(%ebp),%eax
  102082:	66 89 45 ec          	mov    %ax,-0x14(%ebp)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
  102086:	0f b7 45 ec          	movzwl -0x14(%ebp),%eax
  10208a:	89 c2                	mov    %eax,%edx
  10208c:	ec                   	in     (%dx),%al
  10208d:	88 45 ff             	mov    %al,-0x1(%ebp)
  return data;
  102090:	0f b6 45 ff          	movzbl -0x1(%ebp),%eax
}
  102094:	c9                   	leave
  102095:	c3                   	ret

00102096 <insl>:
{
  102096:	55                   	push   %ebp
  102097:	89 e5                	mov    %esp,%ebp
  102099:	57                   	push   %edi
  10209a:	53                   	push   %ebx
  asm volatile("cld; rep insl" :
  10209b:	8b 55 08             	mov    0x8(%ebp),%edx
  10209e:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  1020a1:	8b 45 10             	mov    0x10(%ebp),%eax
  1020a4:	89 cb                	mov    %ecx,%ebx
  1020a6:	89 df                	mov    %ebx,%edi
  1020a8:	89 c1                	mov    %eax,%ecx
  1020aa:	fc                   	cld
  1020ab:	f3 6d                	rep insl (%dx),%es:(%edi)
  1020ad:	89 c8                	mov    %ecx,%eax
  1020af:	89 fb                	mov    %edi,%ebx
  1020b1:	89 5d 0c             	mov    %ebx,0xc(%ebp)
  1020b4:	89 45 10             	mov    %eax,0x10(%ebp)
}
  1020b7:	90                   	nop
  1020b8:	5b                   	pop    %ebx
  1020b9:	5f                   	pop    %edi
  1020ba:	5d                   	pop    %ebp
  1020bb:	c3                   	ret

001020bc <outb>:
{
  1020bc:	55                   	push   %ebp
  1020bd:	89 e5                	mov    %esp,%ebp
  1020bf:	83 ec 08             	sub    $0x8,%esp
  1020c2:	8b 55 08             	mov    0x8(%ebp),%edx
  1020c5:	8b 45 0c             	mov    0xc(%ebp),%eax
  1020c8:	66 89 55 fc          	mov    %dx,-0x4(%ebp)
  1020cc:	88 45 f8             	mov    %al,-0x8(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
  1020cf:	0f b6 45 f8          	movzbl -0x8(%ebp),%eax
  1020d3:	0f b7 55 fc          	movzwl -0x4(%ebp),%edx
  1020d7:	ee                   	out    %al,(%dx)
}
  1020d8:	90                   	nop
  1020d9:	c9                   	leave
  1020da:	c3                   	ret

001020db <outsl>:
{
  1020db:	55                   	push   %ebp
  1020dc:	89 e5                	mov    %esp,%ebp
  1020de:	56                   	push   %esi
  1020df:	53                   	push   %ebx
  asm volatile("cld; rep outsl" :
  1020e0:	8b 55 08             	mov    0x8(%ebp),%edx
  1020e3:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  1020e6:	8b 45 10             	mov    0x10(%ebp),%eax
  1020e9:	89 cb                	mov    %ecx,%ebx
  1020eb:	89 de                	mov    %ebx,%esi
  1020ed:	89 c1                	mov    %eax,%ecx
  1020ef:	fc                   	cld
  1020f0:	f3 6f                	rep outsl %ds:(%esi),(%dx)
  1020f2:	89 c8                	mov    %ecx,%eax
  1020f4:	89 f3                	mov    %esi,%ebx
  1020f6:	89 5d 0c             	mov    %ebx,0xc(%ebp)
  1020f9:	89 45 10             	mov    %eax,0x10(%ebp)
}
  1020fc:	90                   	nop
  1020fd:	5b                   	pop    %ebx
  1020fe:	5e                   	pop    %esi
  1020ff:	5d                   	pop    %ebp
  102100:	c3                   	ret

00102101 <noop>:

static inline void
noop(void)
{
  102101:	55                   	push   %ebp
  102102:	89 e5                	mov    %esp,%ebp
  asm volatile("nop");
  102104:	90                   	nop
}
  102105:	90                   	nop
  102106:	5d                   	pop    %ebp
  102107:	c3                   	ret

00102108 <idewait>:
static void idestart(struct buf*);

// Wait for IDE disk to become ready.
static int
idewait(int checkerr)
{
  102108:	55                   	push   %ebp
  102109:	89 e5                	mov    %esp,%ebp
  10210b:	83 ec 10             	sub    $0x10,%esp
  int r;

  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY);
  10210e:	90                   	nop
  10210f:	68 f7 01 00 00       	push   $0x1f7
  102114:	e8 60 ff ff ff       	call   102079 <inb>
  102119:	83 c4 04             	add    $0x4,%esp
  10211c:	0f b6 c0             	movzbl %al,%eax
  10211f:	89 45 fc             	mov    %eax,-0x4(%ebp)
  102122:	8b 45 fc             	mov    -0x4(%ebp),%eax
  102125:	25 c0 00 00 00       	and    $0xc0,%eax
  10212a:	83 f8 40             	cmp    $0x40,%eax
  10212d:	75 e0                	jne    10210f <idewait+0x7>
  if(checkerr && (r & (IDE_DF|IDE_ERR)) != 0)
  10212f:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
  102133:	74 11                	je     102146 <idewait+0x3e>
  102135:	8b 45 fc             	mov    -0x4(%ebp),%eax
  102138:	83 e0 21             	and    $0x21,%eax
  10213b:	85 c0                	test   %eax,%eax
  10213d:	74 07                	je     102146 <idewait+0x3e>
    return -1;
  10213f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  102144:	eb 05                	jmp    10214b <idewait+0x43>
  return 0;
  102146:	b8 00 00 00 00       	mov    $0x0,%eax
}
  10214b:	c9                   	leave
  10214c:	c3                   	ret

0010214d <ideinit>:

void
ideinit(void)
{
  10214d:	55                   	push   %ebp
  10214e:	89 e5                	mov    %esp,%ebp
  102150:	83 ec 18             	sub    $0x18,%esp
  int i;

  // initlock(&idelock, "ide");
  ioapicenable(IRQ_IDE, ncpu - 1);
  102153:	a1 c0 54 10 00       	mov    0x1054c0,%eax
  102158:	83 e8 01             	sub    $0x1,%eax
  10215b:	83 ec 08             	sub    $0x8,%esp
  10215e:	50                   	push   %eax
  10215f:	6a 0e                	push   $0xe
  102161:	e8 32 e4 ff ff       	call   100598 <ioapicenable>
  102166:	83 c4 10             	add    $0x10,%esp
  idewait(0);
  102169:	83 ec 0c             	sub    $0xc,%esp
  10216c:	6a 00                	push   $0x0
  10216e:	e8 95 ff ff ff       	call   102108 <idewait>
  102173:	83 c4 10             	add    $0x10,%esp

  // Check if disk 1 is present
  outb(0x1f6, 0xe0 | (1<<4));
  102176:	83 ec 08             	sub    $0x8,%esp
  102179:	68 f0 00 00 00       	push   $0xf0
  10217e:	68 f6 01 00 00       	push   $0x1f6
  102183:	e8 34 ff ff ff       	call   1020bc <outb>
  102188:	83 c4 10             	add    $0x10,%esp
  for(i=0; i<1000; i++){
  10218b:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  102192:	eb 24                	jmp    1021b8 <ideinit+0x6b>
    if(inb(0x1f7) != 0){
  102194:	83 ec 0c             	sub    $0xc,%esp
  102197:	68 f7 01 00 00       	push   $0x1f7
  10219c:	e8 d8 fe ff ff       	call   102079 <inb>
  1021a1:	83 c4 10             	add    $0x10,%esp
  1021a4:	84 c0                	test   %al,%al
  1021a6:	74 0c                	je     1021b4 <ideinit+0x67>
      havedisk1 = 1;
  1021a8:	c7 05 68 9e 10 00 01 	movl   $0x1,0x109e68
  1021af:	00 00 00 
      break;
  1021b2:	eb 0d                	jmp    1021c1 <ideinit+0x74>
  for(i=0; i<1000; i++){
  1021b4:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  1021b8:	81 7d f4 e7 03 00 00 	cmpl   $0x3e7,-0xc(%ebp)
  1021bf:	7e d3                	jle    102194 <ideinit+0x47>
    }
  }

  // Switch back to disk 0.
  outb(0x1f6, 0xe0 | (0<<4));
  1021c1:	83 ec 08             	sub    $0x8,%esp
  1021c4:	68 e0 00 00 00       	push   $0xe0
  1021c9:	68 f6 01 00 00       	push   $0x1f6
  1021ce:	e8 e9 fe ff ff       	call   1020bc <outb>
  1021d3:	83 c4 10             	add    $0x10,%esp
}
  1021d6:	90                   	nop
  1021d7:	c9                   	leave
  1021d8:	c3                   	ret

001021d9 <idestart>:

// Start the request for b.  Caller must hold idelock.
static void
idestart(struct buf *b)
{
  1021d9:	55                   	push   %ebp
  1021da:	89 e5                	mov    %esp,%ebp
  1021dc:	83 ec 18             	sub    $0x18,%esp
  if(b == 0)
  1021df:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
  1021e3:	75 0d                	jne    1021f2 <idestart+0x19>
    panic("idestart");
  1021e5:	83 ec 0c             	sub    $0xc,%esp
  1021e8:	68 f0 41 10 00       	push   $0x1041f0
  1021ed:	e8 bc e0 ff ff       	call   1002ae <panic>
  if(b->blockno >= FSSIZE)
  1021f2:	8b 45 08             	mov    0x8(%ebp),%eax
  1021f5:	8b 40 08             	mov    0x8(%eax),%eax
  1021f8:	3d e7 03 00 00       	cmp    $0x3e7,%eax
  1021fd:	76 0d                	jbe    10220c <idestart+0x33>
    panic("incorrect blockno");
  1021ff:	83 ec 0c             	sub    $0xc,%esp
  102202:	68 f9 41 10 00       	push   $0x1041f9
  102207:	e8 a2 e0 ff ff       	call   1002ae <panic>
  int sector_per_block =  BSIZE/SECTOR_SIZE;
  10220c:	c7 45 ec 01 00 00 00 	movl   $0x1,-0x14(%ebp)
  int sector = b->blockno * sector_per_block;
  102213:	8b 45 08             	mov    0x8(%ebp),%eax
  102216:	8b 50 08             	mov    0x8(%eax),%edx
  102219:	8b 45 ec             	mov    -0x14(%ebp),%eax
  10221c:	0f af c2             	imul   %edx,%eax
  10221f:	89 45 e8             	mov    %eax,-0x18(%ebp)
  int read_cmd = (sector_per_block == 1) ? IDE_CMD_READ :  IDE_CMD_RDMUL;
  102222:	83 7d ec 01          	cmpl   $0x1,-0x14(%ebp)
  102226:	75 09                	jne    102231 <idestart+0x58>
  102228:	c7 45 f4 20 00 00 00 	movl   $0x20,-0xc(%ebp)
  10222f:	eb 07                	jmp    102238 <idestart+0x5f>
  102231:	c7 45 f4 c4 00 00 00 	movl   $0xc4,-0xc(%ebp)
  int write_cmd = (sector_per_block == 1) ? IDE_CMD_WRITE : IDE_CMD_WRMUL;
  102238:	83 7d ec 01          	cmpl   $0x1,-0x14(%ebp)
  10223c:	75 09                	jne    102247 <idestart+0x6e>
  10223e:	c7 45 f0 30 00 00 00 	movl   $0x30,-0x10(%ebp)
  102245:	eb 07                	jmp    10224e <idestart+0x75>
  102247:	c7 45 f0 c5 00 00 00 	movl   $0xc5,-0x10(%ebp)

  if (sector_per_block > 7) panic("idestart");
  10224e:	83 7d ec 07          	cmpl   $0x7,-0x14(%ebp)
  102252:	7e 0d                	jle    102261 <idestart+0x88>
  102254:	83 ec 0c             	sub    $0xc,%esp
  102257:	68 f0 41 10 00       	push   $0x1041f0
  10225c:	e8 4d e0 ff ff       	call   1002ae <panic>

  idewait(0);
  102261:	83 ec 0c             	sub    $0xc,%esp
  102264:	6a 00                	push   $0x0
  102266:	e8 9d fe ff ff       	call   102108 <idewait>
  10226b:	83 c4 10             	add    $0x10,%esp
  outb(0x3f6, 0);  // generate interrupt
  10226e:	83 ec 08             	sub    $0x8,%esp
  102271:	6a 00                	push   $0x0
  102273:	68 f6 03 00 00       	push   $0x3f6
  102278:	e8 3f fe ff ff       	call   1020bc <outb>
  10227d:	83 c4 10             	add    $0x10,%esp
  outb(0x1f2, sector_per_block);  // number of sectors
  102280:	8b 45 ec             	mov    -0x14(%ebp),%eax
  102283:	0f b6 c0             	movzbl %al,%eax
  102286:	83 ec 08             	sub    $0x8,%esp
  102289:	50                   	push   %eax
  10228a:	68 f2 01 00 00       	push   $0x1f2
  10228f:	e8 28 fe ff ff       	call   1020bc <outb>
  102294:	83 c4 10             	add    $0x10,%esp
  outb(0x1f3, sector & 0xff);
  102297:	8b 45 e8             	mov    -0x18(%ebp),%eax
  10229a:	0f b6 c0             	movzbl %al,%eax
  10229d:	83 ec 08             	sub    $0x8,%esp
  1022a0:	50                   	push   %eax
  1022a1:	68 f3 01 00 00       	push   $0x1f3
  1022a6:	e8 11 fe ff ff       	call   1020bc <outb>
  1022ab:	83 c4 10             	add    $0x10,%esp
  outb(0x1f4, (sector >> 8) & 0xff);
  1022ae:	8b 45 e8             	mov    -0x18(%ebp),%eax
  1022b1:	c1 f8 08             	sar    $0x8,%eax
  1022b4:	0f b6 c0             	movzbl %al,%eax
  1022b7:	83 ec 08             	sub    $0x8,%esp
  1022ba:	50                   	push   %eax
  1022bb:	68 f4 01 00 00       	push   $0x1f4
  1022c0:	e8 f7 fd ff ff       	call   1020bc <outb>
  1022c5:	83 c4 10             	add    $0x10,%esp
  outb(0x1f5, (sector >> 16) & 0xff);
  1022c8:	8b 45 e8             	mov    -0x18(%ebp),%eax
  1022cb:	c1 f8 10             	sar    $0x10,%eax
  1022ce:	0f b6 c0             	movzbl %al,%eax
  1022d1:	83 ec 08             	sub    $0x8,%esp
  1022d4:	50                   	push   %eax
  1022d5:	68 f5 01 00 00       	push   $0x1f5
  1022da:	e8 dd fd ff ff       	call   1020bc <outb>
  1022df:	83 c4 10             	add    $0x10,%esp
  outb(0x1f6, 0xe0 | ((b->dev&1)<<4) | ((sector>>24)&0x0f));
  1022e2:	8b 45 08             	mov    0x8(%ebp),%eax
  1022e5:	8b 40 04             	mov    0x4(%eax),%eax
  1022e8:	c1 e0 04             	shl    $0x4,%eax
  1022eb:	83 e0 10             	and    $0x10,%eax
  1022ee:	89 c2                	mov    %eax,%edx
  1022f0:	8b 45 e8             	mov    -0x18(%ebp),%eax
  1022f3:	c1 f8 18             	sar    $0x18,%eax
  1022f6:	83 e0 0f             	and    $0xf,%eax
  1022f9:	09 d0                	or     %edx,%eax
  1022fb:	83 c8 e0             	or     $0xffffffe0,%eax
  1022fe:	0f b6 c0             	movzbl %al,%eax
  102301:	83 ec 08             	sub    $0x8,%esp
  102304:	50                   	push   %eax
  102305:	68 f6 01 00 00       	push   $0x1f6
  10230a:	e8 ad fd ff ff       	call   1020bc <outb>
  10230f:	83 c4 10             	add    $0x10,%esp
  if(b->flags & B_DIRTY){
  102312:	8b 45 08             	mov    0x8(%ebp),%eax
  102315:	8b 00                	mov    (%eax),%eax
  102317:	83 e0 04             	and    $0x4,%eax
  10231a:	85 c0                	test   %eax,%eax
  10231c:	74 35                	je     102353 <idestart+0x17a>
    outb(0x1f7, write_cmd);
  10231e:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102321:	0f b6 c0             	movzbl %al,%eax
  102324:	83 ec 08             	sub    $0x8,%esp
  102327:	50                   	push   %eax
  102328:	68 f7 01 00 00       	push   $0x1f7
  10232d:	e8 8a fd ff ff       	call   1020bc <outb>
  102332:	83 c4 10             	add    $0x10,%esp
    outsl(0x1f0, b->data, BSIZE/4);
  102335:	8b 45 08             	mov    0x8(%ebp),%eax
  102338:	83 c0 1c             	add    $0x1c,%eax
  10233b:	83 ec 04             	sub    $0x4,%esp
  10233e:	68 80 00 00 00       	push   $0x80
  102343:	50                   	push   %eax
  102344:	68 f0 01 00 00       	push   $0x1f0
  102349:	e8 8d fd ff ff       	call   1020db <outsl>
  10234e:	83 c4 10             	add    $0x10,%esp
  } else {
    outb(0x1f7, read_cmd);
  }
}
  102351:	eb 17                	jmp    10236a <idestart+0x191>
    outb(0x1f7, read_cmd);
  102353:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102356:	0f b6 c0             	movzbl %al,%eax
  102359:	83 ec 08             	sub    $0x8,%esp
  10235c:	50                   	push   %eax
  10235d:	68 f7 01 00 00       	push   $0x1f7
  102362:	e8 55 fd ff ff       	call   1020bc <outb>
  102367:	83 c4 10             	add    $0x10,%esp
}
  10236a:	90                   	nop
  10236b:	c9                   	leave
  10236c:	c3                   	ret

0010236d <ideintr>:

// Interrupt handler.
void
ideintr(void)
{
  10236d:	55                   	push   %ebp
  10236e:	89 e5                	mov    %esp,%ebp
  102370:	83 ec 18             	sub    $0x18,%esp
  struct buf *b;

  // First queued buffer is the active request.
  if((b = idequeue) == 0){
  102373:	a1 64 9e 10 00       	mov    0x109e64,%eax
  102378:	89 45 f4             	mov    %eax,-0xc(%ebp)
  10237b:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
  10237f:	74 78                	je     1023f9 <ideintr+0x8c>
    return;
  }
  idequeue = b->qnext;
  102381:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102384:	8b 40 18             	mov    0x18(%eax),%eax
  102387:	a3 64 9e 10 00       	mov    %eax,0x109e64

  // Read data if needed.
  if(!(b->flags & B_DIRTY) && idewait(1) >= 0)
  10238c:	8b 45 f4             	mov    -0xc(%ebp),%eax
  10238f:	8b 00                	mov    (%eax),%eax
  102391:	83 e0 04             	and    $0x4,%eax
  102394:	85 c0                	test   %eax,%eax
  102396:	75 27                	jne    1023bf <ideintr+0x52>
  102398:	6a 01                	push   $0x1
  10239a:	e8 69 fd ff ff       	call   102108 <idewait>
  10239f:	83 c4 04             	add    $0x4,%esp
  1023a2:	85 c0                	test   %eax,%eax
  1023a4:	78 19                	js     1023bf <ideintr+0x52>
    insl(0x1f0, b->data, BSIZE/4);
  1023a6:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1023a9:	83 c0 1c             	add    $0x1c,%eax
  1023ac:	68 80 00 00 00       	push   $0x80
  1023b1:	50                   	push   %eax
  1023b2:	68 f0 01 00 00       	push   $0x1f0
  1023b7:	e8 da fc ff ff       	call   102096 <insl>
  1023bc:	83 c4 0c             	add    $0xc,%esp

  b->flags |= B_VALID;
  1023bf:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1023c2:	8b 00                	mov    (%eax),%eax
  1023c4:	83 c8 02             	or     $0x2,%eax
  1023c7:	89 c2                	mov    %eax,%edx
  1023c9:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1023cc:	89 10                	mov    %edx,(%eax)
  b->flags &= ~B_DIRTY;
  1023ce:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1023d1:	8b 00                	mov    (%eax),%eax
  1023d3:	83 e0 fb             	and    $0xfffffffb,%eax
  1023d6:	89 c2                	mov    %eax,%edx
  1023d8:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1023db:	89 10                	mov    %edx,(%eax)

  // Start disk on next buf in queue.
  if(idequeue != 0)
  1023dd:	a1 64 9e 10 00       	mov    0x109e64,%eax
  1023e2:	85 c0                	test   %eax,%eax
  1023e4:	74 14                	je     1023fa <ideintr+0x8d>
    idestart(idequeue);
  1023e6:	a1 64 9e 10 00       	mov    0x109e64,%eax
  1023eb:	83 ec 0c             	sub    $0xc,%esp
  1023ee:	50                   	push   %eax
  1023ef:	e8 e5 fd ff ff       	call   1021d9 <idestart>
  1023f4:	83 c4 10             	add    $0x10,%esp
  1023f7:	eb 01                	jmp    1023fa <ideintr+0x8d>
    return;
  1023f9:	90                   	nop
}
  1023fa:	c9                   	leave
  1023fb:	c3                   	ret

001023fc <iderw>:
// Sync buf with disk.
// If B_DIRTY is set, write buf to disk, clear B_DIRTY, set B_VALID.
// Else if B_VALID is not set, read buf from disk, set B_VALID.
void
iderw(struct buf *b)
{
  1023fc:	55                   	push   %ebp
  1023fd:	89 e5                	mov    %esp,%ebp
  1023ff:	83 ec 18             	sub    $0x18,%esp
  struct buf **pp;

  if((b->flags & (B_VALID|B_DIRTY)) == B_VALID)
  102402:	8b 45 08             	mov    0x8(%ebp),%eax
  102405:	8b 00                	mov    (%eax),%eax
  102407:	83 e0 06             	and    $0x6,%eax
  10240a:	83 f8 02             	cmp    $0x2,%eax
  10240d:	75 0d                	jne    10241c <iderw+0x20>
    panic("iderw: nothing to do");
  10240f:	83 ec 0c             	sub    $0xc,%esp
  102412:	68 0b 42 10 00       	push   $0x10420b
  102417:	e8 92 de ff ff       	call   1002ae <panic>
  if(b->dev != 0 && !havedisk1)
  10241c:	8b 45 08             	mov    0x8(%ebp),%eax
  10241f:	8b 40 04             	mov    0x4(%eax),%eax
  102422:	85 c0                	test   %eax,%eax
  102424:	74 16                	je     10243c <iderw+0x40>
  102426:	a1 68 9e 10 00       	mov    0x109e68,%eax
  10242b:	85 c0                	test   %eax,%eax
  10242d:	75 0d                	jne    10243c <iderw+0x40>
    panic("iderw: ide disk 1 not present");
  10242f:	83 ec 0c             	sub    $0xc,%esp
  102432:	68 20 42 10 00       	push   $0x104220
  102437:	e8 72 de ff ff       	call   1002ae <panic>

  // Append b to idequeue.
  b->qnext = 0;
  10243c:	8b 45 08             	mov    0x8(%ebp),%eax
  10243f:	c7 40 18 00 00 00 00 	movl   $0x0,0x18(%eax)
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
  102446:	c7 45 f4 64 9e 10 00 	movl   $0x109e64,-0xc(%ebp)
  10244d:	eb 0b                	jmp    10245a <iderw+0x5e>
  10244f:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102452:	8b 00                	mov    (%eax),%eax
  102454:	83 c0 18             	add    $0x18,%eax
  102457:	89 45 f4             	mov    %eax,-0xc(%ebp)
  10245a:	8b 45 f4             	mov    -0xc(%ebp),%eax
  10245d:	8b 00                	mov    (%eax),%eax
  10245f:	85 c0                	test   %eax,%eax
  102461:	75 ec                	jne    10244f <iderw+0x53>
    ;
  *pp = b;
  102463:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102466:	8b 55 08             	mov    0x8(%ebp),%edx
  102469:	89 10                	mov    %edx,(%eax)

  // Start disk if necessary.
  if(idequeue == b)
  10246b:	a1 64 9e 10 00       	mov    0x109e64,%eax
  102470:	39 45 08             	cmp    %eax,0x8(%ebp)
  102473:	75 15                	jne    10248a <iderw+0x8e>
    idestart(b);
  102475:	83 ec 0c             	sub    $0xc,%esp
  102478:	ff 75 08             	push   0x8(%ebp)
  10247b:	e8 59 fd ff ff       	call   1021d9 <idestart>
  102480:	83 c4 10             	add    $0x10,%esp

  // Wait for request to finish.
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID)
  102483:	eb 05                	jmp    10248a <iderw+0x8e>
  {
    // Warning: If we do not call noop(), compiler generates code that does not
    // read "b->flags" again and therefore never come out of this while loop. 
    // "b->flags" is modified by the trap handler in ideintr().  
    noop();
  102485:	e8 77 fc ff ff       	call   102101 <noop>
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID)
  10248a:	8b 45 08             	mov    0x8(%ebp),%eax
  10248d:	8b 00                	mov    (%eax),%eax
  10248f:	83 e0 06             	and    $0x6,%eax
  102492:	83 f8 02             	cmp    $0x2,%eax
  102495:	75 ee                	jne    102485 <iderw+0x89>
  }
}
  102497:	90                   	nop
  102498:	90                   	nop
  102499:	c9                   	leave
  10249a:	c3                   	ret

0010249b <readsb>:
struct superblock sb; 

// Read the super block.
void
readsb(int dev, struct superblock *sb)
{
  10249b:	55                   	push   %ebp
  10249c:	89 e5                	mov    %esp,%ebp
  10249e:	83 ec 18             	sub    $0x18,%esp
  struct buf *bp;

  bp = bread(dev, 1);
  1024a1:	8b 45 08             	mov    0x8(%ebp),%eax
  1024a4:	83 ec 08             	sub    $0x8,%esp
  1024a7:	6a 01                	push   $0x1
  1024a9:	50                   	push   %eax
  1024aa:	e8 ec fa ff ff       	call   101f9b <bread>
  1024af:	83 c4 10             	add    $0x10,%esp
  1024b2:	89 45 f4             	mov    %eax,-0xc(%ebp)
  memmove(sb, bp->data, sizeof(*sb));
  1024b5:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1024b8:	83 c0 1c             	add    $0x1c,%eax
  1024bb:	83 ec 04             	sub    $0x4,%esp
  1024be:	6a 1c                	push   $0x1c
  1024c0:	50                   	push   %eax
  1024c1:	ff 75 0c             	push   0xc(%ebp)
  1024c4:	e8 7c ea ff ff       	call   100f45 <memmove>
  1024c9:	83 c4 10             	add    $0x10,%esp
  brelse(bp);
  1024cc:	83 ec 0c             	sub    $0xc,%esp
  1024cf:	ff 75 f4             	push   -0xc(%ebp)
  1024d2:	e8 3c fb ff ff       	call   102013 <brelse>
  1024d7:	83 c4 10             	add    $0x10,%esp
}
  1024da:	90                   	nop
  1024db:	c9                   	leave
  1024dc:	c3                   	ret

001024dd <bzero>:

// Zero a block.
static void
bzero(int dev, int bno)
{
  1024dd:	55                   	push   %ebp
  1024de:	89 e5                	mov    %esp,%ebp
  1024e0:	83 ec 18             	sub    $0x18,%esp
  struct buf *bp;

  bp = bread_wr(dev, bno);
  1024e3:	8b 55 0c             	mov    0xc(%ebp),%edx
  1024e6:	8b 45 08             	mov    0x8(%ebp),%eax
  1024e9:	83 ec 08             	sub    $0x8,%esp
  1024ec:	52                   	push   %edx
  1024ed:	50                   	push   %eax
  1024ee:	e8 07 fb ff ff       	call   101ffa <bread_wr>
  1024f3:	83 c4 10             	add    $0x10,%esp
  1024f6:	89 45 f4             	mov    %eax,-0xc(%ebp)
  write_log_ul(bp);  /// writing this old block to memory.
  1024f9:	83 ec 0c             	sub    $0xc,%esp
  1024fc:	ff 75 f4             	push   -0xc(%ebp)
  1024ff:	e8 4f 1a 00 00       	call   103f53 <write_log_ul>
  102504:	83 c4 10             	add    $0x10,%esp
  memset(bp->data, 0, BSIZE);
  102507:	8b 45 f4             	mov    -0xc(%ebp),%eax
  10250a:	83 c0 1c             	add    $0x1c,%eax
  10250d:	83 ec 04             	sub    $0x4,%esp
  102510:	68 00 02 00 00       	push   $0x200
  102515:	6a 00                	push   $0x0
  102517:	50                   	push   %eax
  102518:	e8 69 e9 ff ff       	call   100e86 <memset>
  10251d:	83 c4 10             	add    $0x10,%esp
  log_write(bp);
  102520:	83 ec 0c             	sub    $0xc,%esp
  102523:	ff 75 f4             	push   -0xc(%ebp)
  102526:	e8 88 19 00 00       	call   103eb3 <log_write>
  10252b:	83 c4 10             	add    $0x10,%esp
  brelse(bp);
  10252e:	83 ec 0c             	sub    $0xc,%esp
  102531:	ff 75 f4             	push   -0xc(%ebp)
  102534:	e8 da fa ff ff       	call   102013 <brelse>
  102539:	83 c4 10             	add    $0x10,%esp
}
  10253c:	90                   	nop
  10253d:	c9                   	leave
  10253e:	c3                   	ret

0010253f <balloc>:
// Blocks.

// Allocate a zeroed disk block.
static uint
balloc(uint dev)
{
  10253f:	55                   	push   %ebp
  102540:	89 e5                	mov    %esp,%ebp
  102542:	83 ec 18             	sub    $0x18,%esp
  int b, bi, m;
  struct buf *bp;

  bp = 0;
  102545:	c7 45 ec 00 00 00 00 	movl   $0x0,-0x14(%ebp)
  for(b = 0; b < sb.size; b += BPB){
  10254c:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  102553:	e9 19 01 00 00       	jmp    102671 <balloc+0x132>
    bp = bread_wr(dev, BBLOCK(b, sb));
  102558:	8b 45 f4             	mov    -0xc(%ebp),%eax
  10255b:	8d 90 ff 0f 00 00    	lea    0xfff(%eax),%edx
  102561:	85 c0                	test   %eax,%eax
  102563:	0f 48 c2             	cmovs  %edx,%eax
  102566:	c1 f8 0c             	sar    $0xc,%eax
  102569:	89 c2                	mov    %eax,%edx
  10256b:	a1 98 9e 10 00       	mov    0x109e98,%eax
  102570:	01 d0                	add    %edx,%eax
  102572:	83 ec 08             	sub    $0x8,%esp
  102575:	50                   	push   %eax
  102576:	ff 75 08             	push   0x8(%ebp)
  102579:	e8 7c fa ff ff       	call   101ffa <bread_wr>
  10257e:	83 c4 10             	add    $0x10,%esp
  102581:	89 45 ec             	mov    %eax,-0x14(%ebp)
    write_log_ul(bp);
  102584:	83 ec 0c             	sub    $0xc,%esp
  102587:	ff 75 ec             	push   -0x14(%ebp)
  10258a:	e8 c4 19 00 00       	call   103f53 <write_log_ul>
  10258f:	83 c4 10             	add    $0x10,%esp
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
  102592:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
  102599:	e9 9e 00 00 00       	jmp    10263c <balloc+0xfd>
      m = 1 << (bi % 8);
  10259e:	8b 45 f0             	mov    -0x10(%ebp),%eax
  1025a1:	83 e0 07             	and    $0x7,%eax
  1025a4:	ba 01 00 00 00       	mov    $0x1,%edx
  1025a9:	89 c1                	mov    %eax,%ecx
  1025ab:	d3 e2                	shl    %cl,%edx
  1025ad:	89 d0                	mov    %edx,%eax
  1025af:	89 45 e8             	mov    %eax,-0x18(%ebp)
      if((bp->data[bi/8] & m) == 0){  // Is block free?
  1025b2:	8b 45 f0             	mov    -0x10(%ebp),%eax
  1025b5:	8d 50 07             	lea    0x7(%eax),%edx
  1025b8:	85 c0                	test   %eax,%eax
  1025ba:	0f 48 c2             	cmovs  %edx,%eax
  1025bd:	c1 f8 03             	sar    $0x3,%eax
  1025c0:	89 c2                	mov    %eax,%edx
  1025c2:	8b 45 ec             	mov    -0x14(%ebp),%eax
  1025c5:	0f b6 44 10 1c       	movzbl 0x1c(%eax,%edx,1),%eax
  1025ca:	0f b6 c0             	movzbl %al,%eax
  1025cd:	23 45 e8             	and    -0x18(%ebp),%eax
  1025d0:	85 c0                	test   %eax,%eax
  1025d2:	75 64                	jne    102638 <balloc+0xf9>
        bp->data[bi/8] |= m;  // Mark block in use.
  1025d4:	8b 45 f0             	mov    -0x10(%ebp),%eax
  1025d7:	8d 50 07             	lea    0x7(%eax),%edx
  1025da:	85 c0                	test   %eax,%eax
  1025dc:	0f 48 c2             	cmovs  %edx,%eax
  1025df:	c1 f8 03             	sar    $0x3,%eax
  1025e2:	8b 55 ec             	mov    -0x14(%ebp),%edx
  1025e5:	0f b6 54 02 1c       	movzbl 0x1c(%edx,%eax,1),%edx
  1025ea:	89 d1                	mov    %edx,%ecx
  1025ec:	8b 55 e8             	mov    -0x18(%ebp),%edx
  1025ef:	09 ca                	or     %ecx,%edx
  1025f1:	89 d1                	mov    %edx,%ecx
  1025f3:	8b 55 ec             	mov    -0x14(%ebp),%edx
  1025f6:	88 4c 02 1c          	mov    %cl,0x1c(%edx,%eax,1)
        log_write(bp);
  1025fa:	83 ec 0c             	sub    $0xc,%esp
  1025fd:	ff 75 ec             	push   -0x14(%ebp)
  102600:	e8 ae 18 00 00       	call   103eb3 <log_write>
  102605:	83 c4 10             	add    $0x10,%esp
        brelse(bp);
  102608:	83 ec 0c             	sub    $0xc,%esp
  10260b:	ff 75 ec             	push   -0x14(%ebp)
  10260e:	e8 00 fa ff ff       	call   102013 <brelse>
  102613:	83 c4 10             	add    $0x10,%esp
        bzero(dev, b + bi);
  102616:	8b 55 f4             	mov    -0xc(%ebp),%edx
  102619:	8b 45 f0             	mov    -0x10(%ebp),%eax
  10261c:	01 c2                	add    %eax,%edx
  10261e:	8b 45 08             	mov    0x8(%ebp),%eax
  102621:	83 ec 08             	sub    $0x8,%esp
  102624:	52                   	push   %edx
  102625:	50                   	push   %eax
  102626:	e8 b2 fe ff ff       	call   1024dd <bzero>
  10262b:	83 c4 10             	add    $0x10,%esp
        return b + bi;
  10262e:	8b 55 f4             	mov    -0xc(%ebp),%edx
  102631:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102634:	01 d0                	add    %edx,%eax
  102636:	eb 56                	jmp    10268e <balloc+0x14f>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
  102638:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
  10263c:	81 7d f0 ff 0f 00 00 	cmpl   $0xfff,-0x10(%ebp)
  102643:	7f 17                	jg     10265c <balloc+0x11d>
  102645:	8b 55 f4             	mov    -0xc(%ebp),%edx
  102648:	8b 45 f0             	mov    -0x10(%ebp),%eax
  10264b:	01 d0                	add    %edx,%eax
  10264d:	89 c2                	mov    %eax,%edx
  10264f:	a1 80 9e 10 00       	mov    0x109e80,%eax
  102654:	39 c2                	cmp    %eax,%edx
  102656:	0f 82 42 ff ff ff    	jb     10259e <balloc+0x5f>
      }
    }
    brelse(bp);
  10265c:	83 ec 0c             	sub    $0xc,%esp
  10265f:	ff 75 ec             	push   -0x14(%ebp)
  102662:	e8 ac f9 ff ff       	call   102013 <brelse>
  102667:	83 c4 10             	add    $0x10,%esp
  for(b = 0; b < sb.size; b += BPB){
  10266a:	81 45 f4 00 10 00 00 	addl   $0x1000,-0xc(%ebp)
  102671:	a1 80 9e 10 00       	mov    0x109e80,%eax
  102676:	8b 55 f4             	mov    -0xc(%ebp),%edx
  102679:	39 c2                	cmp    %eax,%edx
  10267b:	0f 82 d7 fe ff ff    	jb     102558 <balloc+0x19>
  }
  panic("balloc: out of blocks");
  102681:	83 ec 0c             	sub    $0xc,%esp
  102684:	68 40 42 10 00       	push   $0x104240
  102689:	e8 20 dc ff ff       	call   1002ae <panic>
}
  10268e:	c9                   	leave
  10268f:	c3                   	ret

00102690 <bfree>:


// Free a disk block.
static void
bfree(int dev, uint b)
{
  102690:	55                   	push   %ebp
  102691:	89 e5                	mov    %esp,%ebp
  102693:	83 ec 18             	sub    $0x18,%esp
  struct buf *bp;
  int bi, m;

  bp = bread_wr(dev, BBLOCK(b, sb));
  102696:	8b 45 0c             	mov    0xc(%ebp),%eax
  102699:	c1 e8 0c             	shr    $0xc,%eax
  10269c:	89 c2                	mov    %eax,%edx
  10269e:	a1 98 9e 10 00       	mov    0x109e98,%eax
  1026a3:	01 c2                	add    %eax,%edx
  1026a5:	8b 45 08             	mov    0x8(%ebp),%eax
  1026a8:	83 ec 08             	sub    $0x8,%esp
  1026ab:	52                   	push   %edx
  1026ac:	50                   	push   %eax
  1026ad:	e8 48 f9 ff ff       	call   101ffa <bread_wr>
  1026b2:	83 c4 10             	add    $0x10,%esp
  1026b5:	89 45 f4             	mov    %eax,-0xc(%ebp)
  write_log_ul(bp);
  1026b8:	83 ec 0c             	sub    $0xc,%esp
  1026bb:	ff 75 f4             	push   -0xc(%ebp)
  1026be:	e8 90 18 00 00       	call   103f53 <write_log_ul>
  1026c3:	83 c4 10             	add    $0x10,%esp
  bi = b % BPB;
  1026c6:	8b 45 0c             	mov    0xc(%ebp),%eax
  1026c9:	25 ff 0f 00 00       	and    $0xfff,%eax
  1026ce:	89 45 f0             	mov    %eax,-0x10(%ebp)
  m = 1 << (bi % 8);
  1026d1:	8b 45 f0             	mov    -0x10(%ebp),%eax
  1026d4:	83 e0 07             	and    $0x7,%eax
  1026d7:	ba 01 00 00 00       	mov    $0x1,%edx
  1026dc:	89 c1                	mov    %eax,%ecx
  1026de:	d3 e2                	shl    %cl,%edx
  1026e0:	89 d0                	mov    %edx,%eax
  1026e2:	89 45 ec             	mov    %eax,-0x14(%ebp)
  if((bp->data[bi/8] & m) == 0)
  1026e5:	8b 45 f0             	mov    -0x10(%ebp),%eax
  1026e8:	8d 50 07             	lea    0x7(%eax),%edx
  1026eb:	85 c0                	test   %eax,%eax
  1026ed:	0f 48 c2             	cmovs  %edx,%eax
  1026f0:	c1 f8 03             	sar    $0x3,%eax
  1026f3:	89 c2                	mov    %eax,%edx
  1026f5:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1026f8:	0f b6 44 10 1c       	movzbl 0x1c(%eax,%edx,1),%eax
  1026fd:	0f b6 c0             	movzbl %al,%eax
  102700:	23 45 ec             	and    -0x14(%ebp),%eax
  102703:	85 c0                	test   %eax,%eax
  102705:	75 0d                	jne    102714 <bfree+0x84>
    panic("freeing free block");
  102707:	83 ec 0c             	sub    $0xc,%esp
  10270a:	68 56 42 10 00       	push   $0x104256
  10270f:	e8 9a db ff ff       	call   1002ae <panic>
  bp->data[bi/8] &= ~m;
  102714:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102717:	8d 50 07             	lea    0x7(%eax),%edx
  10271a:	85 c0                	test   %eax,%eax
  10271c:	0f 48 c2             	cmovs  %edx,%eax
  10271f:	c1 f8 03             	sar    $0x3,%eax
  102722:	8b 55 f4             	mov    -0xc(%ebp),%edx
  102725:	0f b6 54 02 1c       	movzbl 0x1c(%edx,%eax,1),%edx
  10272a:	89 d1                	mov    %edx,%ecx
  10272c:	8b 55 ec             	mov    -0x14(%ebp),%edx
  10272f:	f7 d2                	not    %edx
  102731:	21 ca                	and    %ecx,%edx
  102733:	89 d1                	mov    %edx,%ecx
  102735:	8b 55 f4             	mov    -0xc(%ebp),%edx
  102738:	88 4c 02 1c          	mov    %cl,0x1c(%edx,%eax,1)
  log_write(bp);
  10273c:	83 ec 0c             	sub    $0xc,%esp
  10273f:	ff 75 f4             	push   -0xc(%ebp)
  102742:	e8 6c 17 00 00       	call   103eb3 <log_write>
  102747:	83 c4 10             	add    $0x10,%esp
  brelse(bp);
  10274a:	83 ec 0c             	sub    $0xc,%esp
  10274d:	ff 75 f4             	push   -0xc(%ebp)
  102750:	e8 be f8 ff ff       	call   102013 <brelse>
  102755:	83 c4 10             	add    $0x10,%esp
}
  102758:	90                   	nop
  102759:	c9                   	leave
  10275a:	c3                   	ret

0010275b <iinit>:
  struct inode inode[NINODE];
} icache;

void
iinit(int dev)
{
  10275b:	55                   	push   %ebp
  10275c:	89 e5                	mov    %esp,%ebp
  10275e:	57                   	push   %edi
  10275f:	56                   	push   %esi
  102760:	53                   	push   %ebx
  102761:	83 ec 1c             	sub    $0x1c,%esp
  readsb(dev, &sb);
  102764:	83 ec 08             	sub    $0x8,%esp
  102767:	68 80 9e 10 00       	push   $0x109e80
  10276c:	ff 75 08             	push   0x8(%ebp)
  10276f:	e8 27 fd ff ff       	call   10249b <readsb>
  102774:	83 c4 10             	add    $0x10,%esp
  cprintf("sb: size %d nblocks %d ninodes %d nlog %d logstart %d\
  102777:	a1 98 9e 10 00       	mov    0x109e98,%eax
  10277c:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  10277f:	8b 3d 94 9e 10 00    	mov    0x109e94,%edi
  102785:	8b 35 90 9e 10 00    	mov    0x109e90,%esi
  10278b:	8b 1d 8c 9e 10 00    	mov    0x109e8c,%ebx
  102791:	8b 0d 88 9e 10 00    	mov    0x109e88,%ecx
  102797:	8b 15 84 9e 10 00    	mov    0x109e84,%edx
  10279d:	a1 80 9e 10 00       	mov    0x109e80,%eax
  1027a2:	ff 75 e4             	push   -0x1c(%ebp)
  1027a5:	57                   	push   %edi
  1027a6:	56                   	push   %esi
  1027a7:	53                   	push   %ebx
  1027a8:	51                   	push   %ecx
  1027a9:	52                   	push   %edx
  1027aa:	50                   	push   %eax
  1027ab:	68 6c 42 10 00       	push   $0x10426c
  1027b0:	e8 37 d9 ff ff       	call   1000ec <cprintf>
  1027b5:	83 c4 20             	add    $0x20,%esp
 inodestart %d bmap start %d\n", sb.size, sb.nblocks,
          sb.ninodes, sb.nlog, sb.logstart, sb.inodestart,
          sb.bmapstart);
}
  1027b8:	90                   	nop
  1027b9:	8d 65 f4             	lea    -0xc(%ebp),%esp
  1027bc:	5b                   	pop    %ebx
  1027bd:	5e                   	pop    %esi
  1027be:	5f                   	pop    %edi
  1027bf:	5d                   	pop    %ebp
  1027c0:	c3                   	ret

001027c1 <ialloc>:
// Allocate an inode on device dev.
// Mark it as allocated by  giving it type type.
// Returns an unlocked but allocated and referenced inode.
struct inode*
ialloc(uint dev, short type)
{
  1027c1:	55                   	push   %ebp
  1027c2:	89 e5                	mov    %esp,%ebp
  1027c4:	83 ec 28             	sub    $0x28,%esp
  1027c7:	8b 45 0c             	mov    0xc(%ebp),%eax
  1027ca:	66 89 45 e4          	mov    %ax,-0x1c(%ebp)
  int inum;
  struct buf *bp;
  struct dinode *dip;

  for(inum = 1; inum < sb.ninodes; inum++){
  1027ce:	c7 45 f4 01 00 00 00 	movl   $0x1,-0xc(%ebp)
  1027d5:	e9 ac 00 00 00       	jmp    102886 <ialloc+0xc5>
    bp = bread_wr(dev, IBLOCK(inum, sb));
  1027da:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1027dd:	c1 e8 03             	shr    $0x3,%eax
  1027e0:	89 c2                	mov    %eax,%edx
  1027e2:	a1 94 9e 10 00       	mov    0x109e94,%eax
  1027e7:	01 d0                	add    %edx,%eax
  1027e9:	83 ec 08             	sub    $0x8,%esp
  1027ec:	50                   	push   %eax
  1027ed:	ff 75 08             	push   0x8(%ebp)
  1027f0:	e8 05 f8 ff ff       	call   101ffa <bread_wr>
  1027f5:	83 c4 10             	add    $0x10,%esp
  1027f8:	89 45 f0             	mov    %eax,-0x10(%ebp)
    write_log_ul(bp);
  1027fb:	83 ec 0c             	sub    $0xc,%esp
  1027fe:	ff 75 f0             	push   -0x10(%ebp)
  102801:	e8 4d 17 00 00       	call   103f53 <write_log_ul>
  102806:	83 c4 10             	add    $0x10,%esp
    dip = (struct dinode*)bp->data + inum%IPB;
  102809:	8b 45 f0             	mov    -0x10(%ebp),%eax
  10280c:	8d 50 1c             	lea    0x1c(%eax),%edx
  10280f:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102812:	83 e0 07             	and    $0x7,%eax
  102815:	c1 e0 06             	shl    $0x6,%eax
  102818:	01 d0                	add    %edx,%eax
  10281a:	89 45 ec             	mov    %eax,-0x14(%ebp)
    if(dip->type == 0){  // a free inode
  10281d:	8b 45 ec             	mov    -0x14(%ebp),%eax
  102820:	0f b7 00             	movzwl (%eax),%eax
  102823:	66 85 c0             	test   %ax,%ax
  102826:	75 4c                	jne    102874 <ialloc+0xb3>
      memset(dip, 0, sizeof(*dip));
  102828:	83 ec 04             	sub    $0x4,%esp
  10282b:	6a 40                	push   $0x40
  10282d:	6a 00                	push   $0x0
  10282f:	ff 75 ec             	push   -0x14(%ebp)
  102832:	e8 4f e6 ff ff       	call   100e86 <memset>
  102837:	83 c4 10             	add    $0x10,%esp
      dip->type = type;
  10283a:	8b 45 ec             	mov    -0x14(%ebp),%eax
  10283d:	0f b7 55 e4          	movzwl -0x1c(%ebp),%edx
  102841:	66 89 10             	mov    %dx,(%eax)
      log_write(bp);   // mark it allocated on the disk
  102844:	83 ec 0c             	sub    $0xc,%esp
  102847:	ff 75 f0             	push   -0x10(%ebp)
  10284a:	e8 64 16 00 00       	call   103eb3 <log_write>
  10284f:	83 c4 10             	add    $0x10,%esp
      brelse(bp);
  102852:	83 ec 0c             	sub    $0xc,%esp
  102855:	ff 75 f0             	push   -0x10(%ebp)
  102858:	e8 b6 f7 ff ff       	call   102013 <brelse>
  10285d:	83 c4 10             	add    $0x10,%esp
      return iget(dev, inum);
  102860:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102863:	83 ec 08             	sub    $0x8,%esp
  102866:	50                   	push   %eax
  102867:	ff 75 08             	push   0x8(%ebp)
  10286a:	e8 71 01 00 00       	call   1029e0 <iget>
  10286f:	83 c4 10             	add    $0x10,%esp
  102872:	eb 2f                	jmp    1028a3 <ialloc+0xe2>
    }
    brelse(bp);
  102874:	83 ec 0c             	sub    $0xc,%esp
  102877:	ff 75 f0             	push   -0x10(%ebp)
  10287a:	e8 94 f7 ff ff       	call   102013 <brelse>
  10287f:	83 c4 10             	add    $0x10,%esp
  for(inum = 1; inum < sb.ninodes; inum++){
  102882:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  102886:	a1 88 9e 10 00       	mov    0x109e88,%eax
  10288b:	8b 55 f4             	mov    -0xc(%ebp),%edx
  10288e:	39 c2                	cmp    %eax,%edx
  102890:	0f 82 44 ff ff ff    	jb     1027da <ialloc+0x19>
  }
  panic("ialloc: no inodes");
  102896:	83 ec 0c             	sub    $0xc,%esp
  102899:	68 bf 42 10 00       	push   $0x1042bf
  10289e:	e8 0b da ff ff       	call   1002ae <panic>
}
  1028a3:	c9                   	leave
  1028a4:	c3                   	ret

001028a5 <iput>:
// be recycled.
// If that was the last reference and the inode has no links
// to it, free the inode (and its content) on disk.
void
iput(struct inode *ip)
{
  1028a5:	55                   	push   %ebp
  1028a6:	89 e5                	mov    %esp,%ebp
  1028a8:	83 ec 18             	sub    $0x18,%esp
  if(ip->valid && ip->nlink == 0){
  1028ab:	8b 45 08             	mov    0x8(%ebp),%eax
  1028ae:	8b 40 0c             	mov    0xc(%eax),%eax
  1028b1:	85 c0                	test   %eax,%eax
  1028b3:	74 4a                	je     1028ff <iput+0x5a>
  1028b5:	8b 45 08             	mov    0x8(%ebp),%eax
  1028b8:	0f b7 40 16          	movzwl 0x16(%eax),%eax
  1028bc:	66 85 c0             	test   %ax,%ax
  1028bf:	75 3e                	jne    1028ff <iput+0x5a>
    int r = ip->ref;
  1028c1:	8b 45 08             	mov    0x8(%ebp),%eax
  1028c4:	8b 40 08             	mov    0x8(%eax),%eax
  1028c7:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(r == 1){
  1028ca:	83 7d f4 01          	cmpl   $0x1,-0xc(%ebp)
  1028ce:	75 2f                	jne    1028ff <iput+0x5a>
      // inode has no links and no other references: truncate and free.
      itrunc(ip);
  1028d0:	83 ec 0c             	sub    $0xc,%esp
  1028d3:	ff 75 08             	push   0x8(%ebp)
  1028d6:	e8 cf 03 00 00       	call   102caa <itrunc>
  1028db:	83 c4 10             	add    $0x10,%esp
      ip->type = 0;
  1028de:	8b 45 08             	mov    0x8(%ebp),%eax
  1028e1:	66 c7 40 10 00 00    	movw   $0x0,0x10(%eax)
      iupdate(ip);
  1028e7:	83 ec 0c             	sub    $0xc,%esp
  1028ea:	ff 75 08             	push   0x8(%ebp)
  1028ed:	e8 1f 00 00 00       	call   102911 <iupdate>
  1028f2:	83 c4 10             	add    $0x10,%esp
      ip->valid = 0;
  1028f5:	8b 45 08             	mov    0x8(%ebp),%eax
  1028f8:	c7 40 0c 00 00 00 00 	movl   $0x0,0xc(%eax)
    }
  }
  ip->ref--;
  1028ff:	8b 45 08             	mov    0x8(%ebp),%eax
  102902:	8b 40 08             	mov    0x8(%eax),%eax
  102905:	8d 50 ff             	lea    -0x1(%eax),%edx
  102908:	8b 45 08             	mov    0x8(%ebp),%eax
  10290b:	89 50 08             	mov    %edx,0x8(%eax)
}
  10290e:	90                   	nop
  10290f:	c9                   	leave
  102910:	c3                   	ret

00102911 <iupdate>:
// Copy a modified in-memory inode to disk.
// Must be called after every change to an ip->xxx field
// that lives on disk, since i-node cache is write-through.
void
iupdate(struct inode *ip)
{
  102911:	55                   	push   %ebp
  102912:	89 e5                	mov    %esp,%ebp
  102914:	83 ec 18             	sub    $0x18,%esp
  struct buf *bp;
  struct dinode *dip;

  bp = bread_wr(ip->dev, IBLOCK(ip->inum, sb));
  102917:	8b 45 08             	mov    0x8(%ebp),%eax
  10291a:	8b 40 04             	mov    0x4(%eax),%eax
  10291d:	c1 e8 03             	shr    $0x3,%eax
  102920:	89 c2                	mov    %eax,%edx
  102922:	a1 94 9e 10 00       	mov    0x109e94,%eax
  102927:	01 c2                	add    %eax,%edx
  102929:	8b 45 08             	mov    0x8(%ebp),%eax
  10292c:	8b 00                	mov    (%eax),%eax
  10292e:	83 ec 08             	sub    $0x8,%esp
  102931:	52                   	push   %edx
  102932:	50                   	push   %eax
  102933:	e8 c2 f6 ff ff       	call   101ffa <bread_wr>
  102938:	83 c4 10             	add    $0x10,%esp
  10293b:	89 45 f4             	mov    %eax,-0xc(%ebp)
  write_log_ul(bp);
  10293e:	83 ec 0c             	sub    $0xc,%esp
  102941:	ff 75 f4             	push   -0xc(%ebp)
  102944:	e8 0a 16 00 00       	call   103f53 <write_log_ul>
  102949:	83 c4 10             	add    $0x10,%esp
  dip = (struct dinode*)bp->data + ip->inum%IPB;
  10294c:	8b 45 f4             	mov    -0xc(%ebp),%eax
  10294f:	8d 50 1c             	lea    0x1c(%eax),%edx
  102952:	8b 45 08             	mov    0x8(%ebp),%eax
  102955:	8b 40 04             	mov    0x4(%eax),%eax
  102958:	83 e0 07             	and    $0x7,%eax
  10295b:	c1 e0 06             	shl    $0x6,%eax
  10295e:	01 d0                	add    %edx,%eax
  102960:	89 45 f0             	mov    %eax,-0x10(%ebp)
  dip->type = ip->type;
  102963:	8b 45 08             	mov    0x8(%ebp),%eax
  102966:	0f b7 50 10          	movzwl 0x10(%eax),%edx
  10296a:	8b 45 f0             	mov    -0x10(%ebp),%eax
  10296d:	66 89 10             	mov    %dx,(%eax)
  dip->major = ip->major;
  102970:	8b 45 08             	mov    0x8(%ebp),%eax
  102973:	0f b7 50 12          	movzwl 0x12(%eax),%edx
  102977:	8b 45 f0             	mov    -0x10(%ebp),%eax
  10297a:	66 89 50 02          	mov    %dx,0x2(%eax)
  dip->minor = ip->minor;
  10297e:	8b 45 08             	mov    0x8(%ebp),%eax
  102981:	0f b7 50 14          	movzwl 0x14(%eax),%edx
  102985:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102988:	66 89 50 04          	mov    %dx,0x4(%eax)
  dip->nlink = ip->nlink;
  10298c:	8b 45 08             	mov    0x8(%ebp),%eax
  10298f:	0f b7 50 16          	movzwl 0x16(%eax),%edx
  102993:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102996:	66 89 50 06          	mov    %dx,0x6(%eax)
  dip->size = ip->size;
  10299a:	8b 45 08             	mov    0x8(%ebp),%eax
  10299d:	8b 50 18             	mov    0x18(%eax),%edx
  1029a0:	8b 45 f0             	mov    -0x10(%ebp),%eax
  1029a3:	89 50 08             	mov    %edx,0x8(%eax)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
  1029a6:	8b 45 08             	mov    0x8(%ebp),%eax
  1029a9:	8d 50 1c             	lea    0x1c(%eax),%edx
  1029ac:	8b 45 f0             	mov    -0x10(%ebp),%eax
  1029af:	83 c0 0c             	add    $0xc,%eax
  1029b2:	83 ec 04             	sub    $0x4,%esp
  1029b5:	6a 34                	push   $0x34
  1029b7:	52                   	push   %edx
  1029b8:	50                   	push   %eax
  1029b9:	e8 87 e5 ff ff       	call   100f45 <memmove>
  1029be:	83 c4 10             	add    $0x10,%esp
  log_write(bp);
  1029c1:	83 ec 0c             	sub    $0xc,%esp
  1029c4:	ff 75 f4             	push   -0xc(%ebp)
  1029c7:	e8 e7 14 00 00       	call   103eb3 <log_write>
  1029cc:	83 c4 10             	add    $0x10,%esp
  brelse(bp);
  1029cf:	83 ec 0c             	sub    $0xc,%esp
  1029d2:	ff 75 f4             	push   -0xc(%ebp)
  1029d5:	e8 39 f6 ff ff       	call   102013 <brelse>
  1029da:	83 c4 10             	add    $0x10,%esp
}
  1029dd:	90                   	nop
  1029de:	c9                   	leave
  1029df:	c3                   	ret

001029e0 <iget>:
// Find the inode with number inum on device dev
// and return the in-memory copy. Does not lock
// the inode and does not read it from disk.
struct inode*
iget(uint dev, uint inum)
{
  1029e0:	55                   	push   %ebp
  1029e1:	89 e5                	mov    %esp,%ebp
  1029e3:	83 ec 18             	sub    $0x18,%esp
  struct inode *ip, *empty;

  // Is the inode already cached?
  empty = 0;
  1029e6:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
  1029ed:	c7 45 f4 a0 9e 10 00 	movl   $0x109ea0,-0xc(%ebp)
  1029f4:	eb 4d                	jmp    102a43 <iget+0x63>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
  1029f6:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1029f9:	8b 40 08             	mov    0x8(%eax),%eax
  1029fc:	85 c0                	test   %eax,%eax
  1029fe:	7e 29                	jle    102a29 <iget+0x49>
  102a00:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102a03:	8b 00                	mov    (%eax),%eax
  102a05:	39 45 08             	cmp    %eax,0x8(%ebp)
  102a08:	75 1f                	jne    102a29 <iget+0x49>
  102a0a:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102a0d:	8b 40 04             	mov    0x4(%eax),%eax
  102a10:	39 45 0c             	cmp    %eax,0xc(%ebp)
  102a13:	75 14                	jne    102a29 <iget+0x49>
      ip->ref++;
  102a15:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102a18:	8b 40 08             	mov    0x8(%eax),%eax
  102a1b:	8d 50 01             	lea    0x1(%eax),%edx
  102a1e:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102a21:	89 50 08             	mov    %edx,0x8(%eax)
      return ip;
  102a24:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102a27:	eb 64                	jmp    102a8d <iget+0xad>
    }
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
  102a29:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
  102a2d:	75 10                	jne    102a3f <iget+0x5f>
  102a2f:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102a32:	8b 40 08             	mov    0x8(%eax),%eax
  102a35:	85 c0                	test   %eax,%eax
  102a37:	75 06                	jne    102a3f <iget+0x5f>
      empty = ip;
  102a39:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102a3c:	89 45 f0             	mov    %eax,-0x10(%ebp)
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
  102a3f:	83 45 f4 50          	addl   $0x50,-0xc(%ebp)
  102a43:	81 7d f4 40 ae 10 00 	cmpl   $0x10ae40,-0xc(%ebp)
  102a4a:	72 aa                	jb     1029f6 <iget+0x16>
  }

  // Recycle an inode cache entry.
  if(empty == 0)
  102a4c:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
  102a50:	75 0d                	jne    102a5f <iget+0x7f>
    panic("iget: no inodes");
  102a52:	83 ec 0c             	sub    $0xc,%esp
  102a55:	68 d1 42 10 00       	push   $0x1042d1
  102a5a:	e8 4f d8 ff ff       	call   1002ae <panic>

  ip = empty;
  102a5f:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102a62:	89 45 f4             	mov    %eax,-0xc(%ebp)
  ip->dev = dev;
  102a65:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102a68:	8b 55 08             	mov    0x8(%ebp),%edx
  102a6b:	89 10                	mov    %edx,(%eax)
  ip->inum = inum;
  102a6d:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102a70:	8b 55 0c             	mov    0xc(%ebp),%edx
  102a73:	89 50 04             	mov    %edx,0x4(%eax)
  ip->ref = 1;
  102a76:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102a79:	c7 40 08 01 00 00 00 	movl   $0x1,0x8(%eax)
  ip->valid = 0;
  102a80:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102a83:	c7 40 0c 00 00 00 00 	movl   $0x0,0xc(%eax)

  return ip;
  102a8a:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
  102a8d:	c9                   	leave
  102a8e:	c3                   	ret

00102a8f <iread>:

// Reads the inode from disk if necessary.
void
iread(struct inode *ip)
{
  102a8f:	55                   	push   %ebp
  102a90:	89 e5                	mov    %esp,%ebp
  102a92:	83 ec 18             	sub    $0x18,%esp
  struct buf *bp;
  struct dinode *dip;

  if(ip == 0 || ip->ref < 1)
  102a95:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
  102a99:	74 0a                	je     102aa5 <iread+0x16>
  102a9b:	8b 45 08             	mov    0x8(%ebp),%eax
  102a9e:	8b 40 08             	mov    0x8(%eax),%eax
  102aa1:	85 c0                	test   %eax,%eax
  102aa3:	7f 0d                	jg     102ab2 <iread+0x23>
    panic("iread");
  102aa5:	83 ec 0c             	sub    $0xc,%esp
  102aa8:	68 e1 42 10 00       	push   $0x1042e1
  102aad:	e8 fc d7 ff ff       	call   1002ae <panic>

  if(ip->valid == 0){
  102ab2:	8b 45 08             	mov    0x8(%ebp),%eax
  102ab5:	8b 40 0c             	mov    0xc(%eax),%eax
  102ab8:	85 c0                	test   %eax,%eax
  102aba:	0f 85 cd 00 00 00    	jne    102b8d <iread+0xfe>
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
  102ac0:	8b 45 08             	mov    0x8(%ebp),%eax
  102ac3:	8b 40 04             	mov    0x4(%eax),%eax
  102ac6:	c1 e8 03             	shr    $0x3,%eax
  102ac9:	89 c2                	mov    %eax,%edx
  102acb:	a1 94 9e 10 00       	mov    0x109e94,%eax
  102ad0:	01 c2                	add    %eax,%edx
  102ad2:	8b 45 08             	mov    0x8(%ebp),%eax
  102ad5:	8b 00                	mov    (%eax),%eax
  102ad7:	83 ec 08             	sub    $0x8,%esp
  102ada:	52                   	push   %edx
  102adb:	50                   	push   %eax
  102adc:	e8 ba f4 ff ff       	call   101f9b <bread>
  102ae1:	83 c4 10             	add    $0x10,%esp
  102ae4:	89 45 f4             	mov    %eax,-0xc(%ebp)
    dip = (struct dinode*)bp->data + ip->inum%IPB;
  102ae7:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102aea:	8d 50 1c             	lea    0x1c(%eax),%edx
  102aed:	8b 45 08             	mov    0x8(%ebp),%eax
  102af0:	8b 40 04             	mov    0x4(%eax),%eax
  102af3:	83 e0 07             	and    $0x7,%eax
  102af6:	c1 e0 06             	shl    $0x6,%eax
  102af9:	01 d0                	add    %edx,%eax
  102afb:	89 45 f0             	mov    %eax,-0x10(%ebp)
    ip->type = dip->type;
  102afe:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102b01:	0f b7 10             	movzwl (%eax),%edx
  102b04:	8b 45 08             	mov    0x8(%ebp),%eax
  102b07:	66 89 50 10          	mov    %dx,0x10(%eax)
    ip->major = dip->major;
  102b0b:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102b0e:	0f b7 50 02          	movzwl 0x2(%eax),%edx
  102b12:	8b 45 08             	mov    0x8(%ebp),%eax
  102b15:	66 89 50 12          	mov    %dx,0x12(%eax)
    ip->minor = dip->minor;
  102b19:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102b1c:	0f b7 50 04          	movzwl 0x4(%eax),%edx
  102b20:	8b 45 08             	mov    0x8(%ebp),%eax
  102b23:	66 89 50 14          	mov    %dx,0x14(%eax)
    ip->nlink = dip->nlink;
  102b27:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102b2a:	0f b7 50 06          	movzwl 0x6(%eax),%edx
  102b2e:	8b 45 08             	mov    0x8(%ebp),%eax
  102b31:	66 89 50 16          	mov    %dx,0x16(%eax)
    ip->size = dip->size;
  102b35:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102b38:	8b 50 08             	mov    0x8(%eax),%edx
  102b3b:	8b 45 08             	mov    0x8(%ebp),%eax
  102b3e:	89 50 18             	mov    %edx,0x18(%eax)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
  102b41:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102b44:	8d 50 0c             	lea    0xc(%eax),%edx
  102b47:	8b 45 08             	mov    0x8(%ebp),%eax
  102b4a:	83 c0 1c             	add    $0x1c,%eax
  102b4d:	83 ec 04             	sub    $0x4,%esp
  102b50:	6a 34                	push   $0x34
  102b52:	52                   	push   %edx
  102b53:	50                   	push   %eax
  102b54:	e8 ec e3 ff ff       	call   100f45 <memmove>
  102b59:	83 c4 10             	add    $0x10,%esp
    brelse(bp);
  102b5c:	83 ec 0c             	sub    $0xc,%esp
  102b5f:	ff 75 f4             	push   -0xc(%ebp)
  102b62:	e8 ac f4 ff ff       	call   102013 <brelse>
  102b67:	83 c4 10             	add    $0x10,%esp
    ip->valid = 1;
  102b6a:	8b 45 08             	mov    0x8(%ebp),%eax
  102b6d:	c7 40 0c 01 00 00 00 	movl   $0x1,0xc(%eax)
    if(ip->type == 0)
  102b74:	8b 45 08             	mov    0x8(%ebp),%eax
  102b77:	0f b7 40 10          	movzwl 0x10(%eax),%eax
  102b7b:	66 85 c0             	test   %ax,%ax
  102b7e:	75 0d                	jne    102b8d <iread+0xfe>
      panic("iread: no type");
  102b80:	83 ec 0c             	sub    $0xc,%esp
  102b83:	68 e7 42 10 00       	push   $0x1042e7
  102b88:	e8 21 d7 ff ff       	call   1002ae <panic>
  }
}
  102b8d:	90                   	nop
  102b8e:	c9                   	leave
  102b8f:	c3                   	ret

00102b90 <bmap>:

// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
static uint
bmap(struct inode *ip, uint bn)
{
  102b90:	55                   	push   %ebp
  102b91:	89 e5                	mov    %esp,%ebp
  102b93:	83 ec 18             	sub    $0x18,%esp
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
  102b96:	83 7d 0c 0b          	cmpl   $0xb,0xc(%ebp)
  102b9a:	77 42                	ja     102bde <bmap+0x4e>
    if((addr = ip->addrs[bn]) == 0)
  102b9c:	8b 45 08             	mov    0x8(%ebp),%eax
  102b9f:	8b 55 0c             	mov    0xc(%ebp),%edx
  102ba2:	83 c2 04             	add    $0x4,%edx
  102ba5:	8b 44 90 0c          	mov    0xc(%eax,%edx,4),%eax
  102ba9:	89 45 f4             	mov    %eax,-0xc(%ebp)
  102bac:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
  102bb0:	75 24                	jne    102bd6 <bmap+0x46>
      ip->addrs[bn] = addr = balloc(ip->dev);
  102bb2:	8b 45 08             	mov    0x8(%ebp),%eax
  102bb5:	8b 00                	mov    (%eax),%eax
  102bb7:	83 ec 0c             	sub    $0xc,%esp
  102bba:	50                   	push   %eax
  102bbb:	e8 7f f9 ff ff       	call   10253f <balloc>
  102bc0:	83 c4 10             	add    $0x10,%esp
  102bc3:	89 45 f4             	mov    %eax,-0xc(%ebp)
  102bc6:	8b 45 08             	mov    0x8(%ebp),%eax
  102bc9:	8b 55 0c             	mov    0xc(%ebp),%edx
  102bcc:	8d 4a 04             	lea    0x4(%edx),%ecx
  102bcf:	8b 55 f4             	mov    -0xc(%ebp),%edx
  102bd2:	89 54 88 0c          	mov    %edx,0xc(%eax,%ecx,4)
    return addr;
  102bd6:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102bd9:	e9 ca 00 00 00       	jmp    102ca8 <bmap+0x118>
  }
  bn -= NDIRECT;
  102bde:	83 6d 0c 0c          	subl   $0xc,0xc(%ebp)

  if(bn < NINDIRECT){
  102be2:	83 7d 0c 7f          	cmpl   $0x7f,0xc(%ebp)
  102be6:	0f 87 af 00 00 00    	ja     102c9b <bmap+0x10b>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0)
  102bec:	8b 45 08             	mov    0x8(%ebp),%eax
  102bef:	8b 40 4c             	mov    0x4c(%eax),%eax
  102bf2:	89 45 f4             	mov    %eax,-0xc(%ebp)
  102bf5:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
  102bf9:	75 1d                	jne    102c18 <bmap+0x88>
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
  102bfb:	8b 45 08             	mov    0x8(%ebp),%eax
  102bfe:	8b 00                	mov    (%eax),%eax
  102c00:	83 ec 0c             	sub    $0xc,%esp
  102c03:	50                   	push   %eax
  102c04:	e8 36 f9 ff ff       	call   10253f <balloc>
  102c09:	83 c4 10             	add    $0x10,%esp
  102c0c:	89 45 f4             	mov    %eax,-0xc(%ebp)
  102c0f:	8b 45 08             	mov    0x8(%ebp),%eax
  102c12:	8b 55 f4             	mov    -0xc(%ebp),%edx
  102c15:	89 50 4c             	mov    %edx,0x4c(%eax)
    bp = bread(ip->dev, addr);
  102c18:	8b 45 08             	mov    0x8(%ebp),%eax
  102c1b:	8b 00                	mov    (%eax),%eax
  102c1d:	83 ec 08             	sub    $0x8,%esp
  102c20:	ff 75 f4             	push   -0xc(%ebp)
  102c23:	50                   	push   %eax
  102c24:	e8 72 f3 ff ff       	call   101f9b <bread>
  102c29:	83 c4 10             	add    $0x10,%esp
  102c2c:	89 45 f0             	mov    %eax,-0x10(%ebp)
    a = (uint*)bp->data;
  102c2f:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102c32:	83 c0 1c             	add    $0x1c,%eax
  102c35:	89 45 ec             	mov    %eax,-0x14(%ebp)
    if((addr = a[bn]) == 0){
  102c38:	8b 45 0c             	mov    0xc(%ebp),%eax
  102c3b:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
  102c42:	8b 45 ec             	mov    -0x14(%ebp),%eax
  102c45:	01 d0                	add    %edx,%eax
  102c47:	8b 00                	mov    (%eax),%eax
  102c49:	89 45 f4             	mov    %eax,-0xc(%ebp)
  102c4c:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
  102c50:	75 36                	jne    102c88 <bmap+0xf8>
      a[bn] = addr = balloc(ip->dev);
  102c52:	8b 45 08             	mov    0x8(%ebp),%eax
  102c55:	8b 00                	mov    (%eax),%eax
  102c57:	83 ec 0c             	sub    $0xc,%esp
  102c5a:	50                   	push   %eax
  102c5b:	e8 df f8 ff ff       	call   10253f <balloc>
  102c60:	83 c4 10             	add    $0x10,%esp
  102c63:	89 45 f4             	mov    %eax,-0xc(%ebp)
  102c66:	8b 45 0c             	mov    0xc(%ebp),%eax
  102c69:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
  102c70:	8b 45 ec             	mov    -0x14(%ebp),%eax
  102c73:	01 c2                	add    %eax,%edx
  102c75:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102c78:	89 02                	mov    %eax,(%edx)
      log_write(bp);
  102c7a:	83 ec 0c             	sub    $0xc,%esp
  102c7d:	ff 75 f0             	push   -0x10(%ebp)
  102c80:	e8 2e 12 00 00       	call   103eb3 <log_write>
  102c85:	83 c4 10             	add    $0x10,%esp
    }
    brelse(bp);
  102c88:	83 ec 0c             	sub    $0xc,%esp
  102c8b:	ff 75 f0             	push   -0x10(%ebp)
  102c8e:	e8 80 f3 ff ff       	call   102013 <brelse>
  102c93:	83 c4 10             	add    $0x10,%esp
    return addr;
  102c96:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102c99:	eb 0d                	jmp    102ca8 <bmap+0x118>
  }

  panic("bmap: out of range");
  102c9b:	83 ec 0c             	sub    $0xc,%esp
  102c9e:	68 f6 42 10 00       	push   $0x1042f6
  102ca3:	e8 06 d6 ff ff       	call   1002ae <panic>
}
  102ca8:	c9                   	leave
  102ca9:	c3                   	ret

00102caa <itrunc>:
// to it (no directory entries referring to it)
// and has no in-memory reference to it (is
// not an open file or current directory).
static void
itrunc(struct inode *ip)
{
  102caa:	55                   	push   %ebp
  102cab:	89 e5                	mov    %esp,%ebp
  102cad:	83 ec 18             	sub    $0x18,%esp
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
  102cb0:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  102cb7:	eb 45                	jmp    102cfe <itrunc+0x54>
    if(ip->addrs[i]){
  102cb9:	8b 45 08             	mov    0x8(%ebp),%eax
  102cbc:	8b 55 f4             	mov    -0xc(%ebp),%edx
  102cbf:	83 c2 04             	add    $0x4,%edx
  102cc2:	8b 44 90 0c          	mov    0xc(%eax,%edx,4),%eax
  102cc6:	85 c0                	test   %eax,%eax
  102cc8:	74 30                	je     102cfa <itrunc+0x50>
      bfree(ip->dev, ip->addrs[i]);
  102cca:	8b 45 08             	mov    0x8(%ebp),%eax
  102ccd:	8b 55 f4             	mov    -0xc(%ebp),%edx
  102cd0:	83 c2 04             	add    $0x4,%edx
  102cd3:	8b 44 90 0c          	mov    0xc(%eax,%edx,4),%eax
  102cd7:	8b 55 08             	mov    0x8(%ebp),%edx
  102cda:	8b 12                	mov    (%edx),%edx
  102cdc:	83 ec 08             	sub    $0x8,%esp
  102cdf:	50                   	push   %eax
  102ce0:	52                   	push   %edx
  102ce1:	e8 aa f9 ff ff       	call   102690 <bfree>
  102ce6:	83 c4 10             	add    $0x10,%esp
      ip->addrs[i] = 0;
  102ce9:	8b 45 08             	mov    0x8(%ebp),%eax
  102cec:	8b 55 f4             	mov    -0xc(%ebp),%edx
  102cef:	83 c2 04             	add    $0x4,%edx
  102cf2:	c7 44 90 0c 00 00 00 	movl   $0x0,0xc(%eax,%edx,4)
  102cf9:	00 
  for(i = 0; i < NDIRECT; i++){
  102cfa:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  102cfe:	83 7d f4 0b          	cmpl   $0xb,-0xc(%ebp)
  102d02:	7e b5                	jle    102cb9 <itrunc+0xf>
    }
  }

  if(ip->addrs[NDIRECT]){
  102d04:	8b 45 08             	mov    0x8(%ebp),%eax
  102d07:	8b 40 4c             	mov    0x4c(%eax),%eax
  102d0a:	85 c0                	test   %eax,%eax
  102d0c:	0f 84 af 00 00 00    	je     102dc1 <itrunc+0x117>
    bp = bread_wr(ip->dev, ip->addrs[NDIRECT]);
  102d12:	8b 45 08             	mov    0x8(%ebp),%eax
  102d15:	8b 50 4c             	mov    0x4c(%eax),%edx
  102d18:	8b 45 08             	mov    0x8(%ebp),%eax
  102d1b:	8b 00                	mov    (%eax),%eax
  102d1d:	83 ec 08             	sub    $0x8,%esp
  102d20:	52                   	push   %edx
  102d21:	50                   	push   %eax
  102d22:	e8 d3 f2 ff ff       	call   101ffa <bread_wr>
  102d27:	83 c4 10             	add    $0x10,%esp
  102d2a:	89 45 ec             	mov    %eax,-0x14(%ebp)
    write_log_ul(bp);
  102d2d:	83 ec 0c             	sub    $0xc,%esp
  102d30:	ff 75 ec             	push   -0x14(%ebp)
  102d33:	e8 1b 12 00 00       	call   103f53 <write_log_ul>
  102d38:	83 c4 10             	add    $0x10,%esp
    a = (uint*)bp->data;
  102d3b:	8b 45 ec             	mov    -0x14(%ebp),%eax
  102d3e:	83 c0 1c             	add    $0x1c,%eax
  102d41:	89 45 e8             	mov    %eax,-0x18(%ebp)
    for(j = 0; j < NINDIRECT; j++){
  102d44:	c7 45 f0 00 00 00 00 	movl   $0x0,-0x10(%ebp)
  102d4b:	eb 3c                	jmp    102d89 <itrunc+0xdf>
      if(a[j])
  102d4d:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102d50:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
  102d57:	8b 45 e8             	mov    -0x18(%ebp),%eax
  102d5a:	01 d0                	add    %edx,%eax
  102d5c:	8b 00                	mov    (%eax),%eax
  102d5e:	85 c0                	test   %eax,%eax
  102d60:	74 23                	je     102d85 <itrunc+0xdb>
        bfree(ip->dev, a[j]);
  102d62:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102d65:	8d 14 85 00 00 00 00 	lea    0x0(,%eax,4),%edx
  102d6c:	8b 45 e8             	mov    -0x18(%ebp),%eax
  102d6f:	01 d0                	add    %edx,%eax
  102d71:	8b 00                	mov    (%eax),%eax
  102d73:	8b 55 08             	mov    0x8(%ebp),%edx
  102d76:	8b 12                	mov    (%edx),%edx
  102d78:	83 ec 08             	sub    $0x8,%esp
  102d7b:	50                   	push   %eax
  102d7c:	52                   	push   %edx
  102d7d:	e8 0e f9 ff ff       	call   102690 <bfree>
  102d82:	83 c4 10             	add    $0x10,%esp
    for(j = 0; j < NINDIRECT; j++){
  102d85:	83 45 f0 01          	addl   $0x1,-0x10(%ebp)
  102d89:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102d8c:	83 f8 7f             	cmp    $0x7f,%eax
  102d8f:	76 bc                	jbe    102d4d <itrunc+0xa3>
    }
    brelse(bp);
  102d91:	83 ec 0c             	sub    $0xc,%esp
  102d94:	ff 75 ec             	push   -0x14(%ebp)
  102d97:	e8 77 f2 ff ff       	call   102013 <brelse>
  102d9c:	83 c4 10             	add    $0x10,%esp
    bfree(ip->dev, ip->addrs[NDIRECT]);
  102d9f:	8b 45 08             	mov    0x8(%ebp),%eax
  102da2:	8b 40 4c             	mov    0x4c(%eax),%eax
  102da5:	8b 55 08             	mov    0x8(%ebp),%edx
  102da8:	8b 12                	mov    (%edx),%edx
  102daa:	83 ec 08             	sub    $0x8,%esp
  102dad:	50                   	push   %eax
  102dae:	52                   	push   %edx
  102daf:	e8 dc f8 ff ff       	call   102690 <bfree>
  102db4:	83 c4 10             	add    $0x10,%esp
    ip->addrs[NDIRECT] = 0;
  102db7:	8b 45 08             	mov    0x8(%ebp),%eax
  102dba:	c7 40 4c 00 00 00 00 	movl   $0x0,0x4c(%eax)
  }

  ip->size = 0;
  102dc1:	8b 45 08             	mov    0x8(%ebp),%eax
  102dc4:	c7 40 18 00 00 00 00 	movl   $0x0,0x18(%eax)
  iupdate(ip);
  102dcb:	83 ec 0c             	sub    $0xc,%esp
  102dce:	ff 75 08             	push   0x8(%ebp)
  102dd1:	e8 3b fb ff ff       	call   102911 <iupdate>
  102dd6:	83 c4 10             	add    $0x10,%esp
}
  102dd9:	90                   	nop
  102dda:	c9                   	leave
  102ddb:	c3                   	ret

00102ddc <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
  102ddc:	55                   	push   %ebp
  102ddd:	89 e5                	mov    %esp,%ebp
  st->dev = ip->dev;
  102ddf:	8b 45 08             	mov    0x8(%ebp),%eax
  102de2:	8b 00                	mov    (%eax),%eax
  102de4:	89 c2                	mov    %eax,%edx
  102de6:	8b 45 0c             	mov    0xc(%ebp),%eax
  102de9:	89 50 04             	mov    %edx,0x4(%eax)
  st->ino = ip->inum;
  102dec:	8b 45 08             	mov    0x8(%ebp),%eax
  102def:	8b 50 04             	mov    0x4(%eax),%edx
  102df2:	8b 45 0c             	mov    0xc(%ebp),%eax
  102df5:	89 50 08             	mov    %edx,0x8(%eax)
  st->type = ip->type;
  102df8:	8b 45 08             	mov    0x8(%ebp),%eax
  102dfb:	0f b7 50 10          	movzwl 0x10(%eax),%edx
  102dff:	8b 45 0c             	mov    0xc(%ebp),%eax
  102e02:	66 89 10             	mov    %dx,(%eax)
  st->nlink = ip->nlink;
  102e05:	8b 45 08             	mov    0x8(%ebp),%eax
  102e08:	0f b7 50 16          	movzwl 0x16(%eax),%edx
  102e0c:	8b 45 0c             	mov    0xc(%ebp),%eax
  102e0f:	66 89 50 0c          	mov    %dx,0xc(%eax)
  st->size = ip->size;
  102e13:	8b 45 08             	mov    0x8(%ebp),%eax
  102e16:	8b 50 18             	mov    0x18(%eax),%edx
  102e19:	8b 45 0c             	mov    0xc(%ebp),%eax
  102e1c:	89 50 10             	mov    %edx,0x10(%eax)
}
  102e1f:	90                   	nop
  102e20:	5d                   	pop    %ebp
  102e21:	c3                   	ret

00102e22 <readi>:

// Read data from inode.
// Caller must hold ip->lock.
int
readi(struct inode *ip, char *dst, uint off, uint n)
{
  102e22:	55                   	push   %ebp
  102e23:	89 e5                	mov    %esp,%ebp
  102e25:	83 ec 18             	sub    $0x18,%esp
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off || ip->nlink < 1)
  102e28:	8b 45 08             	mov    0x8(%ebp),%eax
  102e2b:	8b 40 18             	mov    0x18(%eax),%eax
  102e2e:	3b 45 10             	cmp    0x10(%ebp),%eax
  102e31:	72 19                	jb     102e4c <readi+0x2a>
  102e33:	8b 55 10             	mov    0x10(%ebp),%edx
  102e36:	8b 45 14             	mov    0x14(%ebp),%eax
  102e39:	01 d0                	add    %edx,%eax
  102e3b:	3b 45 10             	cmp    0x10(%ebp),%eax
  102e3e:	72 0c                	jb     102e4c <readi+0x2a>
  102e40:	8b 45 08             	mov    0x8(%ebp),%eax
  102e43:	0f b7 40 16          	movzwl 0x16(%eax),%eax
  102e47:	66 85 c0             	test   %ax,%ax
  102e4a:	7f 0a                	jg     102e56 <readi+0x34>
    return -1;
  102e4c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  102e51:	e9 c2 00 00 00       	jmp    102f18 <readi+0xf6>
  if(off + n > ip->size)
  102e56:	8b 55 10             	mov    0x10(%ebp),%edx
  102e59:	8b 45 14             	mov    0x14(%ebp),%eax
  102e5c:	01 c2                	add    %eax,%edx
  102e5e:	8b 45 08             	mov    0x8(%ebp),%eax
  102e61:	8b 40 18             	mov    0x18(%eax),%eax
  102e64:	39 d0                	cmp    %edx,%eax
  102e66:	73 0c                	jae    102e74 <readi+0x52>
    n = ip->size - off;
  102e68:	8b 45 08             	mov    0x8(%ebp),%eax
  102e6b:	8b 40 18             	mov    0x18(%eax),%eax
  102e6e:	2b 45 10             	sub    0x10(%ebp),%eax
  102e71:	89 45 14             	mov    %eax,0x14(%ebp)

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
  102e74:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  102e7b:	e9 89 00 00 00       	jmp    102f09 <readi+0xe7>
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
  102e80:	8b 45 10             	mov    0x10(%ebp),%eax
  102e83:	c1 e8 09             	shr    $0x9,%eax
  102e86:	83 ec 08             	sub    $0x8,%esp
  102e89:	50                   	push   %eax
  102e8a:	ff 75 08             	push   0x8(%ebp)
  102e8d:	e8 fe fc ff ff       	call   102b90 <bmap>
  102e92:	83 c4 10             	add    $0x10,%esp
  102e95:	8b 55 08             	mov    0x8(%ebp),%edx
  102e98:	8b 12                	mov    (%edx),%edx
  102e9a:	83 ec 08             	sub    $0x8,%esp
  102e9d:	50                   	push   %eax
  102e9e:	52                   	push   %edx
  102e9f:	e8 f7 f0 ff ff       	call   101f9b <bread>
  102ea4:	83 c4 10             	add    $0x10,%esp
  102ea7:	89 45 f0             	mov    %eax,-0x10(%ebp)
    m = min(n - tot, BSIZE - off%BSIZE);
  102eaa:	8b 45 10             	mov    0x10(%ebp),%eax
  102ead:	25 ff 01 00 00       	and    $0x1ff,%eax
  102eb2:	ba 00 02 00 00       	mov    $0x200,%edx
  102eb7:	29 c2                	sub    %eax,%edx
  102eb9:	8b 45 14             	mov    0x14(%ebp),%eax
  102ebc:	2b 45 f4             	sub    -0xc(%ebp),%eax
  102ebf:	39 c2                	cmp    %eax,%edx
  102ec1:	0f 46 c2             	cmovbe %edx,%eax
  102ec4:	89 45 ec             	mov    %eax,-0x14(%ebp)
    memmove(dst, bp->data + off%BSIZE, m);
  102ec7:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102eca:	8d 50 1c             	lea    0x1c(%eax),%edx
  102ecd:	8b 45 10             	mov    0x10(%ebp),%eax
  102ed0:	25 ff 01 00 00       	and    $0x1ff,%eax
  102ed5:	01 d0                	add    %edx,%eax
  102ed7:	83 ec 04             	sub    $0x4,%esp
  102eda:	ff 75 ec             	push   -0x14(%ebp)
  102edd:	50                   	push   %eax
  102ede:	ff 75 0c             	push   0xc(%ebp)
  102ee1:	e8 5f e0 ff ff       	call   100f45 <memmove>
  102ee6:	83 c4 10             	add    $0x10,%esp
    brelse(bp);
  102ee9:	83 ec 0c             	sub    $0xc,%esp
  102eec:	ff 75 f0             	push   -0x10(%ebp)
  102eef:	e8 1f f1 ff ff       	call   102013 <brelse>
  102ef4:	83 c4 10             	add    $0x10,%esp
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
  102ef7:	8b 45 ec             	mov    -0x14(%ebp),%eax
  102efa:	01 45 f4             	add    %eax,-0xc(%ebp)
  102efd:	8b 45 ec             	mov    -0x14(%ebp),%eax
  102f00:	01 45 10             	add    %eax,0x10(%ebp)
  102f03:	8b 45 ec             	mov    -0x14(%ebp),%eax
  102f06:	01 45 0c             	add    %eax,0xc(%ebp)
  102f09:	8b 45 f4             	mov    -0xc(%ebp),%eax
  102f0c:	3b 45 14             	cmp    0x14(%ebp),%eax
  102f0f:	0f 82 6b ff ff ff    	jb     102e80 <readi+0x5e>
  }
  return n;
  102f15:	8b 45 14             	mov    0x14(%ebp),%eax
}
  102f18:	c9                   	leave
  102f19:	c3                   	ret

00102f1a <writei>:

// Write data to inode.
// Caller must hold ip->lock.
int
writei(struct inode *ip, char *src, uint off, uint n)
{
  102f1a:	55                   	push   %ebp
  102f1b:	89 e5                	mov    %esp,%ebp
  102f1d:	83 ec 18             	sub    $0x18,%esp
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
  102f20:	8b 45 08             	mov    0x8(%ebp),%eax
  102f23:	8b 40 18             	mov    0x18(%eax),%eax
  102f26:	3b 45 10             	cmp    0x10(%ebp),%eax
  102f29:	72 0d                	jb     102f38 <writei+0x1e>
  102f2b:	8b 55 10             	mov    0x10(%ebp),%edx
  102f2e:	8b 45 14             	mov    0x14(%ebp),%eax
  102f31:	01 d0                	add    %edx,%eax
  102f33:	3b 45 10             	cmp    0x10(%ebp),%eax
  102f36:	73 0a                	jae    102f42 <writei+0x28>
    return -1;
  102f38:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  102f3d:	e9 01 01 00 00       	jmp    103043 <writei+0x129>
  if(off + n > MAXFILE*BSIZE)
  102f42:	8b 55 10             	mov    0x10(%ebp),%edx
  102f45:	8b 45 14             	mov    0x14(%ebp),%eax
  102f48:	01 d0                	add    %edx,%eax
  102f4a:	3d 00 18 01 00       	cmp    $0x11800,%eax
  102f4f:	76 0a                	jbe    102f5b <writei+0x41>
    return -1;
  102f51:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  102f56:	e9 e8 00 00 00       	jmp    103043 <writei+0x129>

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
  102f5b:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  102f62:	e9 a5 00 00 00       	jmp    10300c <writei+0xf2>
    bp = bread_wr(ip->dev, bmap(ip, off/BSIZE));
  102f67:	8b 45 10             	mov    0x10(%ebp),%eax
  102f6a:	c1 e8 09             	shr    $0x9,%eax
  102f6d:	83 ec 08             	sub    $0x8,%esp
  102f70:	50                   	push   %eax
  102f71:	ff 75 08             	push   0x8(%ebp)
  102f74:	e8 17 fc ff ff       	call   102b90 <bmap>
  102f79:	83 c4 10             	add    $0x10,%esp
  102f7c:	8b 55 08             	mov    0x8(%ebp),%edx
  102f7f:	8b 12                	mov    (%edx),%edx
  102f81:	83 ec 08             	sub    $0x8,%esp
  102f84:	50                   	push   %eax
  102f85:	52                   	push   %edx
  102f86:	e8 6f f0 ff ff       	call   101ffa <bread_wr>
  102f8b:	83 c4 10             	add    $0x10,%esp
  102f8e:	89 45 f0             	mov    %eax,-0x10(%ebp)
    write_log_ul(bp);
  102f91:	83 ec 0c             	sub    $0xc,%esp
  102f94:	ff 75 f0             	push   -0x10(%ebp)
  102f97:	e8 b7 0f 00 00       	call   103f53 <write_log_ul>
  102f9c:	83 c4 10             	add    $0x10,%esp
    m = min(n - tot, BSIZE - off%BSIZE);
  102f9f:	8b 45 10             	mov    0x10(%ebp),%eax
  102fa2:	25 ff 01 00 00       	and    $0x1ff,%eax
  102fa7:	ba 00 02 00 00       	mov    $0x200,%edx
  102fac:	29 c2                	sub    %eax,%edx
  102fae:	8b 45 14             	mov    0x14(%ebp),%eax
  102fb1:	2b 45 f4             	sub    -0xc(%ebp),%eax
  102fb4:	39 c2                	cmp    %eax,%edx
  102fb6:	0f 46 c2             	cmovbe %edx,%eax
  102fb9:	89 45 ec             	mov    %eax,-0x14(%ebp)
    memmove(bp->data + off%BSIZE, src, m);
  102fbc:	8b 45 f0             	mov    -0x10(%ebp),%eax
  102fbf:	8d 50 1c             	lea    0x1c(%eax),%edx
  102fc2:	8b 45 10             	mov    0x10(%ebp),%eax
  102fc5:	25 ff 01 00 00       	and    $0x1ff,%eax
  102fca:	01 d0                	add    %edx,%eax
  102fcc:	83 ec 04             	sub    $0x4,%esp
  102fcf:	ff 75 ec             	push   -0x14(%ebp)
  102fd2:	ff 75 0c             	push   0xc(%ebp)
  102fd5:	50                   	push   %eax
  102fd6:	e8 6a df ff ff       	call   100f45 <memmove>
  102fdb:	83 c4 10             	add    $0x10,%esp
    log_write(bp);
  102fde:	83 ec 0c             	sub    $0xc,%esp
  102fe1:	ff 75 f0             	push   -0x10(%ebp)
  102fe4:	e8 ca 0e 00 00       	call   103eb3 <log_write>
  102fe9:	83 c4 10             	add    $0x10,%esp
    brelse(bp);
  102fec:	83 ec 0c             	sub    $0xc,%esp
  102fef:	ff 75 f0             	push   -0x10(%ebp)
  102ff2:	e8 1c f0 ff ff       	call   102013 <brelse>
  102ff7:	83 c4 10             	add    $0x10,%esp
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
  102ffa:	8b 45 ec             	mov    -0x14(%ebp),%eax
  102ffd:	01 45 f4             	add    %eax,-0xc(%ebp)
  103000:	8b 45 ec             	mov    -0x14(%ebp),%eax
  103003:	01 45 10             	add    %eax,0x10(%ebp)
  103006:	8b 45 ec             	mov    -0x14(%ebp),%eax
  103009:	01 45 0c             	add    %eax,0xc(%ebp)
  10300c:	8b 45 f4             	mov    -0xc(%ebp),%eax
  10300f:	3b 45 14             	cmp    0x14(%ebp),%eax
  103012:	0f 82 4f ff ff ff    	jb     102f67 <writei+0x4d>
  }

  if(n > 0 && off > ip->size){
  103018:	83 7d 14 00          	cmpl   $0x0,0x14(%ebp)
  10301c:	74 22                	je     103040 <writei+0x126>
  10301e:	8b 45 08             	mov    0x8(%ebp),%eax
  103021:	8b 40 18             	mov    0x18(%eax),%eax
  103024:	3b 45 10             	cmp    0x10(%ebp),%eax
  103027:	73 17                	jae    103040 <writei+0x126>
    ip->size = off;
  103029:	8b 45 08             	mov    0x8(%ebp),%eax
  10302c:	8b 55 10             	mov    0x10(%ebp),%edx
  10302f:	89 50 18             	mov    %edx,0x18(%eax)
    iupdate(ip);
  103032:	83 ec 0c             	sub    $0xc,%esp
  103035:	ff 75 08             	push   0x8(%ebp)
  103038:	e8 d4 f8 ff ff       	call   102911 <iupdate>
  10303d:	83 c4 10             	add    $0x10,%esp
  }
  return n;
  103040:	8b 45 14             	mov    0x14(%ebp),%eax
}
  103043:	c9                   	leave
  103044:	c3                   	ret

00103045 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
  103045:	55                   	push   %ebp
  103046:	89 e5                	mov    %esp,%ebp
  103048:	83 ec 08             	sub    $0x8,%esp
  return strncmp(s, t, DIRSIZ);
  10304b:	83 ec 04             	sub    $0x4,%esp
  10304e:	6a 0e                	push   $0xe
  103050:	ff 75 0c             	push   0xc(%ebp)
  103053:	ff 75 08             	push   0x8(%ebp)
  103056:	e8 80 df ff ff       	call   100fdb <strncmp>
  10305b:	83 c4 10             	add    $0x10,%esp
}
  10305e:	c9                   	leave
  10305f:	c3                   	ret

00103060 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
  103060:	55                   	push   %ebp
  103061:	89 e5                	mov    %esp,%ebp
  103063:	83 ec 28             	sub    $0x28,%esp
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
  103066:	8b 45 08             	mov    0x8(%ebp),%eax
  103069:	0f b7 40 10          	movzwl 0x10(%eax),%eax
  10306d:	66 83 f8 01          	cmp    $0x1,%ax
  103071:	74 0d                	je     103080 <dirlookup+0x20>
    panic("dirlookup not DIR");
  103073:	83 ec 0c             	sub    $0xc,%esp
  103076:	68 09 43 10 00       	push   $0x104309
  10307b:	e8 2e d2 ff ff       	call   1002ae <panic>

  for(off = 0; off < dp->size; off += sizeof(de)){
  103080:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  103087:	eb 7b                	jmp    103104 <dirlookup+0xa4>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
  103089:	6a 10                	push   $0x10
  10308b:	ff 75 f4             	push   -0xc(%ebp)
  10308e:	8d 45 e0             	lea    -0x20(%ebp),%eax
  103091:	50                   	push   %eax
  103092:	ff 75 08             	push   0x8(%ebp)
  103095:	e8 88 fd ff ff       	call   102e22 <readi>
  10309a:	83 c4 10             	add    $0x10,%esp
  10309d:	83 f8 10             	cmp    $0x10,%eax
  1030a0:	74 0d                	je     1030af <dirlookup+0x4f>
      panic("dirlookup read");
  1030a2:	83 ec 0c             	sub    $0xc,%esp
  1030a5:	68 1b 43 10 00       	push   $0x10431b
  1030aa:	e8 ff d1 ff ff       	call   1002ae <panic>
    if(de.inum == 0)
  1030af:	0f b7 45 e0          	movzwl -0x20(%ebp),%eax
  1030b3:	66 85 c0             	test   %ax,%ax
  1030b6:	74 47                	je     1030ff <dirlookup+0x9f>
      continue;
    if(namecmp(name, de.name) == 0){
  1030b8:	83 ec 08             	sub    $0x8,%esp
  1030bb:	8d 45 e0             	lea    -0x20(%ebp),%eax
  1030be:	83 c0 02             	add    $0x2,%eax
  1030c1:	50                   	push   %eax
  1030c2:	ff 75 0c             	push   0xc(%ebp)
  1030c5:	e8 7b ff ff ff       	call   103045 <namecmp>
  1030ca:	83 c4 10             	add    $0x10,%esp
  1030cd:	85 c0                	test   %eax,%eax
  1030cf:	75 2f                	jne    103100 <dirlookup+0xa0>
      // entry matches path element
      if(poff)
  1030d1:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
  1030d5:	74 08                	je     1030df <dirlookup+0x7f>
        *poff = off;
  1030d7:	8b 45 10             	mov    0x10(%ebp),%eax
  1030da:	8b 55 f4             	mov    -0xc(%ebp),%edx
  1030dd:	89 10                	mov    %edx,(%eax)
      inum = de.inum;
  1030df:	0f b7 45 e0          	movzwl -0x20(%ebp),%eax
  1030e3:	0f b7 c0             	movzwl %ax,%eax
  1030e6:	89 45 f0             	mov    %eax,-0x10(%ebp)
      return iget(dp->dev, inum);
  1030e9:	8b 45 08             	mov    0x8(%ebp),%eax
  1030ec:	8b 00                	mov    (%eax),%eax
  1030ee:	83 ec 08             	sub    $0x8,%esp
  1030f1:	ff 75 f0             	push   -0x10(%ebp)
  1030f4:	50                   	push   %eax
  1030f5:	e8 e6 f8 ff ff       	call   1029e0 <iget>
  1030fa:	83 c4 10             	add    $0x10,%esp
  1030fd:	eb 19                	jmp    103118 <dirlookup+0xb8>
      continue;
  1030ff:	90                   	nop
  for(off = 0; off < dp->size; off += sizeof(de)){
  103100:	83 45 f4 10          	addl   $0x10,-0xc(%ebp)
  103104:	8b 45 08             	mov    0x8(%ebp),%eax
  103107:	8b 40 18             	mov    0x18(%eax),%eax
  10310a:	39 45 f4             	cmp    %eax,-0xc(%ebp)
  10310d:	0f 82 76 ff ff ff    	jb     103089 <dirlookup+0x29>
    }
  }

  return 0;
  103113:	b8 00 00 00 00       	mov    $0x0,%eax
}
  103118:	c9                   	leave
  103119:	c3                   	ret

0010311a <dirlink>:


// Write a new directory entry (name, inum) into the directory dp.
int
dirlink(struct inode *dp, char *name, uint inum)
{
  10311a:	55                   	push   %ebp
  10311b:	89 e5                	mov    %esp,%ebp
  10311d:	83 ec 28             	sub    $0x28,%esp
  int off;
  struct dirent de;
  struct inode *ip;

  // Check that name is not present.
  if((ip = dirlookup(dp, name, 0)) != 0){
  103120:	83 ec 04             	sub    $0x4,%esp
  103123:	6a 00                	push   $0x0
  103125:	ff 75 0c             	push   0xc(%ebp)
  103128:	ff 75 08             	push   0x8(%ebp)
  10312b:	e8 30 ff ff ff       	call   103060 <dirlookup>
  103130:	83 c4 10             	add    $0x10,%esp
  103133:	89 45 f0             	mov    %eax,-0x10(%ebp)
  103136:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
  10313a:	74 18                	je     103154 <dirlink+0x3a>
    iput(ip);
  10313c:	83 ec 0c             	sub    $0xc,%esp
  10313f:	ff 75 f0             	push   -0x10(%ebp)
  103142:	e8 5e f7 ff ff       	call   1028a5 <iput>
  103147:	83 c4 10             	add    $0x10,%esp
    return -1;
  10314a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  10314f:	e9 9c 00 00 00       	jmp    1031f0 <dirlink+0xd6>
  }

  // Look for an empty dirent.
  for(off = 0; off < dp->size; off += sizeof(de)){
  103154:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  10315b:	eb 39                	jmp    103196 <dirlink+0x7c>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
  10315d:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103160:	6a 10                	push   $0x10
  103162:	50                   	push   %eax
  103163:	8d 45 e0             	lea    -0x20(%ebp),%eax
  103166:	50                   	push   %eax
  103167:	ff 75 08             	push   0x8(%ebp)
  10316a:	e8 b3 fc ff ff       	call   102e22 <readi>
  10316f:	83 c4 10             	add    $0x10,%esp
  103172:	83 f8 10             	cmp    $0x10,%eax
  103175:	74 0d                	je     103184 <dirlink+0x6a>
      panic("dirlink read");
  103177:	83 ec 0c             	sub    $0xc,%esp
  10317a:	68 2a 43 10 00       	push   $0x10432a
  10317f:	e8 2a d1 ff ff       	call   1002ae <panic>
    if(de.inum == 0)
  103184:	0f b7 45 e0          	movzwl -0x20(%ebp),%eax
  103188:	66 85 c0             	test   %ax,%ax
  10318b:	74 18                	je     1031a5 <dirlink+0x8b>
  for(off = 0; off < dp->size; off += sizeof(de)){
  10318d:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103190:	83 c0 10             	add    $0x10,%eax
  103193:	89 45 f4             	mov    %eax,-0xc(%ebp)
  103196:	8b 45 08             	mov    0x8(%ebp),%eax
  103199:	8b 40 18             	mov    0x18(%eax),%eax
  10319c:	8b 55 f4             	mov    -0xc(%ebp),%edx
  10319f:	39 c2                	cmp    %eax,%edx
  1031a1:	72 ba                	jb     10315d <dirlink+0x43>
  1031a3:	eb 01                	jmp    1031a6 <dirlink+0x8c>
      break;
  1031a5:	90                   	nop
  }

  strncpy(de.name, name, DIRSIZ);
  1031a6:	83 ec 04             	sub    $0x4,%esp
  1031a9:	6a 0e                	push   $0xe
  1031ab:	ff 75 0c             	push   0xc(%ebp)
  1031ae:	8d 45 e0             	lea    -0x20(%ebp),%eax
  1031b1:	83 c0 02             	add    $0x2,%eax
  1031b4:	50                   	push   %eax
  1031b5:	e8 77 de ff ff       	call   101031 <strncpy>
  1031ba:	83 c4 10             	add    $0x10,%esp
  de.inum = inum;
  1031bd:	8b 45 10             	mov    0x10(%ebp),%eax
  1031c0:	66 89 45 e0          	mov    %ax,-0x20(%ebp)
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
  1031c4:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1031c7:	6a 10                	push   $0x10
  1031c9:	50                   	push   %eax
  1031ca:	8d 45 e0             	lea    -0x20(%ebp),%eax
  1031cd:	50                   	push   %eax
  1031ce:	ff 75 08             	push   0x8(%ebp)
  1031d1:	e8 44 fd ff ff       	call   102f1a <writei>
  1031d6:	83 c4 10             	add    $0x10,%esp
  1031d9:	83 f8 10             	cmp    $0x10,%eax
  1031dc:	74 0d                	je     1031eb <dirlink+0xd1>
    panic("dirlink");
  1031de:	83 ec 0c             	sub    $0xc,%esp
  1031e1:	68 37 43 10 00       	push   $0x104337
  1031e6:	e8 c3 d0 ff ff       	call   1002ae <panic>

  return 0;
  1031eb:	b8 00 00 00 00       	mov    $0x0,%eax
}
  1031f0:	c9                   	leave
  1031f1:	c3                   	ret

001031f2 <skipelem>:
//   skipelem("a", name) = "", setting name = "a"
//   skipelem("", name) = skipelem("////", name) = 0
//
static char*
skipelem(char *path, char *name)
{
  1031f2:	55                   	push   %ebp
  1031f3:	89 e5                	mov    %esp,%ebp
  1031f5:	83 ec 18             	sub    $0x18,%esp
  char *s;
  int len;

  while(*path == '/')
  1031f8:	eb 04                	jmp    1031fe <skipelem+0xc>
    path++;
  1031fa:	83 45 08 01          	addl   $0x1,0x8(%ebp)
  while(*path == '/')
  1031fe:	8b 45 08             	mov    0x8(%ebp),%eax
  103201:	0f b6 00             	movzbl (%eax),%eax
  103204:	3c 2f                	cmp    $0x2f,%al
  103206:	74 f2                	je     1031fa <skipelem+0x8>
  if(*path == 0)
  103208:	8b 45 08             	mov    0x8(%ebp),%eax
  10320b:	0f b6 00             	movzbl (%eax),%eax
  10320e:	84 c0                	test   %al,%al
  103210:	75 07                	jne    103219 <skipelem+0x27>
    return 0;
  103212:	b8 00 00 00 00       	mov    $0x0,%eax
  103217:	eb 77                	jmp    103290 <skipelem+0x9e>
  s = path;
  103219:	8b 45 08             	mov    0x8(%ebp),%eax
  10321c:	89 45 f4             	mov    %eax,-0xc(%ebp)
  while(*path != '/' && *path != 0)
  10321f:	eb 04                	jmp    103225 <skipelem+0x33>
    path++;
  103221:	83 45 08 01          	addl   $0x1,0x8(%ebp)
  while(*path != '/' && *path != 0)
  103225:	8b 45 08             	mov    0x8(%ebp),%eax
  103228:	0f b6 00             	movzbl (%eax),%eax
  10322b:	3c 2f                	cmp    $0x2f,%al
  10322d:	74 0a                	je     103239 <skipelem+0x47>
  10322f:	8b 45 08             	mov    0x8(%ebp),%eax
  103232:	0f b6 00             	movzbl (%eax),%eax
  103235:	84 c0                	test   %al,%al
  103237:	75 e8                	jne    103221 <skipelem+0x2f>
  len = path - s;
  103239:	8b 45 08             	mov    0x8(%ebp),%eax
  10323c:	2b 45 f4             	sub    -0xc(%ebp),%eax
  10323f:	89 45 f0             	mov    %eax,-0x10(%ebp)
  if(len >= DIRSIZ)
  103242:	83 7d f0 0d          	cmpl   $0xd,-0x10(%ebp)
  103246:	7e 15                	jle    10325d <skipelem+0x6b>
    memmove(name, s, DIRSIZ);
  103248:	83 ec 04             	sub    $0x4,%esp
  10324b:	6a 0e                	push   $0xe
  10324d:	ff 75 f4             	push   -0xc(%ebp)
  103250:	ff 75 0c             	push   0xc(%ebp)
  103253:	e8 ed dc ff ff       	call   100f45 <memmove>
  103258:	83 c4 10             	add    $0x10,%esp
  10325b:	eb 26                	jmp    103283 <skipelem+0x91>
  else {
    memmove(name, s, len);
  10325d:	8b 45 f0             	mov    -0x10(%ebp),%eax
  103260:	83 ec 04             	sub    $0x4,%esp
  103263:	50                   	push   %eax
  103264:	ff 75 f4             	push   -0xc(%ebp)
  103267:	ff 75 0c             	push   0xc(%ebp)
  10326a:	e8 d6 dc ff ff       	call   100f45 <memmove>
  10326f:	83 c4 10             	add    $0x10,%esp
    name[len] = 0;
  103272:	8b 55 f0             	mov    -0x10(%ebp),%edx
  103275:	8b 45 0c             	mov    0xc(%ebp),%eax
  103278:	01 d0                	add    %edx,%eax
  10327a:	c6 00 00             	movb   $0x0,(%eax)
  }
  while(*path == '/')
  10327d:	eb 04                	jmp    103283 <skipelem+0x91>
    path++;
  10327f:	83 45 08 01          	addl   $0x1,0x8(%ebp)
  while(*path == '/')
  103283:	8b 45 08             	mov    0x8(%ebp),%eax
  103286:	0f b6 00             	movzbl (%eax),%eax
  103289:	3c 2f                	cmp    $0x2f,%al
  10328b:	74 f2                	je     10327f <skipelem+0x8d>
  return path;
  10328d:	8b 45 08             	mov    0x8(%ebp),%eax
}
  103290:	c9                   	leave
  103291:	c3                   	ret

00103292 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
  103292:	55                   	push   %ebp
  103293:	89 e5                	mov    %esp,%ebp
  103295:	83 ec 18             	sub    $0x18,%esp
  struct inode *ip, *next;

  ip = iget(ROOTDEV, ROOTINO);
  103298:	83 ec 08             	sub    $0x8,%esp
  10329b:	6a 01                	push   $0x1
  10329d:	6a 01                	push   $0x1
  10329f:	e8 3c f7 ff ff       	call   1029e0 <iget>
  1032a4:	83 c4 10             	add    $0x10,%esp
  1032a7:	89 45 f4             	mov    %eax,-0xc(%ebp)

  while((path = skipelem(path, name)) != 0){
  1032aa:	e9 c0 00 00 00       	jmp    10336f <namex+0xdd>
    iread(ip);
  1032af:	83 ec 0c             	sub    $0xc,%esp
  1032b2:	ff 75 f4             	push   -0xc(%ebp)
  1032b5:	e8 d5 f7 ff ff       	call   102a8f <iread>
  1032ba:	83 c4 10             	add    $0x10,%esp
    if(ip->type != T_DIR){
  1032bd:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1032c0:	0f b7 40 10          	movzwl 0x10(%eax),%eax
  1032c4:	66 83 f8 01          	cmp    $0x1,%ax
  1032c8:	74 28                	je     1032f2 <namex+0x60>
      iput(ip);
  1032ca:	83 ec 0c             	sub    $0xc,%esp
  1032cd:	ff 75 f4             	push   -0xc(%ebp)
  1032d0:	e8 d0 f5 ff ff       	call   1028a5 <iput>
  1032d5:	83 c4 10             	add    $0x10,%esp
      cprintf("wtf1.1");
  1032d8:	83 ec 0c             	sub    $0xc,%esp
  1032db:	68 3f 43 10 00       	push   $0x10433f
  1032e0:	e8 07 ce ff ff       	call   1000ec <cprintf>
  1032e5:	83 c4 10             	add    $0x10,%esp
      return 0;
  1032e8:	b8 00 00 00 00       	mov    $0x0,%eax
  1032ed:	e9 c9 00 00 00       	jmp    1033bb <namex+0x129>
    }
    if(nameiparent && *path == '\0'){
  1032f2:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
  1032f6:	74 22                	je     10331a <namex+0x88>
  1032f8:	8b 45 08             	mov    0x8(%ebp),%eax
  1032fb:	0f b6 00             	movzbl (%eax),%eax
  1032fe:	84 c0                	test   %al,%al
  103300:	75 18                	jne    10331a <namex+0x88>
      // Stop one level early.
      cprintf("wtf1.2");
  103302:	83 ec 0c             	sub    $0xc,%esp
  103305:	68 46 43 10 00       	push   $0x104346
  10330a:	e8 dd cd ff ff       	call   1000ec <cprintf>
  10330f:	83 c4 10             	add    $0x10,%esp

      return ip;
  103312:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103315:	e9 a1 00 00 00       	jmp    1033bb <namex+0x129>
    }
    if((next = dirlookup(ip, name, 0)) == 0){
  10331a:	83 ec 04             	sub    $0x4,%esp
  10331d:	6a 00                	push   $0x0
  10331f:	ff 75 10             	push   0x10(%ebp)
  103322:	ff 75 f4             	push   -0xc(%ebp)
  103325:	e8 36 fd ff ff       	call   103060 <dirlookup>
  10332a:	83 c4 10             	add    $0x10,%esp
  10332d:	89 45 f0             	mov    %eax,-0x10(%ebp)
  103330:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
  103334:	75 25                	jne    10335b <namex+0xc9>
      iput(ip);
  103336:	83 ec 0c             	sub    $0xc,%esp
  103339:	ff 75 f4             	push   -0xc(%ebp)
  10333c:	e8 64 f5 ff ff       	call   1028a5 <iput>
  103341:	83 c4 10             	add    $0x10,%esp
      cprintf("wtf1.3");
  103344:	83 ec 0c             	sub    $0xc,%esp
  103347:	68 4d 43 10 00       	push   $0x10434d
  10334c:	e8 9b cd ff ff       	call   1000ec <cprintf>
  103351:	83 c4 10             	add    $0x10,%esp

      return 0;
  103354:	b8 00 00 00 00       	mov    $0x0,%eax
  103359:	eb 60                	jmp    1033bb <namex+0x129>
    }
    iput(ip);
  10335b:	83 ec 0c             	sub    $0xc,%esp
  10335e:	ff 75 f4             	push   -0xc(%ebp)
  103361:	e8 3f f5 ff ff       	call   1028a5 <iput>
  103366:	83 c4 10             	add    $0x10,%esp
    ip = next;
  103369:	8b 45 f0             	mov    -0x10(%ebp),%eax
  10336c:	89 45 f4             	mov    %eax,-0xc(%ebp)
  while((path = skipelem(path, name)) != 0){
  10336f:	83 ec 08             	sub    $0x8,%esp
  103372:	ff 75 10             	push   0x10(%ebp)
  103375:	ff 75 08             	push   0x8(%ebp)
  103378:	e8 75 fe ff ff       	call   1031f2 <skipelem>
  10337d:	83 c4 10             	add    $0x10,%esp
  103380:	89 45 08             	mov    %eax,0x8(%ebp)
  103383:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
  103387:	0f 85 22 ff ff ff    	jne    1032af <namex+0x1d>
  }
  if(nameiparent){
  10338d:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
  103391:	74 25                	je     1033b8 <namex+0x126>
    iput(ip);
  103393:	83 ec 0c             	sub    $0xc,%esp
  103396:	ff 75 f4             	push   -0xc(%ebp)
  103399:	e8 07 f5 ff ff       	call   1028a5 <iput>
  10339e:	83 c4 10             	add    $0x10,%esp
      cprintf("wtf1.4");
  1033a1:	83 ec 0c             	sub    $0xc,%esp
  1033a4:	68 54 43 10 00       	push   $0x104354
  1033a9:	e8 3e cd ff ff       	call   1000ec <cprintf>
  1033ae:	83 c4 10             	add    $0x10,%esp

    return 0;
  1033b1:	b8 00 00 00 00       	mov    $0x0,%eax
  1033b6:	eb 03                	jmp    1033bb <namex+0x129>
  }
  return ip;
  1033b8:	8b 45 f4             	mov    -0xc(%ebp),%eax
}
  1033bb:	c9                   	leave
  1033bc:	c3                   	ret

001033bd <namei>:

struct inode*
namei(char *path)
{
  1033bd:	55                   	push   %ebp
  1033be:	89 e5                	mov    %esp,%ebp
  1033c0:	83 ec 18             	sub    $0x18,%esp
  char name[DIRSIZ];
  return namex(path, 0, name);
  1033c3:	83 ec 04             	sub    $0x4,%esp
  1033c6:	8d 45 ea             	lea    -0x16(%ebp),%eax
  1033c9:	50                   	push   %eax
  1033ca:	6a 00                	push   $0x0
  1033cc:	ff 75 08             	push   0x8(%ebp)
  1033cf:	e8 be fe ff ff       	call   103292 <namex>
  1033d4:	83 c4 10             	add    $0x10,%esp
}
  1033d7:	c9                   	leave
  1033d8:	c3                   	ret

001033d9 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
  1033d9:	55                   	push   %ebp
  1033da:	89 e5                	mov    %esp,%ebp
  1033dc:	83 ec 08             	sub    $0x8,%esp
  return namex(path, 1, name);
  1033df:	83 ec 04             	sub    $0x4,%esp
  1033e2:	ff 75 0c             	push   0xc(%ebp)
  1033e5:	6a 01                	push   $0x1
  1033e7:	ff 75 08             	push   0x8(%ebp)
  1033ea:	e8 a3 fe ff ff       	call   103292 <namex>
  1033ef:	83 c4 10             	add    $0x10,%esp
}
  1033f2:	c9                   	leave
  1033f3:	c3                   	ret

001033f4 <filealloc>:
} ftable;

// Allocate a file structure.
struct file*
filealloc(void)
{
  1033f4:	55                   	push   %ebp
  1033f5:	89 e5                	mov    %esp,%ebp
  1033f7:	83 ec 10             	sub    $0x10,%esp
  struct file *f;

  for(f = ftable.file; f < ftable.file + NFILE; f++){
  1033fa:	c7 45 fc 40 ae 10 00 	movl   $0x10ae40,-0x4(%ebp)
  103401:	eb 1d                	jmp    103420 <filealloc+0x2c>
    if(f->ref == 0){
  103403:	8b 45 fc             	mov    -0x4(%ebp),%eax
  103406:	8b 40 04             	mov    0x4(%eax),%eax
  103409:	85 c0                	test   %eax,%eax
  10340b:	75 0f                	jne    10341c <filealloc+0x28>
      f->ref = 1;
  10340d:	8b 45 fc             	mov    -0x4(%ebp),%eax
  103410:	c7 40 04 01 00 00 00 	movl   $0x1,0x4(%eax)
      return f;
  103417:	8b 45 fc             	mov    -0x4(%ebp),%eax
  10341a:	eb 13                	jmp    10342f <filealloc+0x3b>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
  10341c:	83 45 fc 14          	addl   $0x14,-0x4(%ebp)
  103420:	b8 10 b6 10 00       	mov    $0x10b610,%eax
  103425:	39 45 fc             	cmp    %eax,-0x4(%ebp)
  103428:	72 d9                	jb     103403 <filealloc+0xf>
    }
  }
  return 0;
  10342a:	b8 00 00 00 00       	mov    $0x0,%eax
}
  10342f:	c9                   	leave
  103430:	c3                   	ret

00103431 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
  103431:	55                   	push   %ebp
  103432:	89 e5                	mov    %esp,%ebp
  103434:	83 ec 08             	sub    $0x8,%esp
  if(f->ref < 1)
  103437:	8b 45 08             	mov    0x8(%ebp),%eax
  10343a:	8b 40 04             	mov    0x4(%eax),%eax
  10343d:	85 c0                	test   %eax,%eax
  10343f:	7f 0d                	jg     10344e <filedup+0x1d>
    panic("filedup");
  103441:	83 ec 0c             	sub    $0xc,%esp
  103444:	68 5b 43 10 00       	push   $0x10435b
  103449:	e8 60 ce ff ff       	call   1002ae <panic>
  f->ref++;
  10344e:	8b 45 08             	mov    0x8(%ebp),%eax
  103451:	8b 40 04             	mov    0x4(%eax),%eax
  103454:	8d 50 01             	lea    0x1(%eax),%edx
  103457:	8b 45 08             	mov    0x8(%ebp),%eax
  10345a:	89 50 04             	mov    %edx,0x4(%eax)
  return f;
  10345d:	8b 45 08             	mov    0x8(%ebp),%eax
}
  103460:	c9                   	leave
  103461:	c3                   	ret

00103462 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
  103462:	55                   	push   %ebp
  103463:	89 e5                	mov    %esp,%ebp
  103465:	83 ec 28             	sub    $0x28,%esp
  struct file ff;

  if(f->ref < 1)
  103468:	8b 45 08             	mov    0x8(%ebp),%eax
  10346b:	8b 40 04             	mov    0x4(%eax),%eax
  10346e:	85 c0                	test   %eax,%eax
  103470:	7f 0d                	jg     10347f <fileclose+0x1d>
    panic("fileclose");
  103472:	83 ec 0c             	sub    $0xc,%esp
  103475:	68 63 43 10 00       	push   $0x104363
  10347a:	e8 2f ce ff ff       	call   1002ae <panic>
  if(--f->ref > 0){
  10347f:	8b 45 08             	mov    0x8(%ebp),%eax
  103482:	8b 40 04             	mov    0x4(%eax),%eax
  103485:	8d 50 ff             	lea    -0x1(%eax),%edx
  103488:	8b 45 08             	mov    0x8(%ebp),%eax
  10348b:	89 50 04             	mov    %edx,0x4(%eax)
  10348e:	8b 45 08             	mov    0x8(%ebp),%eax
  103491:	8b 40 04             	mov    0x4(%eax),%eax
  103494:	85 c0                	test   %eax,%eax
  103496:	7f 56                	jg     1034ee <fileclose+0x8c>
    return;
  }
  ff = *f;
  103498:	8b 45 08             	mov    0x8(%ebp),%eax
  10349b:	8b 10                	mov    (%eax),%edx
  10349d:	89 55 e4             	mov    %edx,-0x1c(%ebp)
  1034a0:	8b 50 04             	mov    0x4(%eax),%edx
  1034a3:	89 55 e8             	mov    %edx,-0x18(%ebp)
  1034a6:	8b 50 08             	mov    0x8(%eax),%edx
  1034a9:	89 55 ec             	mov    %edx,-0x14(%ebp)
  1034ac:	8b 50 0c             	mov    0xc(%eax),%edx
  1034af:	89 55 f0             	mov    %edx,-0x10(%ebp)
  1034b2:	8b 40 10             	mov    0x10(%eax),%eax
  1034b5:	89 45 f4             	mov    %eax,-0xc(%ebp)
  f->ref = 0;
  1034b8:	8b 45 08             	mov    0x8(%ebp),%eax
  1034bb:	c7 40 04 00 00 00 00 	movl   $0x0,0x4(%eax)
  f->type = FD_NONE;
  1034c2:	8b 45 08             	mov    0x8(%ebp),%eax
  1034c5:	c7 00 00 00 00 00    	movl   $0x0,(%eax)

  if(ff.type == FD_INODE){
  1034cb:	8b 45 e4             	mov    -0x1c(%ebp),%eax
  1034ce:	83 f8 01             	cmp    $0x1,%eax
  1034d1:	75 1c                	jne    1034ef <fileclose+0x8d>
    begin_op();
  1034d3:	e8 9c 09 00 00       	call   103e74 <begin_op>
    iput(ff.ip);
  1034d8:	8b 45 f0             	mov    -0x10(%ebp),%eax
  1034db:	83 ec 0c             	sub    $0xc,%esp
  1034de:	50                   	push   %eax
  1034df:	e8 c1 f3 ff ff       	call   1028a5 <iput>
  1034e4:	83 c4 10             	add    $0x10,%esp
    end_op();
  1034e7:	e8 8e 09 00 00       	call   103e7a <end_op>
  1034ec:	eb 01                	jmp    1034ef <fileclose+0x8d>
    return;
  1034ee:	90                   	nop
  }
}
  1034ef:	c9                   	leave
  1034f0:	c3                   	ret

001034f1 <filestat>:

// Get metadata about file f.
int
filestat(struct file *f, struct stat *st)
{
  1034f1:	55                   	push   %ebp
  1034f2:	89 e5                	mov    %esp,%ebp
  1034f4:	83 ec 08             	sub    $0x8,%esp
  if(f->type == FD_INODE){
  1034f7:	8b 45 08             	mov    0x8(%ebp),%eax
  1034fa:	8b 00                	mov    (%eax),%eax
  1034fc:	83 f8 01             	cmp    $0x1,%eax
  1034ff:	75 2e                	jne    10352f <filestat+0x3e>
    iread(f->ip);
  103501:	8b 45 08             	mov    0x8(%ebp),%eax
  103504:	8b 40 0c             	mov    0xc(%eax),%eax
  103507:	83 ec 0c             	sub    $0xc,%esp
  10350a:	50                   	push   %eax
  10350b:	e8 7f f5 ff ff       	call   102a8f <iread>
  103510:	83 c4 10             	add    $0x10,%esp
    stati(f->ip, st);
  103513:	8b 45 08             	mov    0x8(%ebp),%eax
  103516:	8b 40 0c             	mov    0xc(%eax),%eax
  103519:	83 ec 08             	sub    $0x8,%esp
  10351c:	ff 75 0c             	push   0xc(%ebp)
  10351f:	50                   	push   %eax
  103520:	e8 b7 f8 ff ff       	call   102ddc <stati>
  103525:	83 c4 10             	add    $0x10,%esp
    return 0;
  103528:	b8 00 00 00 00       	mov    $0x0,%eax
  10352d:	eb 05                	jmp    103534 <filestat+0x43>
  }
  return -1;
  10352f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
  103534:	c9                   	leave
  103535:	c3                   	ret

00103536 <fileread>:

// Read from file f.
int
fileread(struct file *f, char *addr, int n)
{
  103536:	55                   	push   %ebp
  103537:	89 e5                	mov    %esp,%ebp
  103539:	83 ec 18             	sub    $0x18,%esp
  int r;

  if(f->readable == 0)
  10353c:	8b 45 08             	mov    0x8(%ebp),%eax
  10353f:	0f b6 40 08          	movzbl 0x8(%eax),%eax
  103543:	84 c0                	test   %al,%al
  103545:	75 07                	jne    10354e <fileread+0x18>
    return -1;
  103547:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  10354c:	eb 65                	jmp    1035b3 <fileread+0x7d>
  if(f->type == FD_INODE){
  10354e:	8b 45 08             	mov    0x8(%ebp),%eax
  103551:	8b 00                	mov    (%eax),%eax
  103553:	83 f8 01             	cmp    $0x1,%eax
  103556:	75 4e                	jne    1035a6 <fileread+0x70>
    iread(f->ip);
  103558:	8b 45 08             	mov    0x8(%ebp),%eax
  10355b:	8b 40 0c             	mov    0xc(%eax),%eax
  10355e:	83 ec 0c             	sub    $0xc,%esp
  103561:	50                   	push   %eax
  103562:	e8 28 f5 ff ff       	call   102a8f <iread>
  103567:	83 c4 10             	add    $0x10,%esp
    if((r = readi(f->ip, addr, f->off, n)) > 0)
  10356a:	8b 4d 10             	mov    0x10(%ebp),%ecx
  10356d:	8b 45 08             	mov    0x8(%ebp),%eax
  103570:	8b 50 10             	mov    0x10(%eax),%edx
  103573:	8b 45 08             	mov    0x8(%ebp),%eax
  103576:	8b 40 0c             	mov    0xc(%eax),%eax
  103579:	51                   	push   %ecx
  10357a:	52                   	push   %edx
  10357b:	ff 75 0c             	push   0xc(%ebp)
  10357e:	50                   	push   %eax
  10357f:	e8 9e f8 ff ff       	call   102e22 <readi>
  103584:	83 c4 10             	add    $0x10,%esp
  103587:	89 45 f4             	mov    %eax,-0xc(%ebp)
  10358a:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
  10358e:	7e 11                	jle    1035a1 <fileread+0x6b>
      f->off += r;
  103590:	8b 45 08             	mov    0x8(%ebp),%eax
  103593:	8b 50 10             	mov    0x10(%eax),%edx
  103596:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103599:	01 c2                	add    %eax,%edx
  10359b:	8b 45 08             	mov    0x8(%ebp),%eax
  10359e:	89 50 10             	mov    %edx,0x10(%eax)
    return r;
  1035a1:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1035a4:	eb 0d                	jmp    1035b3 <fileread+0x7d>
  }
  panic("fileread");
  1035a6:	83 ec 0c             	sub    $0xc,%esp
  1035a9:	68 6d 43 10 00       	push   $0x10436d
  1035ae:	e8 fb cc ff ff       	call   1002ae <panic>
}
  1035b3:	c9                   	leave
  1035b4:	c3                   	ret

001035b5 <filewrite>:

// Write to file f.
int
filewrite(struct file *f, char *addr, int n)
{
  1035b5:	55                   	push   %ebp
  1035b6:	89 e5                	mov    %esp,%ebp
  1035b8:	53                   	push   %ebx
  1035b9:	83 ec 14             	sub    $0x14,%esp
  int r;

  if(f->writable == 0)
  1035bc:	8b 45 08             	mov    0x8(%ebp),%eax
  1035bf:	0f b6 40 09          	movzbl 0x9(%eax),%eax
  1035c3:	84 c0                	test   %al,%al
  1035c5:	75 0a                	jne    1035d1 <filewrite+0x1c>
    return -1;
  1035c7:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  1035cc:	e9 e2 00 00 00       	jmp    1036b3 <filewrite+0xfe>
  if(f->type == FD_INODE){
  1035d1:	8b 45 08             	mov    0x8(%ebp),%eax
  1035d4:	8b 00                	mov    (%eax),%eax
  1035d6:	83 f8 01             	cmp    $0x1,%eax
  1035d9:	0f 85 c7 00 00 00    	jne    1036a6 <filewrite+0xf1>
    // write a few blocks at a time
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * 512;
  1035df:	c7 45 ec 00 06 00 00 	movl   $0x600,-0x14(%ebp)
    int i = 0;
  1035e6:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
    while(i < n){
  1035ed:	e9 91 00 00 00       	jmp    103683 <filewrite+0xce>
      int n1 = n - i;
  1035f2:	8b 45 10             	mov    0x10(%ebp),%eax
  1035f5:	2b 45 f4             	sub    -0xc(%ebp),%eax
  1035f8:	89 45 f0             	mov    %eax,-0x10(%ebp)
      if(n1 > max)
  1035fb:	8b 45 f0             	mov    -0x10(%ebp),%eax
  1035fe:	3b 45 ec             	cmp    -0x14(%ebp),%eax
  103601:	7e 06                	jle    103609 <filewrite+0x54>
        n1 = max;
  103603:	8b 45 ec             	mov    -0x14(%ebp),%eax
  103606:	89 45 f0             	mov    %eax,-0x10(%ebp)

			begin_op();
  103609:	e8 66 08 00 00       	call   103e74 <begin_op>
      iread(f->ip);
  10360e:	8b 45 08             	mov    0x8(%ebp),%eax
  103611:	8b 40 0c             	mov    0xc(%eax),%eax
  103614:	83 ec 0c             	sub    $0xc,%esp
  103617:	50                   	push   %eax
  103618:	e8 72 f4 ff ff       	call   102a8f <iread>
  10361d:	83 c4 10             	add    $0x10,%esp
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
  103620:	8b 4d f0             	mov    -0x10(%ebp),%ecx
  103623:	8b 45 08             	mov    0x8(%ebp),%eax
  103626:	8b 50 10             	mov    0x10(%eax),%edx
  103629:	8b 5d f4             	mov    -0xc(%ebp),%ebx
  10362c:	8b 45 0c             	mov    0xc(%ebp),%eax
  10362f:	01 c3                	add    %eax,%ebx
  103631:	8b 45 08             	mov    0x8(%ebp),%eax
  103634:	8b 40 0c             	mov    0xc(%eax),%eax
  103637:	51                   	push   %ecx
  103638:	52                   	push   %edx
  103639:	53                   	push   %ebx
  10363a:	50                   	push   %eax
  10363b:	e8 da f8 ff ff       	call   102f1a <writei>
  103640:	83 c4 10             	add    $0x10,%esp
  103643:	89 45 e8             	mov    %eax,-0x18(%ebp)
  103646:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
  10364a:	7e 11                	jle    10365d <filewrite+0xa8>
        f->off += r;
  10364c:	8b 45 08             	mov    0x8(%ebp),%eax
  10364f:	8b 50 10             	mov    0x10(%eax),%edx
  103652:	8b 45 e8             	mov    -0x18(%ebp),%eax
  103655:	01 c2                	add    %eax,%edx
  103657:	8b 45 08             	mov    0x8(%ebp),%eax
  10365a:	89 50 10             	mov    %edx,0x10(%eax)
      end_op();
  10365d:	e8 18 08 00 00       	call   103e7a <end_op>

      if(r < 0)
  103662:	83 7d e8 00          	cmpl   $0x0,-0x18(%ebp)
  103666:	78 29                	js     103691 <filewrite+0xdc>
        break;
      if(r != n1)
  103668:	8b 45 e8             	mov    -0x18(%ebp),%eax
  10366b:	3b 45 f0             	cmp    -0x10(%ebp),%eax
  10366e:	74 0d                	je     10367d <filewrite+0xc8>
        panic("short filewrite");
  103670:	83 ec 0c             	sub    $0xc,%esp
  103673:	68 76 43 10 00       	push   $0x104376
  103678:	e8 31 cc ff ff       	call   1002ae <panic>
      i += r;
  10367d:	8b 45 e8             	mov    -0x18(%ebp),%eax
  103680:	01 45 f4             	add    %eax,-0xc(%ebp)
    while(i < n){
  103683:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103686:	3b 45 10             	cmp    0x10(%ebp),%eax
  103689:	0f 8c 63 ff ff ff    	jl     1035f2 <filewrite+0x3d>
  10368f:	eb 01                	jmp    103692 <filewrite+0xdd>
        break;
  103691:	90                   	nop
    }
    return i == n ? n : -1;
  103692:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103695:	3b 45 10             	cmp    0x10(%ebp),%eax
  103698:	75 05                	jne    10369f <filewrite+0xea>
  10369a:	8b 45 10             	mov    0x10(%ebp),%eax
  10369d:	eb 14                	jmp    1036b3 <filewrite+0xfe>
  10369f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  1036a4:	eb 0d                	jmp    1036b3 <filewrite+0xfe>
  }
  panic("filewrite");
  1036a6:	83 ec 0c             	sub    $0xc,%esp
  1036a9:	68 86 43 10 00       	push   $0x104386
  1036ae:	e8 fb cb ff ff       	call   1002ae <panic>
}
  1036b3:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  1036b6:	c9                   	leave
  1036b7:	c3                   	ret

001036b8 <isdirempty>:

// Is the directory dp empty except for "." and ".." ?
int
isdirempty(struct inode *dp)
{
  1036b8:	55                   	push   %ebp
  1036b9:	89 e5                	mov    %esp,%ebp
  1036bb:	83 ec 28             	sub    $0x28,%esp
  int off;
  struct dirent de;

  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
  1036be:	c7 45 f4 20 00 00 00 	movl   $0x20,-0xc(%ebp)
  1036c5:	eb 40                	jmp    103707 <isdirempty+0x4f>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
  1036c7:	8b 45 f4             	mov    -0xc(%ebp),%eax
  1036ca:	6a 10                	push   $0x10
  1036cc:	50                   	push   %eax
  1036cd:	8d 45 e4             	lea    -0x1c(%ebp),%eax
  1036d0:	50                   	push   %eax
  1036d1:	ff 75 08             	push   0x8(%ebp)
  1036d4:	e8 49 f7 ff ff       	call   102e22 <readi>
  1036d9:	83 c4 10             	add    $0x10,%esp
  1036dc:	83 f8 10             	cmp    $0x10,%eax
  1036df:	74 0d                	je     1036ee <isdirempty+0x36>
      panic("isdirempty: readi");
  1036e1:	83 ec 0c             	sub    $0xc,%esp
  1036e4:	68 90 43 10 00       	push   $0x104390
  1036e9:	e8 c0 cb ff ff       	call   1002ae <panic>
    if(de.inum != 0)
  1036ee:	0f b7 45 e4          	movzwl -0x1c(%ebp),%eax
  1036f2:	66 85 c0             	test   %ax,%ax
  1036f5:	74 07                	je     1036fe <isdirempty+0x46>
      return 0;
  1036f7:	b8 00 00 00 00       	mov    $0x0,%eax
  1036fc:	eb 1b                	jmp    103719 <isdirempty+0x61>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
  1036fe:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103701:	83 c0 10             	add    $0x10,%eax
  103704:	89 45 f4             	mov    %eax,-0xc(%ebp)
  103707:	8b 45 08             	mov    0x8(%ebp),%eax
  10370a:	8b 40 18             	mov    0x18(%eax),%eax
  10370d:	8b 55 f4             	mov    -0xc(%ebp),%edx
  103710:	39 c2                	cmp    %eax,%edx
  103712:	72 b3                	jb     1036c7 <isdirempty+0xf>
  }
  return 1;
  103714:	b8 01 00 00 00       	mov    $0x1,%eax
}
  103719:	c9                   	leave
  10371a:	c3                   	ret

0010371b <unlink>:

int
unlink(char* path, char* name)
{
  10371b:	55                   	push   %ebp
  10371c:	89 e5                	mov    %esp,%ebp
  10371e:	83 ec 28             	sub    $0x28,%esp
  struct inode *ip, *dp;
  struct dirent de;
  uint off;

	begin_op();
  103721:	e8 4e 07 00 00       	call   103e74 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
  103726:	83 ec 08             	sub    $0x8,%esp
  103729:	ff 75 0c             	push   0xc(%ebp)
  10372c:	ff 75 08             	push   0x8(%ebp)
  10372f:	e8 a5 fc ff ff       	call   1033d9 <nameiparent>
  103734:	83 c4 10             	add    $0x10,%esp
  103737:	89 45 f4             	mov    %eax,-0xc(%ebp)
  10373a:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
  10373e:	75 0f                	jne    10374f <unlink+0x34>
    end_op();
  103740:	e8 35 07 00 00       	call   103e7a <end_op>
    return -1;
  103745:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  10374a:	e9 8c 01 00 00       	jmp    1038db <unlink+0x1c0>
  }

  iread(dp);
  10374f:	83 ec 0c             	sub    $0xc,%esp
  103752:	ff 75 f4             	push   -0xc(%ebp)
  103755:	e8 35 f3 ff ff       	call   102a8f <iread>
  10375a:	83 c4 10             	add    $0x10,%esp

  // Cannot unlink "." or "..".
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
  10375d:	83 ec 08             	sub    $0x8,%esp
  103760:	68 a2 43 10 00       	push   $0x1043a2
  103765:	ff 75 0c             	push   0xc(%ebp)
  103768:	e8 d8 f8 ff ff       	call   103045 <namecmp>
  10376d:	83 c4 10             	add    $0x10,%esp
  103770:	85 c0                	test   %eax,%eax
  103772:	0f 84 47 01 00 00    	je     1038bf <unlink+0x1a4>
  103778:	83 ec 08             	sub    $0x8,%esp
  10377b:	68 a4 43 10 00       	push   $0x1043a4
  103780:	ff 75 0c             	push   0xc(%ebp)
  103783:	e8 bd f8 ff ff       	call   103045 <namecmp>
  103788:	83 c4 10             	add    $0x10,%esp
  10378b:	85 c0                	test   %eax,%eax
  10378d:	0f 84 2c 01 00 00    	je     1038bf <unlink+0x1a4>
    goto bad;

  if((ip = dirlookup(dp, name, &off)) == 0)
  103793:	83 ec 04             	sub    $0x4,%esp
  103796:	8d 45 dc             	lea    -0x24(%ebp),%eax
  103799:	50                   	push   %eax
  10379a:	ff 75 0c             	push   0xc(%ebp)
  10379d:	ff 75 f4             	push   -0xc(%ebp)
  1037a0:	e8 bb f8 ff ff       	call   103060 <dirlookup>
  1037a5:	83 c4 10             	add    $0x10,%esp
  1037a8:	89 45 f0             	mov    %eax,-0x10(%ebp)
  1037ab:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
  1037af:	0f 84 0d 01 00 00    	je     1038c2 <unlink+0x1a7>
    goto bad;
  iread(ip);
  1037b5:	83 ec 0c             	sub    $0xc,%esp
  1037b8:	ff 75 f0             	push   -0x10(%ebp)
  1037bb:	e8 cf f2 ff ff       	call   102a8f <iread>
  1037c0:	83 c4 10             	add    $0x10,%esp

  if(ip->nlink < 1)
  1037c3:	8b 45 f0             	mov    -0x10(%ebp),%eax
  1037c6:	0f b7 40 16          	movzwl 0x16(%eax),%eax
  1037ca:	66 85 c0             	test   %ax,%ax
  1037cd:	7f 0d                	jg     1037dc <unlink+0xc1>
    panic("unlink: nlink < 1");
  1037cf:	83 ec 0c             	sub    $0xc,%esp
  1037d2:	68 a7 43 10 00       	push   $0x1043a7
  1037d7:	e8 d2 ca ff ff       	call   1002ae <panic>
  if(ip->type == T_DIR && !isdirempty(ip)){
  1037dc:	8b 45 f0             	mov    -0x10(%ebp),%eax
  1037df:	0f b7 40 10          	movzwl 0x10(%eax),%eax
  1037e3:	66 83 f8 01          	cmp    $0x1,%ax
  1037e7:	75 25                	jne    10380e <unlink+0xf3>
  1037e9:	83 ec 0c             	sub    $0xc,%esp
  1037ec:	ff 75 f0             	push   -0x10(%ebp)
  1037ef:	e8 c4 fe ff ff       	call   1036b8 <isdirempty>
  1037f4:	83 c4 10             	add    $0x10,%esp
  1037f7:	85 c0                	test   %eax,%eax
  1037f9:	75 13                	jne    10380e <unlink+0xf3>
    iput(ip);
  1037fb:	83 ec 0c             	sub    $0xc,%esp
  1037fe:	ff 75 f0             	push   -0x10(%ebp)
  103801:	e8 9f f0 ff ff       	call   1028a5 <iput>
  103806:	83 c4 10             	add    $0x10,%esp
    goto bad;
  103809:	e9 b5 00 00 00       	jmp    1038c3 <unlink+0x1a8>
  }

  memset(&de, 0, sizeof(de));
  10380e:	83 ec 04             	sub    $0x4,%esp
  103811:	6a 10                	push   $0x10
  103813:	6a 00                	push   $0x0
  103815:	8d 45 e0             	lea    -0x20(%ebp),%eax
  103818:	50                   	push   %eax
  103819:	e8 68 d6 ff ff       	call   100e86 <memset>
  10381e:	83 c4 10             	add    $0x10,%esp
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
  103821:	8b 45 dc             	mov    -0x24(%ebp),%eax
  103824:	6a 10                	push   $0x10
  103826:	50                   	push   %eax
  103827:	8d 45 e0             	lea    -0x20(%ebp),%eax
  10382a:	50                   	push   %eax
  10382b:	ff 75 f4             	push   -0xc(%ebp)
  10382e:	e8 e7 f6 ff ff       	call   102f1a <writei>
  103833:	83 c4 10             	add    $0x10,%esp
  103836:	83 f8 10             	cmp    $0x10,%eax
  103839:	74 0d                	je     103848 <unlink+0x12d>
    panic("unlink: writei");
  10383b:	83 ec 0c             	sub    $0xc,%esp
  10383e:	68 b9 43 10 00       	push   $0x1043b9
  103843:	e8 66 ca ff ff       	call   1002ae <panic>
  if(ip->type == T_DIR){
  103848:	8b 45 f0             	mov    -0x10(%ebp),%eax
  10384b:	0f b7 40 10          	movzwl 0x10(%eax),%eax
  10384f:	66 83 f8 01          	cmp    $0x1,%ax
  103853:	75 21                	jne    103876 <unlink+0x15b>
    dp->nlink--;
  103855:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103858:	0f b7 40 16          	movzwl 0x16(%eax),%eax
  10385c:	83 e8 01             	sub    $0x1,%eax
  10385f:	89 c2                	mov    %eax,%edx
  103861:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103864:	66 89 50 16          	mov    %dx,0x16(%eax)
    iupdate(dp);
  103868:	83 ec 0c             	sub    $0xc,%esp
  10386b:	ff 75 f4             	push   -0xc(%ebp)
  10386e:	e8 9e f0 ff ff       	call   102911 <iupdate>
  103873:	83 c4 10             	add    $0x10,%esp
  }
  iput(dp);
  103876:	83 ec 0c             	sub    $0xc,%esp
  103879:	ff 75 f4             	push   -0xc(%ebp)
  10387c:	e8 24 f0 ff ff       	call   1028a5 <iput>
  103881:	83 c4 10             	add    $0x10,%esp

  ip->nlink--;
  103884:	8b 45 f0             	mov    -0x10(%ebp),%eax
  103887:	0f b7 40 16          	movzwl 0x16(%eax),%eax
  10388b:	83 e8 01             	sub    $0x1,%eax
  10388e:	89 c2                	mov    %eax,%edx
  103890:	8b 45 f0             	mov    -0x10(%ebp),%eax
  103893:	66 89 50 16          	mov    %dx,0x16(%eax)
  iupdate(ip);
  103897:	83 ec 0c             	sub    $0xc,%esp
  10389a:	ff 75 f0             	push   -0x10(%ebp)
  10389d:	e8 6f f0 ff ff       	call   102911 <iupdate>
  1038a2:	83 c4 10             	add    $0x10,%esp
  iput(ip);
  1038a5:	83 ec 0c             	sub    $0xc,%esp
  1038a8:	ff 75 f0             	push   -0x10(%ebp)
  1038ab:	e8 f5 ef ff ff       	call   1028a5 <iput>
  1038b0:	83 c4 10             	add    $0x10,%esp

  end_op();
  1038b3:	e8 c2 05 00 00       	call   103e7a <end_op>
  return 0;
  1038b8:	b8 00 00 00 00       	mov    $0x0,%eax
  1038bd:	eb 1c                	jmp    1038db <unlink+0x1c0>
    goto bad;
  1038bf:	90                   	nop
  1038c0:	eb 01                	jmp    1038c3 <unlink+0x1a8>
    goto bad;
  1038c2:	90                   	nop

bad:
  iput(dp);
  1038c3:	83 ec 0c             	sub    $0xc,%esp
  1038c6:	ff 75 f4             	push   -0xc(%ebp)
  1038c9:	e8 d7 ef ff ff       	call   1028a5 <iput>
  1038ce:	83 c4 10             	add    $0x10,%esp
  end_op();
  1038d1:	e8 a4 05 00 00       	call   103e7a <end_op>
  return -1;
  1038d6:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
  1038db:	c9                   	leave
  1038dc:	c3                   	ret

001038dd <create>:

static struct inode*
create(char *path, short type, short major, short minor)
{
  1038dd:	55                   	push   %ebp
  1038de:	89 e5                	mov    %esp,%ebp
  1038e0:	83 ec 38             	sub    $0x38,%esp
  1038e3:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  1038e6:	8b 55 10             	mov    0x10(%ebp),%edx
  1038e9:	8b 45 14             	mov    0x14(%ebp),%eax
  1038ec:	66 89 4d d4          	mov    %cx,-0x2c(%ebp)
  1038f0:	66 89 55 d0          	mov    %dx,-0x30(%ebp)
  1038f4:	66 89 45 cc          	mov    %ax,-0x34(%ebp)
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
  1038f8:	83 ec 08             	sub    $0x8,%esp
  1038fb:	8d 45 e2             	lea    -0x1e(%ebp),%eax
  1038fe:	50                   	push   %eax
  1038ff:	ff 75 08             	push   0x8(%ebp)
  103902:	e8 d2 fa ff ff       	call   1033d9 <nameiparent>
  103907:	83 c4 10             	add    $0x10,%esp
  10390a:	89 45 f4             	mov    %eax,-0xc(%ebp)
  10390d:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
  103911:	75 0a                	jne    10391d <create+0x40>
    return 0;
  103913:	b8 00 00 00 00       	mov    $0x0,%eax
  103918:	e9 8e 01 00 00       	jmp    103aab <create+0x1ce>
  iread(dp);
  10391d:	83 ec 0c             	sub    $0xc,%esp
  103920:	ff 75 f4             	push   -0xc(%ebp)
  103923:	e8 67 f1 ff ff       	call   102a8f <iread>
  103928:	83 c4 10             	add    $0x10,%esp

  if((ip = dirlookup(dp, name, 0)) != 0){
  10392b:	83 ec 04             	sub    $0x4,%esp
  10392e:	6a 00                	push   $0x0
  103930:	8d 45 e2             	lea    -0x1e(%ebp),%eax
  103933:	50                   	push   %eax
  103934:	ff 75 f4             	push   -0xc(%ebp)
  103937:	e8 24 f7 ff ff       	call   103060 <dirlookup>
  10393c:	83 c4 10             	add    $0x10,%esp
  10393f:	89 45 f0             	mov    %eax,-0x10(%ebp)
  103942:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
  103946:	74 50                	je     103998 <create+0xbb>
    iput(dp);
  103948:	83 ec 0c             	sub    $0xc,%esp
  10394b:	ff 75 f4             	push   -0xc(%ebp)
  10394e:	e8 52 ef ff ff       	call   1028a5 <iput>
  103953:	83 c4 10             	add    $0x10,%esp
    iread(ip);
  103956:	83 ec 0c             	sub    $0xc,%esp
  103959:	ff 75 f0             	push   -0x10(%ebp)
  10395c:	e8 2e f1 ff ff       	call   102a8f <iread>
  103961:	83 c4 10             	add    $0x10,%esp
    if(type == T_FILE && ip->type == T_FILE)
  103964:	66 83 7d d4 02       	cmpw   $0x2,-0x2c(%ebp)
  103969:	75 15                	jne    103980 <create+0xa3>
  10396b:	8b 45 f0             	mov    -0x10(%ebp),%eax
  10396e:	0f b7 40 10          	movzwl 0x10(%eax),%eax
  103972:	66 83 f8 02          	cmp    $0x2,%ax
  103976:	75 08                	jne    103980 <create+0xa3>
      return ip;
  103978:	8b 45 f0             	mov    -0x10(%ebp),%eax
  10397b:	e9 2b 01 00 00       	jmp    103aab <create+0x1ce>
    iput(ip);
  103980:	83 ec 0c             	sub    $0xc,%esp
  103983:	ff 75 f0             	push   -0x10(%ebp)
  103986:	e8 1a ef ff ff       	call   1028a5 <iput>
  10398b:	83 c4 10             	add    $0x10,%esp
    return 0;
  10398e:	b8 00 00 00 00       	mov    $0x0,%eax
  103993:	e9 13 01 00 00       	jmp    103aab <create+0x1ce>
  }

  if((ip = ialloc(dp->dev, type)) == 0)
  103998:	0f bf 55 d4          	movswl -0x2c(%ebp),%edx
  10399c:	8b 45 f4             	mov    -0xc(%ebp),%eax
  10399f:	8b 00                	mov    (%eax),%eax
  1039a1:	83 ec 08             	sub    $0x8,%esp
  1039a4:	52                   	push   %edx
  1039a5:	50                   	push   %eax
  1039a6:	e8 16 ee ff ff       	call   1027c1 <ialloc>
  1039ab:	83 c4 10             	add    $0x10,%esp
  1039ae:	89 45 f0             	mov    %eax,-0x10(%ebp)
  1039b1:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
  1039b5:	75 0d                	jne    1039c4 <create+0xe7>
    panic("create: ialloc");
  1039b7:	83 ec 0c             	sub    $0xc,%esp
  1039ba:	68 c8 43 10 00       	push   $0x1043c8
  1039bf:	e8 ea c8 ff ff       	call   1002ae <panic>

  iread(ip);
  1039c4:	83 ec 0c             	sub    $0xc,%esp
  1039c7:	ff 75 f0             	push   -0x10(%ebp)
  1039ca:	e8 c0 f0 ff ff       	call   102a8f <iread>
  1039cf:	83 c4 10             	add    $0x10,%esp
  ip->major = major;
  1039d2:	8b 45 f0             	mov    -0x10(%ebp),%eax
  1039d5:	0f b7 55 d0          	movzwl -0x30(%ebp),%edx
  1039d9:	66 89 50 12          	mov    %dx,0x12(%eax)
  ip->minor = minor;
  1039dd:	8b 45 f0             	mov    -0x10(%ebp),%eax
  1039e0:	0f b7 55 cc          	movzwl -0x34(%ebp),%edx
  1039e4:	66 89 50 14          	mov    %dx,0x14(%eax)
  ip->nlink = 1;
  1039e8:	8b 45 f0             	mov    -0x10(%ebp),%eax
  1039eb:	66 c7 40 16 01 00    	movw   $0x1,0x16(%eax)
  iupdate(ip);
  1039f1:	83 ec 0c             	sub    $0xc,%esp
  1039f4:	ff 75 f0             	push   -0x10(%ebp)
  1039f7:	e8 15 ef ff ff       	call   102911 <iupdate>
  1039fc:	83 c4 10             	add    $0x10,%esp

  if(type == T_DIR){  // Create . and .. entries.
  1039ff:	66 83 7d d4 01       	cmpw   $0x1,-0x2c(%ebp)
  103a04:	75 6a                	jne    103a70 <create+0x193>
    dp->nlink++;  // for ".."
  103a06:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103a09:	0f b7 40 16          	movzwl 0x16(%eax),%eax
  103a0d:	83 c0 01             	add    $0x1,%eax
  103a10:	89 c2                	mov    %eax,%edx
  103a12:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103a15:	66 89 50 16          	mov    %dx,0x16(%eax)
    iupdate(dp);
  103a19:	83 ec 0c             	sub    $0xc,%esp
  103a1c:	ff 75 f4             	push   -0xc(%ebp)
  103a1f:	e8 ed ee ff ff       	call   102911 <iupdate>
  103a24:	83 c4 10             	add    $0x10,%esp
    // No ip->nlink++ for ".": avoid cyclic ref count.
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
  103a27:	8b 45 f0             	mov    -0x10(%ebp),%eax
  103a2a:	8b 40 04             	mov    0x4(%eax),%eax
  103a2d:	83 ec 04             	sub    $0x4,%esp
  103a30:	50                   	push   %eax
  103a31:	68 a2 43 10 00       	push   $0x1043a2
  103a36:	ff 75 f0             	push   -0x10(%ebp)
  103a39:	e8 dc f6 ff ff       	call   10311a <dirlink>
  103a3e:	83 c4 10             	add    $0x10,%esp
  103a41:	85 c0                	test   %eax,%eax
  103a43:	78 1e                	js     103a63 <create+0x186>
  103a45:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103a48:	8b 40 04             	mov    0x4(%eax),%eax
  103a4b:	83 ec 04             	sub    $0x4,%esp
  103a4e:	50                   	push   %eax
  103a4f:	68 a4 43 10 00       	push   $0x1043a4
  103a54:	ff 75 f0             	push   -0x10(%ebp)
  103a57:	e8 be f6 ff ff       	call   10311a <dirlink>
  103a5c:	83 c4 10             	add    $0x10,%esp
  103a5f:	85 c0                	test   %eax,%eax
  103a61:	79 0d                	jns    103a70 <create+0x193>
      panic("create dots");
  103a63:	83 ec 0c             	sub    $0xc,%esp
  103a66:	68 d7 43 10 00       	push   $0x1043d7
  103a6b:	e8 3e c8 ff ff       	call   1002ae <panic>
  }

  if(dirlink(dp, name, ip->inum) < 0)
  103a70:	8b 45 f0             	mov    -0x10(%ebp),%eax
  103a73:	8b 40 04             	mov    0x4(%eax),%eax
  103a76:	83 ec 04             	sub    $0x4,%esp
  103a79:	50                   	push   %eax
  103a7a:	8d 45 e2             	lea    -0x1e(%ebp),%eax
  103a7d:	50                   	push   %eax
  103a7e:	ff 75 f4             	push   -0xc(%ebp)
  103a81:	e8 94 f6 ff ff       	call   10311a <dirlink>
  103a86:	83 c4 10             	add    $0x10,%esp
  103a89:	85 c0                	test   %eax,%eax
  103a8b:	79 0d                	jns    103a9a <create+0x1bd>
    panic("create: dirlink");
  103a8d:	83 ec 0c             	sub    $0xc,%esp
  103a90:	68 e3 43 10 00       	push   $0x1043e3
  103a95:	e8 14 c8 ff ff       	call   1002ae <panic>

  iput(dp);
  103a9a:	83 ec 0c             	sub    $0xc,%esp
  103a9d:	ff 75 f4             	push   -0xc(%ebp)
  103aa0:	e8 00 ee ff ff       	call   1028a5 <iput>
  103aa5:	83 c4 10             	add    $0x10,%esp

  return ip;
  103aa8:	8b 45 f0             	mov    -0x10(%ebp),%eax
}
  103aab:	c9                   	leave
  103aac:	c3                   	ret

00103aad <open>:


struct file*
open(char* path, int omode)
{
  103aad:	55                   	push   %ebp
  103aae:	89 e5                	mov    %esp,%ebp
  103ab0:	83 ec 18             	sub    $0x18,%esp
  struct inode *ip;

  begin_op();
  103ab3:	e8 bc 03 00 00       	call   103e74 <begin_op>

  if(omode & O_CREATE){
  103ab8:	8b 45 0c             	mov    0xc(%ebp),%eax
  103abb:	25 00 02 00 00       	and    $0x200,%eax
  103ac0:	85 c0                	test   %eax,%eax
  103ac2:	74 3d                	je     103b01 <open+0x54>
    ip = create(path, T_FILE, 0, 0);
  103ac4:	6a 00                	push   $0x0
  103ac6:	6a 00                	push   $0x0
  103ac8:	6a 02                	push   $0x2
  103aca:	ff 75 08             	push   0x8(%ebp)
  103acd:	e8 0b fe ff ff       	call   1038dd <create>
  103ad2:	83 c4 10             	add    $0x10,%esp
  103ad5:	89 45 f4             	mov    %eax,-0xc(%ebp)
    if(ip == 0){
  103ad8:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
  103adc:	0f 85 a3 00 00 00    	jne    103b85 <open+0xd8>
      end_op();
  103ae2:	e8 93 03 00 00       	call   103e7a <end_op>
      cprintf("wtf");
  103ae7:	83 ec 0c             	sub    $0xc,%esp
  103aea:	68 f3 43 10 00       	push   $0x1043f3
  103aef:	e8 f8 c5 ff ff       	call   1000ec <cprintf>
  103af4:	83 c4 10             	add    $0x10,%esp
      return 0;
  103af7:	b8 00 00 00 00       	mov    $0x0,%eax
  103afc:	e9 1c 01 00 00       	jmp    103c1d <open+0x170>
    }
  } else {
    if((ip = namei(path)) == 0){
  103b01:	83 ec 0c             	sub    $0xc,%esp
  103b04:	ff 75 08             	push   0x8(%ebp)
  103b07:	e8 b1 f8 ff ff       	call   1033bd <namei>
  103b0c:	83 c4 10             	add    $0x10,%esp
  103b0f:	89 45 f4             	mov    %eax,-0xc(%ebp)
  103b12:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
  103b16:	75 1f                	jne    103b37 <open+0x8a>
      end_op();
  103b18:	e8 5d 03 00 00       	call   103e7a <end_op>
      cprintf("wtf1");
  103b1d:	83 ec 0c             	sub    $0xc,%esp
  103b20:	68 f7 43 10 00       	push   $0x1043f7
  103b25:	e8 c2 c5 ff ff       	call   1000ec <cprintf>
  103b2a:	83 c4 10             	add    $0x10,%esp
      return 0;
  103b2d:	b8 00 00 00 00       	mov    $0x0,%eax
  103b32:	e9 e6 00 00 00       	jmp    103c1d <open+0x170>
    }
    iread(ip);
  103b37:	83 ec 0c             	sub    $0xc,%esp
  103b3a:	ff 75 f4             	push   -0xc(%ebp)
  103b3d:	e8 4d ef ff ff       	call   102a8f <iread>
  103b42:	83 c4 10             	add    $0x10,%esp
    if(ip->type == T_DIR && omode != O_RDONLY){
  103b45:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103b48:	0f b7 40 10          	movzwl 0x10(%eax),%eax
  103b4c:	66 83 f8 01          	cmp    $0x1,%ax
  103b50:	75 33                	jne    103b85 <open+0xd8>
  103b52:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
  103b56:	74 2d                	je     103b85 <open+0xd8>
      iput(ip);
  103b58:	83 ec 0c             	sub    $0xc,%esp
  103b5b:	ff 75 f4             	push   -0xc(%ebp)
  103b5e:	e8 42 ed ff ff       	call   1028a5 <iput>
  103b63:	83 c4 10             	add    $0x10,%esp
      end_op();
  103b66:	e8 0f 03 00 00       	call   103e7a <end_op>
      cprintf("wtf2");
  103b6b:	83 ec 0c             	sub    $0xc,%esp
  103b6e:	68 fc 43 10 00       	push   $0x1043fc
  103b73:	e8 74 c5 ff ff       	call   1000ec <cprintf>
  103b78:	83 c4 10             	add    $0x10,%esp
      return 0;
  103b7b:	b8 00 00 00 00       	mov    $0x0,%eax
  103b80:	e9 98 00 00 00       	jmp    103c1d <open+0x170>
    }
  }

  struct file* f;
  if((f = filealloc()) == 0) { 
  103b85:	e8 6a f8 ff ff       	call   1033f4 <filealloc>
  103b8a:	89 45 f0             	mov    %eax,-0x10(%ebp)
  103b8d:	83 7d f0 00          	cmpl   $0x0,-0x10(%ebp)
  103b91:	75 2a                	jne    103bbd <open+0x110>
    iput(ip);
  103b93:	83 ec 0c             	sub    $0xc,%esp
  103b96:	ff 75 f4             	push   -0xc(%ebp)
  103b99:	e8 07 ed ff ff       	call   1028a5 <iput>
  103b9e:	83 c4 10             	add    $0x10,%esp
    end_op();
  103ba1:	e8 d4 02 00 00       	call   103e7a <end_op>
    cprintf("wtf3");
  103ba6:	83 ec 0c             	sub    $0xc,%esp
  103ba9:	68 01 44 10 00       	push   $0x104401
  103bae:	e8 39 c5 ff ff       	call   1000ec <cprintf>
  103bb3:	83 c4 10             	add    $0x10,%esp
    return 0;
  103bb6:	b8 00 00 00 00       	mov    $0x0,%eax
  103bbb:	eb 60                	jmp    103c1d <open+0x170>
  }

  f->type = FD_INODE;
  103bbd:	8b 45 f0             	mov    -0x10(%ebp),%eax
  103bc0:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  f->ip = ip;
  103bc6:	8b 45 f0             	mov    -0x10(%ebp),%eax
  103bc9:	8b 55 f4             	mov    -0xc(%ebp),%edx
  103bcc:	89 50 0c             	mov    %edx,0xc(%eax)
  f->off = 0;
  103bcf:	8b 45 f0             	mov    -0x10(%ebp),%eax
  103bd2:	c7 40 10 00 00 00 00 	movl   $0x0,0x10(%eax)
  f->readable = !(omode & O_WRONLY);
  103bd9:	8b 45 0c             	mov    0xc(%ebp),%eax
  103bdc:	83 e0 01             	and    $0x1,%eax
  103bdf:	83 e0 01             	and    $0x1,%eax
  103be2:	83 f0 01             	xor    $0x1,%eax
  103be5:	89 c2                	mov    %eax,%edx
  103be7:	8b 45 f0             	mov    -0x10(%ebp),%eax
  103bea:	88 50 08             	mov    %dl,0x8(%eax)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
  103bed:	8b 45 0c             	mov    0xc(%ebp),%eax
  103bf0:	83 e0 01             	and    $0x1,%eax
  103bf3:	85 c0                	test   %eax,%eax
  103bf5:	75 0a                	jne    103c01 <open+0x154>
  103bf7:	8b 45 0c             	mov    0xc(%ebp),%eax
  103bfa:	83 e0 02             	and    $0x2,%eax
  103bfd:	85 c0                	test   %eax,%eax
  103bff:	74 07                	je     103c08 <open+0x15b>
  103c01:	b8 01 00 00 00       	mov    $0x1,%eax
  103c06:	eb 05                	jmp    103c0d <open+0x160>
  103c08:	b8 00 00 00 00       	mov    $0x0,%eax
  103c0d:	89 c2                	mov    %eax,%edx
  103c0f:	8b 45 f0             	mov    -0x10(%ebp),%eax
  103c12:	88 50 09             	mov    %dl,0x9(%eax)
  end_op();
  103c15:	e8 60 02 00 00       	call   103e7a <end_op>
  return f;
  103c1a:	8b 45 f0             	mov    -0x10(%ebp),%eax
}
  103c1d:	c9                   	leave
  103c1e:	c3                   	ret

00103c1f <mkdir>:

int mkdir(char *path)
{
  103c1f:	55                   	push   %ebp
  103c20:	89 e5                	mov    %esp,%ebp
  103c22:	83 ec 18             	sub    $0x18,%esp
  struct inode *ip;

  begin_op();
  103c25:	e8 4a 02 00 00       	call   103e74 <begin_op>
  if((ip = create(path, T_DIR, 0, 0)) == 0){
  103c2a:	6a 00                	push   $0x0
  103c2c:	6a 00                	push   $0x0
  103c2e:	6a 01                	push   $0x1
  103c30:	ff 75 08             	push   0x8(%ebp)
  103c33:	e8 a5 fc ff ff       	call   1038dd <create>
  103c38:	83 c4 10             	add    $0x10,%esp
  103c3b:	89 45 f4             	mov    %eax,-0xc(%ebp)
  103c3e:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
  103c42:	75 0c                	jne    103c50 <mkdir+0x31>
    end_op();
  103c44:	e8 31 02 00 00       	call   103e7a <end_op>
    return -1;
  103c49:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  103c4e:	eb 18                	jmp    103c68 <mkdir+0x49>
  }
  iput(ip);
  103c50:	83 ec 0c             	sub    $0xc,%esp
  103c53:	ff 75 f4             	push   -0xc(%ebp)
  103c56:	e8 4a ec ff ff       	call   1028a5 <iput>
  103c5b:	83 c4 10             	add    $0x10,%esp
  end_op();
  103c5e:	e8 17 02 00 00       	call   103e7a <end_op>
  return 0;
  103c63:	b8 00 00 00 00       	mov    $0x0,%eax
  103c68:	c9                   	leave
  103c69:	c3                   	ret

00103c6a <initlog>:

static void recover_from_log(void);
static void commit();
void
initlog(int dev)
{
  103c6a:	55                   	push   %ebp
  103c6b:	89 e5                	mov    %esp,%ebp
  103c6d:	83 ec 28             	sub    $0x28,%esp
  if (sizeof(struct logheader) >= BSIZE)
    panic("initlog: too big logheader");

  struct superblock sb;
  readsb(dev, &sb);
  103c70:	83 ec 08             	sub    $0x8,%esp
  103c73:	8d 45 dc             	lea    -0x24(%ebp),%eax
  103c76:	50                   	push   %eax
  103c77:	ff 75 08             	push   0x8(%ebp)
  103c7a:	e8 1c e8 ff ff       	call   10249b <readsb>
  103c7f:	83 c4 10             	add    $0x10,%esp
  log.start = sb.logstart;
  103c82:	8b 45 ec             	mov    -0x14(%ebp),%eax
  103c85:	a3 20 b6 10 00       	mov    %eax,0x10b620
  log.size = sb.nlog;
  103c8a:	8b 45 e8             	mov    -0x18(%ebp),%eax
  103c8d:	a3 24 b6 10 00       	mov    %eax,0x10b624
  log.dev = dev;
  103c92:	8b 45 08             	mov    0x8(%ebp),%eax
  103c95:	a3 2c b6 10 00       	mov    %eax,0x10b62c
  recover_from_log();
  103c9a:	e8 b3 01 00 00       	call   103e52 <recover_from_log>
}
  103c9f:	90                   	nop
  103ca0:	c9                   	leave
  103ca1:	c3                   	ret

00103ca2 <install_trans>:
// }

// Copy committed blocks from log to their home location
static void
install_trans(void)
{
  103ca2:	55                   	push   %ebp
  103ca3:	89 e5                	mov    %esp,%ebp
  103ca5:	83 ec 18             	sub    $0x18,%esp
  // install_trans_modified_ul();
  
  int tail;

  for (tail = 0; tail < log.lh.n; tail++) {
  103ca8:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  103caf:	e9 95 00 00 00       	jmp    103d49 <install_trans+0xa7>
    if (PANIC_5) {
      if (tail == log.lh.n/2) panic("[UNDOLOG] Panic in install_trans type 5");
    }
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
  103cb4:	8b 15 20 b6 10 00    	mov    0x10b620,%edx
  103cba:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103cbd:	01 d0                	add    %edx,%eax
  103cbf:	83 c0 01             	add    $0x1,%eax
  103cc2:	89 c2                	mov    %eax,%edx
  103cc4:	a1 2c b6 10 00       	mov    0x10b62c,%eax
  103cc9:	83 ec 08             	sub    $0x8,%esp
  103ccc:	52                   	push   %edx
  103ccd:	50                   	push   %eax
  103cce:	e8 c8 e2 ff ff       	call   101f9b <bread>
  103cd3:	83 c4 10             	add    $0x10,%esp
  103cd6:	89 45 f0             	mov    %eax,-0x10(%ebp)
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
  103cd9:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103cdc:	83 c0 04             	add    $0x4,%eax
  103cdf:	8b 04 85 24 b6 10 00 	mov    0x10b624(,%eax,4),%eax
  103ce6:	89 c2                	mov    %eax,%edx
  103ce8:	a1 2c b6 10 00       	mov    0x10b62c,%eax
  103ced:	83 ec 08             	sub    $0x8,%esp
  103cf0:	52                   	push   %edx
  103cf1:	50                   	push   %eax
  103cf2:	e8 a4 e2 ff ff       	call   101f9b <bread>
  103cf7:	83 c4 10             	add    $0x10,%esp
  103cfa:	89 45 ec             	mov    %eax,-0x14(%ebp)
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
  103cfd:	8b 45 f0             	mov    -0x10(%ebp),%eax
  103d00:	8d 50 1c             	lea    0x1c(%eax),%edx
  103d03:	8b 45 ec             	mov    -0x14(%ebp),%eax
  103d06:	83 c0 1c             	add    $0x1c,%eax
  103d09:	83 ec 04             	sub    $0x4,%esp
  103d0c:	68 00 02 00 00       	push   $0x200
  103d11:	52                   	push   %edx
  103d12:	50                   	push   %eax
  103d13:	e8 2d d2 ff ff       	call   100f45 <memmove>
  103d18:	83 c4 10             	add    $0x10,%esp
    bwrite(dbuf);  // write dst to disk
  103d1b:	83 ec 0c             	sub    $0xc,%esp
  103d1e:	ff 75 ec             	push   -0x14(%ebp)
  103d21:	e8 ae e2 ff ff       	call   101fd4 <bwrite>
  103d26:	83 c4 10             	add    $0x10,%esp
    brelse(lbuf);
  103d29:	83 ec 0c             	sub    $0xc,%esp
  103d2c:	ff 75 f0             	push   -0x10(%ebp)
  103d2f:	e8 df e2 ff ff       	call   102013 <brelse>
  103d34:	83 c4 10             	add    $0x10,%esp
    brelse(dbuf);
  103d37:	83 ec 0c             	sub    $0xc,%esp
  103d3a:	ff 75 ec             	push   -0x14(%ebp)
  103d3d:	e8 d1 e2 ff ff       	call   102013 <brelse>
  103d42:	83 c4 10             	add    $0x10,%esp
  for (tail = 0; tail < log.lh.n; tail++) {
  103d45:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  103d49:	a1 30 b6 10 00       	mov    0x10b630,%eax
  103d4e:	39 45 f4             	cmp    %eax,-0xc(%ebp)
  103d51:	0f 8c 5d ff ff ff    	jl     103cb4 <install_trans+0x12>
  }
}
  103d57:	90                   	nop
  103d58:	90                   	nop
  103d59:	c9                   	leave
  103d5a:	c3                   	ret

00103d5b <read_head>:

// Read the log header from disk into the in-memory log header
static void
read_head(void)
{
  103d5b:	55                   	push   %ebp
  103d5c:	89 e5                	mov    %esp,%ebp
  103d5e:	83 ec 18             	sub    $0x18,%esp
  struct buf *buf = bread(log.dev, log.start);
  103d61:	a1 20 b6 10 00       	mov    0x10b620,%eax
  103d66:	89 c2                	mov    %eax,%edx
  103d68:	a1 2c b6 10 00       	mov    0x10b62c,%eax
  103d6d:	83 ec 08             	sub    $0x8,%esp
  103d70:	52                   	push   %edx
  103d71:	50                   	push   %eax
  103d72:	e8 24 e2 ff ff       	call   101f9b <bread>
  103d77:	83 c4 10             	add    $0x10,%esp
  103d7a:	89 45 f0             	mov    %eax,-0x10(%ebp)
  struct logheader *lh = (struct logheader *) (buf->data);
  103d7d:	8b 45 f0             	mov    -0x10(%ebp),%eax
  103d80:	83 c0 1c             	add    $0x1c,%eax
  103d83:	89 45 ec             	mov    %eax,-0x14(%ebp)
  int i;
  log.lh.n = lh->n;
  103d86:	8b 45 ec             	mov    -0x14(%ebp),%eax
  103d89:	8b 00                	mov    (%eax),%eax
  103d8b:	a3 30 b6 10 00       	mov    %eax,0x10b630
  for (i = 0; i < log.lh.n; i++) {
  103d90:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  103d97:	eb 1b                	jmp    103db4 <read_head+0x59>
    log.lh.block[i] = lh->block[i];
  103d99:	8b 45 ec             	mov    -0x14(%ebp),%eax
  103d9c:	8b 55 f4             	mov    -0xc(%ebp),%edx
  103d9f:	8b 44 90 04          	mov    0x4(%eax,%edx,4),%eax
  103da3:	8b 55 f4             	mov    -0xc(%ebp),%edx
  103da6:	83 c2 04             	add    $0x4,%edx
  103da9:	89 04 95 24 b6 10 00 	mov    %eax,0x10b624(,%edx,4)
  for (i = 0; i < log.lh.n; i++) {
  103db0:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  103db4:	a1 30 b6 10 00       	mov    0x10b630,%eax
  103db9:	39 45 f4             	cmp    %eax,-0xc(%ebp)
  103dbc:	7c db                	jl     103d99 <read_head+0x3e>
  }
  brelse(buf);
  103dbe:	83 ec 0c             	sub    $0xc,%esp
  103dc1:	ff 75 f0             	push   -0x10(%ebp)
  103dc4:	e8 4a e2 ff ff       	call   102013 <brelse>
  103dc9:	83 c4 10             	add    $0x10,%esp
}
  103dcc:	90                   	nop
  103dcd:	c9                   	leave
  103dce:	c3                   	ret

00103dcf <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
  103dcf:	55                   	push   %ebp
  103dd0:	89 e5                	mov    %esp,%ebp
  103dd2:	83 ec 18             	sub    $0x18,%esp
  struct buf *buf = bread(log.dev, log.start);
  103dd5:	a1 20 b6 10 00       	mov    0x10b620,%eax
  103dda:	89 c2                	mov    %eax,%edx
  103ddc:	a1 2c b6 10 00       	mov    0x10b62c,%eax
  103de1:	83 ec 08             	sub    $0x8,%esp
  103de4:	52                   	push   %edx
  103de5:	50                   	push   %eax
  103de6:	e8 b0 e1 ff ff       	call   101f9b <bread>
  103deb:	83 c4 10             	add    $0x10,%esp
  103dee:	89 45 f0             	mov    %eax,-0x10(%ebp)
  struct logheader *hb = (struct logheader *) (buf->data);
  103df1:	8b 45 f0             	mov    -0x10(%ebp),%eax
  103df4:	83 c0 1c             	add    $0x1c,%eax
  103df7:	89 45 ec             	mov    %eax,-0x14(%ebp)
  int i;
  hb->n = log.lh.n;
  103dfa:	8b 15 30 b6 10 00    	mov    0x10b630,%edx
  103e00:	8b 45 ec             	mov    -0x14(%ebp),%eax
  103e03:	89 10                	mov    %edx,(%eax)
  for (i = 0; i < log.lh.n; i++) {
  103e05:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  103e0c:	eb 1b                	jmp    103e29 <write_head+0x5a>
    hb->block[i] = log.lh.block[i];
  103e0e:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103e11:	83 c0 04             	add    $0x4,%eax
  103e14:	8b 0c 85 24 b6 10 00 	mov    0x10b624(,%eax,4),%ecx
  103e1b:	8b 45 ec             	mov    -0x14(%ebp),%eax
  103e1e:	8b 55 f4             	mov    -0xc(%ebp),%edx
  103e21:	89 4c 90 04          	mov    %ecx,0x4(%eax,%edx,4)
  for (i = 0; i < log.lh.n; i++) {
  103e25:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  103e29:	a1 30 b6 10 00       	mov    0x10b630,%eax
  103e2e:	39 45 f4             	cmp    %eax,-0xc(%ebp)
  103e31:	7c db                	jl     103e0e <write_head+0x3f>
  }
  bwrite(buf);
  103e33:	83 ec 0c             	sub    $0xc,%esp
  103e36:	ff 75 f0             	push   -0x10(%ebp)
  103e39:	e8 96 e1 ff ff       	call   101fd4 <bwrite>
  103e3e:	83 c4 10             	add    $0x10,%esp
  brelse(buf);
  103e41:	83 ec 0c             	sub    $0xc,%esp
  103e44:	ff 75 f0             	push   -0x10(%ebp)
  103e47:	e8 c7 e1 ff ff       	call   102013 <brelse>
  103e4c:	83 c4 10             	add    $0x10,%esp
}
  103e4f:	90                   	nop
  103e50:	c9                   	leave
  103e51:	c3                   	ret

00103e52 <recover_from_log>:

static void
recover_from_log(void)
{
  103e52:	55                   	push   %ebp
  103e53:	89 e5                	mov    %esp,%ebp
  103e55:	83 ec 08             	sub    $0x8,%esp
  read_head();
  103e58:	e8 fe fe ff ff       	call   103d5b <read_head>
  install_trans(); // if committed, copy from log to disk
  103e5d:	e8 40 fe ff ff       	call   103ca2 <install_trans>
  log.lh.n = 0;
  103e62:	c7 05 30 b6 10 00 00 	movl   $0x0,0x10b630
  103e69:	00 00 00 
  write_head(); // clear the log
  103e6c:	e8 5e ff ff ff       	call   103dcf <write_head>
}
  103e71:	90                   	nop
  103e72:	c9                   	leave
  103e73:	c3                   	ret

00103e74 <begin_op>:

// called at the start of each FS system call.
void
begin_op(void)
{
  103e74:	55                   	push   %ebp
  103e75:	89 e5                	mov    %esp,%ebp
  
}
  103e77:	90                   	nop
  103e78:	5d                   	pop    %ebp
  103e79:	c3                   	ret

00103e7a <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
  103e7a:	55                   	push   %ebp
  103e7b:	89 e5                	mov    %esp,%ebp
  103e7d:	83 ec 08             	sub    $0x8,%esp
  // call commit w/o holding locks, since not allowed
  // to sleep with locks.
  commit();
  103e80:	e8 03 00 00 00       	call   103e88 <commit>
}
  103e85:	90                   	nop
  103e86:	c9                   	leave
  103e87:	c3                   	ret

00103e88 <commit>:


/* DO NOT MODIFY THIS FUNCTION*/
static void
commit()
{ 
  103e88:	55                   	push   %ebp
  103e89:	89 e5                	mov    %esp,%ebp
  103e8b:	83 ec 08             	sub    $0x8,%esp
  if (log.lh.n > 0) {
  103e8e:	a1 30 b6 10 00       	mov    0x10b630,%eax
  103e93:	85 c0                	test   %eax,%eax
  103e95:	7e 19                	jle    103eb0 <commit+0x28>
    if (PANIC_1) {
      panic("[UNDOLOG] Panic in commit type 1");
    }
    write_head();    // Write header to disk 
  103e97:	e8 33 ff ff ff       	call   103dcf <write_head>
    if (PANIC_2) {
      panic("[UNDOLOG] Panic in commit type 2");
    }
    install_trans(); // Now install writes to home locations    
  103e9c:	e8 01 fe ff ff       	call   103ca2 <install_trans>
    if (PANIC_3) {
      panic("[UNDOLOG] Panic in commit type 3");
    }
    log.lh.n = 0;
  103ea1:	c7 05 30 b6 10 00 00 	movl   $0x0,0x10b630
  103ea8:	00 00 00 
    write_head();    // Erase the transaction from the log 
  103eab:	e8 1f ff ff ff       	call   103dcf <write_head>
    if (PANIC_4) {
      panic("[UNDOLOG] Panic in commit type 4");
    }  
  }
}
  103eb0:	90                   	nop
  103eb1:	c9                   	leave
  103eb2:	c3                   	ret

00103eb3 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
  103eb3:	55                   	push   %ebp
  103eb4:	89 e5                	mov    %esp,%ebp
  103eb6:	83 ec 18             	sub    $0x18,%esp
  int i;

  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
  103eb9:	a1 30 b6 10 00       	mov    0x10b630,%eax
  103ebe:	83 f8 1d             	cmp    $0x1d,%eax
  103ec1:	7f 12                	jg     103ed5 <log_write+0x22>
  103ec3:	8b 15 30 b6 10 00    	mov    0x10b630,%edx
  103ec9:	a1 24 b6 10 00       	mov    0x10b624,%eax
  103ece:	83 e8 01             	sub    $0x1,%eax
  103ed1:	39 c2                	cmp    %eax,%edx
  103ed3:	7c 0d                	jl     103ee2 <log_write+0x2f>
    panic("too big a transaction");
  103ed5:	83 ec 0c             	sub    $0xc,%esp
  103ed8:	68 06 44 10 00       	push   $0x104406
  103edd:	e8 cc c3 ff ff       	call   1002ae <panic>

  for (i = 0; i < log.lh.n; i++) {
  103ee2:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  103ee9:	eb 1d                	jmp    103f08 <log_write+0x55>
    if (log.lh.block[i] == b->blockno)   // log absorbtion
  103eeb:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103eee:	83 c0 04             	add    $0x4,%eax
  103ef1:	8b 04 85 24 b6 10 00 	mov    0x10b624(,%eax,4),%eax
  103ef8:	89 c2                	mov    %eax,%edx
  103efa:	8b 45 08             	mov    0x8(%ebp),%eax
  103efd:	8b 40 08             	mov    0x8(%eax),%eax
  103f00:	39 c2                	cmp    %eax,%edx
  103f02:	74 10                	je     103f14 <log_write+0x61>
  for (i = 0; i < log.lh.n; i++) {
  103f04:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  103f08:	a1 30 b6 10 00       	mov    0x10b630,%eax
  103f0d:	39 45 f4             	cmp    %eax,-0xc(%ebp)
  103f10:	7c d9                	jl     103eeb <log_write+0x38>
  103f12:	eb 01                	jmp    103f15 <log_write+0x62>
      break;
  103f14:	90                   	nop
  }
  log.lh.block[i] = b->blockno;
  103f15:	8b 45 08             	mov    0x8(%ebp),%eax
  103f18:	8b 40 08             	mov    0x8(%eax),%eax
  103f1b:	89 c2                	mov    %eax,%edx
  103f1d:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103f20:	83 c0 04             	add    $0x4,%eax
  103f23:	89 14 85 24 b6 10 00 	mov    %edx,0x10b624(,%eax,4)
  if (i == log.lh.n)
  103f2a:	a1 30 b6 10 00       	mov    0x10b630,%eax
  103f2f:	39 45 f4             	cmp    %eax,-0xc(%ebp)
  103f32:	75 0d                	jne    103f41 <log_write+0x8e>
    log.lh.n++;
  103f34:	a1 30 b6 10 00       	mov    0x10b630,%eax
  103f39:	83 c0 01             	add    $0x1,%eax
  103f3c:	a3 30 b6 10 00       	mov    %eax,0x10b630
  b->flags |= B_DIRTY; // prevent eviction
  103f41:	8b 45 08             	mov    0x8(%ebp),%eax
  103f44:	8b 00                	mov    (%eax),%eax
  103f46:	83 c8 04             	or     $0x4,%eax
  103f49:	89 c2                	mov    %eax,%edx
  103f4b:	8b 45 08             	mov    0x8(%ebp),%eax
  103f4e:	89 10                	mov    %edx,(%eax)
}
  103f50:	90                   	nop
  103f51:	c9                   	leave
  103f52:	c3                   	ret

00103f53 <write_log_ul>:



/// i read b, now this a old buffer that i want to write in the log.
void write_log_ul(struct buf* b){
  103f53:	55                   	push   %ebp
  103f54:	89 e5                	mov    %esp,%ebp
  103f56:	83 ec 18             	sub    $0x18,%esp
  int i;
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
  103f59:	a1 30 b6 10 00       	mov    0x10b630,%eax
  103f5e:	83 f8 1d             	cmp    $0x1d,%eax
  103f61:	7f 12                	jg     103f75 <write_log_ul+0x22>
  103f63:	8b 15 30 b6 10 00    	mov    0x10b630,%edx
  103f69:	a1 24 b6 10 00       	mov    0x10b624,%eax
  103f6e:	83 e8 01             	sub    $0x1,%eax
  103f71:	39 c2                	cmp    %eax,%edx
  103f73:	7c 0d                	jl     103f82 <write_log_ul+0x2f>
    panic("too big a transaction");
  103f75:	83 ec 0c             	sub    $0xc,%esp
  103f78:	68 06 44 10 00       	push   $0x104406
  103f7d:	e8 2c c3 ff ff       	call   1002ae <panic>

  for (i = 0; i < log.lh.n; i++) {
  103f82:	c7 45 f4 00 00 00 00 	movl   $0x0,-0xc(%ebp)
  103f89:	eb 1d                	jmp    103fa8 <write_log_ul+0x55>
    if (log.lh.block[i] == b->blockno)   // log absorbtion
  103f8b:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103f8e:	83 c0 04             	add    $0x4,%eax
  103f91:	8b 04 85 24 b6 10 00 	mov    0x10b624(,%eax,4),%eax
  103f98:	89 c2                	mov    %eax,%edx
  103f9a:	8b 45 08             	mov    0x8(%ebp),%eax
  103f9d:	8b 40 08             	mov    0x8(%eax),%eax
  103fa0:	39 c2                	cmp    %eax,%edx
  103fa2:	74 10                	je     103fb4 <write_log_ul+0x61>
  for (i = 0; i < log.lh.n; i++) {
  103fa4:	83 45 f4 01          	addl   $0x1,-0xc(%ebp)
  103fa8:	a1 30 b6 10 00       	mov    0x10b630,%eax
  103fad:	39 45 f4             	cmp    %eax,-0xc(%ebp)
  103fb0:	7c d9                	jl     103f8b <write_log_ul+0x38>
  103fb2:	eb 01                	jmp    103fb5 <write_log_ul+0x62>
      break;
  103fb4:	90                   	nop
  }
  log.lh.block[i] = b->blockno;
  103fb5:	8b 45 08             	mov    0x8(%ebp),%eax
  103fb8:	8b 40 08             	mov    0x8(%eax),%eax
  103fbb:	89 c2                	mov    %eax,%edx
  103fbd:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103fc0:	83 c0 04             	add    $0x4,%eax
  103fc3:	89 14 85 24 b6 10 00 	mov    %edx,0x10b624(,%eax,4)
  if (i == log.lh.n){
  103fca:	a1 30 b6 10 00       	mov    0x10b630,%eax
  103fcf:	39 45 f4             	cmp    %eax,-0xc(%ebp)
  103fd2:	75 6b                	jne    10403f <write_log_ul+0xec>
  /// only if this the first time, this block is being changed write the original 
  /// value to the log.

    log.lh.n++;
  103fd4:	a1 30 b6 10 00       	mov    0x10b630,%eax
  103fd9:	83 c0 01             	add    $0x1,%eax
  103fdc:	a3 30 b6 10 00       	mov    %eax,0x10b630
  /// write to buffer 
    struct buf* to = bread(log.dev,log.start+1+i);
  103fe1:	a1 20 b6 10 00       	mov    0x10b620,%eax
  103fe6:	8d 50 01             	lea    0x1(%eax),%edx
  103fe9:	8b 45 f4             	mov    -0xc(%ebp),%eax
  103fec:	01 d0                	add    %edx,%eax
  103fee:	89 c2                	mov    %eax,%edx
  103ff0:	a1 2c b6 10 00       	mov    0x10b62c,%eax
  103ff5:	83 ec 08             	sub    $0x8,%esp
  103ff8:	52                   	push   %edx
  103ff9:	50                   	push   %eax
  103ffa:	e8 9c df ff ff       	call   101f9b <bread>
  103fff:	83 c4 10             	add    $0x10,%esp
  104002:	89 45 f0             	mov    %eax,-0x10(%ebp)
    memmove(to->data,b->data,BSIZE);
  104005:	8b 45 08             	mov    0x8(%ebp),%eax
  104008:	8d 50 1c             	lea    0x1c(%eax),%edx
  10400b:	8b 45 f0             	mov    -0x10(%ebp),%eax
  10400e:	83 c0 1c             	add    $0x1c,%eax
  104011:	83 ec 04             	sub    $0x4,%esp
  104014:	68 00 02 00 00       	push   $0x200
  104019:	52                   	push   %edx
  10401a:	50                   	push   %eax
  10401b:	e8 25 cf ff ff       	call   100f45 <memmove>
  104020:	83 c4 10             	add    $0x10,%esp
    bwrite(to);
  104023:	83 ec 0c             	sub    $0xc,%esp
  104026:	ff 75 f0             	push   -0x10(%ebp)
  104029:	e8 a6 df ff ff       	call   101fd4 <bwrite>
  10402e:	83 c4 10             	add    $0x10,%esp
    brelse(to);
  104031:	83 ec 0c             	sub    $0xc,%esp
  104034:	ff 75 f0             	push   -0x10(%ebp)
  104037:	e8 d7 df ff ff       	call   102013 <brelse>
  10403c:	83 c4 10             	add    $0x10,%esp
  }
  10403f:	90                   	nop
  104040:	c9                   	leave
  104041:	c3                   	ret
